#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 18;

static const uint8_t target[] = {
	0xdb, 0xaf, 0x89, 0x13, 0x8e, 0xf6, 0x7f, 0x75, 0x6d, 0xcd, 0x81, 0x6f, 0xee, 0xec, 0x73, 0xb7, 0xf6, 0xb0
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
