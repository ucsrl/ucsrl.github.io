#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 30;

static const uint8_t target[] = {
	0x9a, 0x8c, 0x4, 0xdc, 0x63, 0x8b, 0x1c, 0x35, 0xe7, 0x6f, 0x6c, 0xce, 0xe5, 0x82, 0x71, 0xf9, 0x73, 0x8f, 0x6, 0x40, 0x15, 0xf8, 0x2, 0x97, 0xc6, 0xf0, 0xb8, 0xa1, 0x75, 0x29
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
