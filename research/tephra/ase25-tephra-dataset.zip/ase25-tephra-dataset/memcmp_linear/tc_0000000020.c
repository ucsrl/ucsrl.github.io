#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 20;

static const uint8_t target[] = {
	0x30, 0x31, 0xcb, 0xe0, 0x0, 0x76, 0xee, 0x2, 0x9b, 0x15, 0x52, 0xd9, 0xa6, 0x2c, 0xc, 0x6b, 0x6a, 0x8a, 0x3a, 0x4e
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
