#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 16;

static const uint8_t target[] = {
	0x40, 0x2a, 0x2a, 0xc3, 0x3d, 0x6b, 0xf, 0x2f, 0x8e, 0x42, 0xdc, 0x72, 0xea, 0xd5, 0xb2, 0x4a
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
