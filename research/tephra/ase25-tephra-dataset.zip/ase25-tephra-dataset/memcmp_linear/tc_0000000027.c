#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 27;

static const uint8_t target[] = {
	0x40, 0x9f, 0xef, 0xec, 0x3a, 0x7f, 0x89, 0x98, 0x5b, 0x98, 0xad, 0x4e, 0x7c, 0x6d, 0x32, 0xff, 0x8a, 0xbd, 0x95, 0x76, 0xdb, 0xaf, 0xb2, 0x6a, 0x9e, 0xff, 0xb0
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
