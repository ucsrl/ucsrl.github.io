#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 24;

static const uint8_t target[] = {
	0xb, 0x13, 0x33, 0xa0, 0xb2, 0x14, 0xea, 0x54, 0x6e, 0x55, 0xc8, 0x4c, 0xdc, 0xef, 0x2d, 0xf0, 0x4e, 0x4b, 0x24, 0xa3, 0xef, 0x20, 0xfd, 0xdc
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
