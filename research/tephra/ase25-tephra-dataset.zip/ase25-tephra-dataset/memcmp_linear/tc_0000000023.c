#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 23;

static const uint8_t target[] = {
	0x53, 0xef, 0xaf, 0xf3, 0xe6, 0x56, 0x6f, 0x6b, 0x75, 0xb8, 0x27, 0xa3, 0x63, 0x72, 0x2d, 0x29, 0x37, 0x3f, 0x4b, 0x83, 0xb6, 0x5a, 0x72
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
