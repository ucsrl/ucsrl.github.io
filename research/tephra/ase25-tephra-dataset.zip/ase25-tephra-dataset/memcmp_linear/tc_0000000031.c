#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 31;

static const uint8_t target[] = {
	0x95, 0x9a, 0x34, 0x4d, 0x60, 0x4b, 0x77, 0x69, 0xab, 0xaa, 0xa4, 0x49, 0x5, 0xa, 0x48, 0x6d, 0x80, 0x39, 0x81, 0x7f, 0x6c, 0x83, 0x6e, 0xd9, 0x1e, 0x34, 0x53, 0x7b, 0xb5, 0xb4, 0x88
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
