#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 32;

static const uint8_t target[] = {
	0x78, 0x7c, 0xcf, 0xe1, 0x2b, 0xf4, 0xcb, 0x4b, 0xcf, 0x6, 0xc5, 0x13, 0x8e, 0x1, 0xa1, 0xa0, 0x3a, 0x96, 0xba, 0xd3, 0xa3, 0x4b, 0x5c, 0x8d, 0x2a, 0x2c, 0x52, 0xe7, 0x69, 0xb7, 0x7b, 0xd
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
