#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 19;

static const uint8_t target[] = {
	0x94, 0xdb, 0xca, 0x37, 0xb9, 0x7e, 0xb6, 0x2c, 0x9, 0xc2, 0x71, 0x42, 0x29, 0xdc, 0x6d, 0xc, 0x86, 0x5d, 0x10
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
