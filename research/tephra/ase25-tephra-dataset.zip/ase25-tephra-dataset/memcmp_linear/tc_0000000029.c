#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 29;

static const uint8_t target[] = {
	0x10, 0x37, 0x73, 0xcc, 0x80, 0x51, 0x3d, 0xa0, 0x32, 0x2d, 0x6d, 0xbd, 0x2c, 0x0, 0x86, 0x95, 0x39, 0xfa, 0xe, 0xe0, 0x56, 0x47, 0xf7, 0x1a, 0x50, 0xd2, 0x52, 0x6c, 0xd6
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
