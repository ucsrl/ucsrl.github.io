#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 28;

static const uint8_t target[] = {
	0x4c, 0xca, 0xc8, 0xa8, 0x5d, 0xb1, 0xd8, 0x59, 0x1, 0x49, 0xb9, 0xa8, 0x43, 0x99, 0xf1, 0x97, 0x47, 0x34, 0xfc, 0x81, 0x19, 0xab, 0xbc, 0x28, 0x8d, 0x52, 0x5b, 0x9e
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
