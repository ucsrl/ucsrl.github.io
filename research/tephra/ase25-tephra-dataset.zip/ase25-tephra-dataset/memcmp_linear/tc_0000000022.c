#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 22;

static const uint8_t target[] = {
	0xbe, 0x54, 0x2f, 0x8b, 0xfd, 0xba, 0xfa, 0x9, 0xaf, 0xd0, 0x91, 0x96, 0xb9, 0x5e, 0xf0, 0x43, 0xf1, 0xb4, 0x4e, 0x25, 0xbe, 0xa3
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
