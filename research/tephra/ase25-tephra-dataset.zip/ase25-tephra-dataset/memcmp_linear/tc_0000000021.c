#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 21;

static const uint8_t target[] = {
	0xa5, 0x6, 0x5d, 0xf3, 0xd4, 0xd6, 0xf0, 0x44, 0x8, 0x64, 0x8, 0x4b, 0xdb, 0x31, 0xf1, 0xad, 0xc2, 0xb0, 0xc7, 0x4c, 0xee
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
