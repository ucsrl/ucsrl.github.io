#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 25;

static const uint8_t target[] = {
	0x9a, 0x22, 0xc1, 0xe5, 0xcd, 0x69, 0x8e, 0xdb, 0x8c, 0x6a, 0xd3, 0x3c, 0x91, 0x92, 0xc, 0xef, 0xf0, 0x77, 0x3f, 0xb0, 0xbd, 0x9, 0xb3, 0x25, 0x5a
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
