#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 10;

static const uint8_t target[] = {
	0xfe, 0x44, 0x60, 0x6d, 0xba, 0x4, 0x4e, 0xa0, 0x1a, 0xdf
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
