#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 17;

static const uint8_t target[] = {
	0x83, 0x1b, 0xe1, 0xc5, 0xc4, 0xe, 0x2d, 0x4e, 0xc6, 0x14, 0x99, 0xea, 0x69, 0x6c, 0xb2, 0xb8, 0x8e
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
