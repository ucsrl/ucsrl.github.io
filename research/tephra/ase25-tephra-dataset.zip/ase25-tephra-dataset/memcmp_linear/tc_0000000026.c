#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

static const size_t BUF_SIZE = 26;

static const uint8_t target[] = {
	0x95, 0xd9, 0xfa, 0xfc, 0x58, 0xfa, 0x5f, 0x23, 0xc4, 0x20, 0xe6, 0x5, 0x4c, 0x65, 0x62, 0x8, 0xd, 0x7c, 0xaa, 0x3, 0xc3, 0xaa, 0xa3, 0xbb, 0xe0, 0x2
};

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    if (size < BUF_SIZE)
        return TEPHRA_EXIT_FAILURE;

    if (memcmp(data, target, BUF_SIZE) == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
