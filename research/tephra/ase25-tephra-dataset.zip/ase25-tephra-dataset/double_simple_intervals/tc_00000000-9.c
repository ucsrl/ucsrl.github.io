#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    double value;
    double eps = 1e-09;
    double bound = 0.764533814500016;

    if (size < sizeof(double))
        return TEPHRA_EXIT_FAILURE;

    memcpy(&value, data, sizeof(double));

    if (value <= (bound + eps))
        if ((bound - eps) <= value)
            BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
