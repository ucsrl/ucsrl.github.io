#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint32_t uint32_eq_const_11_0;
    uint32_t uint32_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;

    if (size < 56)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;


    if (uint32_eq_const_0_0 == 101361573)
    if (uint32_eq_const_1_0 == 1963358775)
    if (uint32_eq_const_2_0 == 1328813054)
    if (uint32_eq_const_3_0 == 667723596)
    if (uint32_eq_const_4_0 == 2693286190)
    if (uint32_eq_const_5_0 == 1982884475)
    if (uint32_eq_const_6_0 == 2923746674)
    if (uint32_eq_const_7_0 == 2459041166)
    if (uint32_eq_const_8_0 == 2642323452)
    if (uint32_eq_const_9_0 == 3041770718)
    if (uint32_eq_const_10_0 == 3029904382)
    if (uint32_eq_const_11_0 == 2230228302)
    if (uint32_eq_const_12_0 == 2983112375)
    if (uint32_eq_const_13_0 == 1067018190)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
