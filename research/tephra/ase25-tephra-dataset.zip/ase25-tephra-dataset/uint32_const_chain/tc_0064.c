#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint32_t uint32_eq_const_11_0;
    uint32_t uint32_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint32_t uint32_eq_const_14_0;
    uint32_t uint32_eq_const_15_0;
    uint32_t uint32_eq_const_16_0;
    uint32_t uint32_eq_const_17_0;
    uint32_t uint32_eq_const_18_0;
    uint32_t uint32_eq_const_19_0;
    uint32_t uint32_eq_const_20_0;
    uint32_t uint32_eq_const_21_0;
    uint32_t uint32_eq_const_22_0;
    uint32_t uint32_eq_const_23_0;
    uint32_t uint32_eq_const_24_0;
    uint32_t uint32_eq_const_25_0;
    uint32_t uint32_eq_const_26_0;
    uint32_t uint32_eq_const_27_0;
    uint32_t uint32_eq_const_28_0;
    uint32_t uint32_eq_const_29_0;
    uint32_t uint32_eq_const_30_0;
    uint32_t uint32_eq_const_31_0;
    uint32_t uint32_eq_const_32_0;
    uint32_t uint32_eq_const_33_0;
    uint32_t uint32_eq_const_34_0;
    uint32_t uint32_eq_const_35_0;
    uint32_t uint32_eq_const_36_0;
    uint32_t uint32_eq_const_37_0;
    uint32_t uint32_eq_const_38_0;
    uint32_t uint32_eq_const_39_0;
    uint32_t uint32_eq_const_40_0;
    uint32_t uint32_eq_const_41_0;
    uint32_t uint32_eq_const_42_0;
    uint32_t uint32_eq_const_43_0;
    uint32_t uint32_eq_const_44_0;
    uint32_t uint32_eq_const_45_0;
    uint32_t uint32_eq_const_46_0;
    uint32_t uint32_eq_const_47_0;
    uint32_t uint32_eq_const_48_0;
    uint32_t uint32_eq_const_49_0;
    uint32_t uint32_eq_const_50_0;
    uint32_t uint32_eq_const_51_0;
    uint32_t uint32_eq_const_52_0;
    uint32_t uint32_eq_const_53_0;
    uint32_t uint32_eq_const_54_0;
    uint32_t uint32_eq_const_55_0;
    uint32_t uint32_eq_const_56_0;
    uint32_t uint32_eq_const_57_0;
    uint32_t uint32_eq_const_58_0;
    uint32_t uint32_eq_const_59_0;
    uint32_t uint32_eq_const_60_0;
    uint32_t uint32_eq_const_61_0;
    uint32_t uint32_eq_const_62_0;
    uint32_t uint32_eq_const_63_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_22_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_28_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_31_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_32_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_33_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_38_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_39_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_41_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_42_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_43_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_44_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_45_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_51_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_53_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_54_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_55_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_56_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_59_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_60_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_61_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_63_0, &data[i], 4);
    i += 4;


    if (uint32_eq_const_0_0 == 1397144585)
    if (uint32_eq_const_1_0 == 2640975455)
    if (uint32_eq_const_2_0 == 698759355)
    if (uint32_eq_const_3_0 == 1692969890)
    if (uint32_eq_const_4_0 == 3879071)
    if (uint32_eq_const_5_0 == 3996868557)
    if (uint32_eq_const_6_0 == 2385873473)
    if (uint32_eq_const_7_0 == 557042804)
    if (uint32_eq_const_8_0 == 512424517)
    if (uint32_eq_const_9_0 == 82125502)
    if (uint32_eq_const_10_0 == 3370996773)
    if (uint32_eq_const_11_0 == 895311763)
    if (uint32_eq_const_12_0 == 3425547489)
    if (uint32_eq_const_13_0 == 1735765558)
    if (uint32_eq_const_14_0 == 1880738156)
    if (uint32_eq_const_15_0 == 3671253387)
    if (uint32_eq_const_16_0 == 3522212977)
    if (uint32_eq_const_17_0 == 140060985)
    if (uint32_eq_const_18_0 == 3563149812)
    if (uint32_eq_const_19_0 == 3655623398)
    if (uint32_eq_const_20_0 == 1658589625)
    if (uint32_eq_const_21_0 == 1766371392)
    if (uint32_eq_const_22_0 == 3692955352)
    if (uint32_eq_const_23_0 == 2931110201)
    if (uint32_eq_const_24_0 == 3648833378)
    if (uint32_eq_const_25_0 == 3553429501)
    if (uint32_eq_const_26_0 == 2078066570)
    if (uint32_eq_const_27_0 == 2674462384)
    if (uint32_eq_const_28_0 == 3299204731)
    if (uint32_eq_const_29_0 == 3493256105)
    if (uint32_eq_const_30_0 == 1689582945)
    if (uint32_eq_const_31_0 == 1485831329)
    if (uint32_eq_const_32_0 == 1970973079)
    if (uint32_eq_const_33_0 == 2116980428)
    if (uint32_eq_const_34_0 == 627701808)
    if (uint32_eq_const_35_0 == 2199032313)
    if (uint32_eq_const_36_0 == 3906212610)
    if (uint32_eq_const_37_0 == 4097679103)
    if (uint32_eq_const_38_0 == 3884485445)
    if (uint32_eq_const_39_0 == 757130410)
    if (uint32_eq_const_40_0 == 1448278258)
    if (uint32_eq_const_41_0 == 1442025539)
    if (uint32_eq_const_42_0 == 636662240)
    if (uint32_eq_const_43_0 == 3454403107)
    if (uint32_eq_const_44_0 == 3887175701)
    if (uint32_eq_const_45_0 == 3800593261)
    if (uint32_eq_const_46_0 == 915096385)
    if (uint32_eq_const_47_0 == 570554214)
    if (uint32_eq_const_48_0 == 455478169)
    if (uint32_eq_const_49_0 == 3625906490)
    if (uint32_eq_const_50_0 == 1156822985)
    if (uint32_eq_const_51_0 == 487352955)
    if (uint32_eq_const_52_0 == 468178489)
    if (uint32_eq_const_53_0 == 2852646146)
    if (uint32_eq_const_54_0 == 1754135790)
    if (uint32_eq_const_55_0 == 2996945307)
    if (uint32_eq_const_56_0 == 3962208337)
    if (uint32_eq_const_57_0 == 2997466888)
    if (uint32_eq_const_58_0 == 3560200519)
    if (uint32_eq_const_59_0 == 1203559667)
    if (uint32_eq_const_60_0 == 2485077314)
    if (uint32_eq_const_61_0 == 1005373927)
    if (uint32_eq_const_62_0 == 3126420194)
    if (uint32_eq_const_63_0 == 861888021)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
