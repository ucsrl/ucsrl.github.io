#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint32_t uint32_eq_const_11_0;
    uint32_t uint32_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint32_t uint32_eq_const_14_0;
    uint32_t uint32_eq_const_15_0;
    uint32_t uint32_eq_const_16_0;
    uint32_t uint32_eq_const_17_0;
    uint32_t uint32_eq_const_18_0;
    uint32_t uint32_eq_const_19_0;
    uint32_t uint32_eq_const_20_0;
    uint32_t uint32_eq_const_21_0;
    uint32_t uint32_eq_const_22_0;
    uint32_t uint32_eq_const_23_0;
    uint32_t uint32_eq_const_24_0;
    uint32_t uint32_eq_const_25_0;
    uint32_t uint32_eq_const_26_0;
    uint32_t uint32_eq_const_27_0;
    uint32_t uint32_eq_const_28_0;
    uint32_t uint32_eq_const_29_0;
    uint32_t uint32_eq_const_30_0;
    uint32_t uint32_eq_const_31_0;
    uint32_t uint32_eq_const_32_0;
    uint32_t uint32_eq_const_33_0;
    uint32_t uint32_eq_const_34_0;
    uint32_t uint32_eq_const_35_0;
    uint32_t uint32_eq_const_36_0;
    uint32_t uint32_eq_const_37_0;
    uint32_t uint32_eq_const_38_0;
    uint32_t uint32_eq_const_39_0;
    uint32_t uint32_eq_const_40_0;
    uint32_t uint32_eq_const_41_0;
    uint32_t uint32_eq_const_42_0;
    uint32_t uint32_eq_const_43_0;
    uint32_t uint32_eq_const_44_0;
    uint32_t uint32_eq_const_45_0;
    uint32_t uint32_eq_const_46_0;
    uint32_t uint32_eq_const_47_0;
    uint32_t uint32_eq_const_48_0;
    uint32_t uint32_eq_const_49_0;
    uint32_t uint32_eq_const_50_0;
    uint32_t uint32_eq_const_51_0;
    uint32_t uint32_eq_const_52_0;
    uint32_t uint32_eq_const_53_0;
    uint32_t uint32_eq_const_54_0;
    uint32_t uint32_eq_const_55_0;
    uint32_t uint32_eq_const_56_0;
    uint32_t uint32_eq_const_57_0;
    uint32_t uint32_eq_const_58_0;
    uint32_t uint32_eq_const_59_0;
    uint32_t uint32_eq_const_60_0;
    uint32_t uint32_eq_const_61_0;
    uint32_t uint32_eq_const_62_0;
    uint32_t uint32_eq_const_63_0;
    uint32_t uint32_eq_const_64_0;
    uint32_t uint32_eq_const_65_0;
    uint32_t uint32_eq_const_66_0;
    uint32_t uint32_eq_const_67_0;
    uint32_t uint32_eq_const_68_0;
    uint32_t uint32_eq_const_69_0;
    uint32_t uint32_eq_const_70_0;
    uint32_t uint32_eq_const_71_0;
    uint32_t uint32_eq_const_72_0;
    uint32_t uint32_eq_const_73_0;
    uint32_t uint32_eq_const_74_0;
    uint32_t uint32_eq_const_75_0;
    uint32_t uint32_eq_const_76_0;
    uint32_t uint32_eq_const_77_0;
    uint32_t uint32_eq_const_78_0;
    uint32_t uint32_eq_const_79_0;
    uint32_t uint32_eq_const_80_0;
    uint32_t uint32_eq_const_81_0;
    uint32_t uint32_eq_const_82_0;
    uint32_t uint32_eq_const_83_0;
    uint32_t uint32_eq_const_84_0;
    uint32_t uint32_eq_const_85_0;
    uint32_t uint32_eq_const_86_0;
    uint32_t uint32_eq_const_87_0;
    uint32_t uint32_eq_const_88_0;
    uint32_t uint32_eq_const_89_0;
    uint32_t uint32_eq_const_90_0;
    uint32_t uint32_eq_const_91_0;
    uint32_t uint32_eq_const_92_0;
    uint32_t uint32_eq_const_93_0;
    uint32_t uint32_eq_const_94_0;
    uint32_t uint32_eq_const_95_0;
    uint32_t uint32_eq_const_96_0;
    uint32_t uint32_eq_const_97_0;
    uint32_t uint32_eq_const_98_0;
    uint32_t uint32_eq_const_99_0;
    uint32_t uint32_eq_const_100_0;
    uint32_t uint32_eq_const_101_0;
    uint32_t uint32_eq_const_102_0;
    uint32_t uint32_eq_const_103_0;
    uint32_t uint32_eq_const_104_0;
    uint32_t uint32_eq_const_105_0;
    uint32_t uint32_eq_const_106_0;
    uint32_t uint32_eq_const_107_0;
    uint32_t uint32_eq_const_108_0;
    uint32_t uint32_eq_const_109_0;
    uint32_t uint32_eq_const_110_0;
    uint32_t uint32_eq_const_111_0;
    uint32_t uint32_eq_const_112_0;
    uint32_t uint32_eq_const_113_0;
    uint32_t uint32_eq_const_114_0;
    uint32_t uint32_eq_const_115_0;
    uint32_t uint32_eq_const_116_0;
    uint32_t uint32_eq_const_117_0;
    uint32_t uint32_eq_const_118_0;
    uint32_t uint32_eq_const_119_0;
    uint32_t uint32_eq_const_120_0;
    uint32_t uint32_eq_const_121_0;
    uint32_t uint32_eq_const_122_0;
    uint32_t uint32_eq_const_123_0;
    uint32_t uint32_eq_const_124_0;
    uint32_t uint32_eq_const_125_0;
    uint32_t uint32_eq_const_126_0;
    uint32_t uint32_eq_const_127_0;

    if (size < 512)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_22_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_28_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_31_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_32_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_33_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_38_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_39_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_41_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_42_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_43_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_44_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_45_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_51_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_53_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_54_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_55_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_56_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_59_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_60_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_61_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_63_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_64_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_65_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_66_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_67_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_68_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_69_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_70_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_71_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_72_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_73_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_74_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_75_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_76_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_77_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_78_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_79_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_80_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_81_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_82_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_83_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_84_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_85_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_86_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_87_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_88_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_89_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_90_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_91_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_92_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_93_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_94_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_95_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_96_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_97_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_98_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_99_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_100_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_101_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_102_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_103_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_104_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_105_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_106_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_107_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_108_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_109_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_110_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_111_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_112_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_113_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_114_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_115_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_116_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_117_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_118_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_119_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_120_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_121_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_122_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_123_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_124_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_125_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_126_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_127_0, &data[i], 4);
    i += 4;


    if (uint32_eq_const_0_0 == 2608837442)
    if (uint32_eq_const_1_0 == 2964863195)
    if (uint32_eq_const_2_0 == 3508342625)
    if (uint32_eq_const_3_0 == 1116961728)
    if (uint32_eq_const_4_0 == 1727631244)
    if (uint32_eq_const_5_0 == 738343472)
    if (uint32_eq_const_6_0 == 1174663238)
    if (uint32_eq_const_7_0 == 326641186)
    if (uint32_eq_const_8_0 == 1504384311)
    if (uint32_eq_const_9_0 == 2693650331)
    if (uint32_eq_const_10_0 == 2438029353)
    if (uint32_eq_const_11_0 == 257049932)
    if (uint32_eq_const_12_0 == 1358259664)
    if (uint32_eq_const_13_0 == 2381312326)
    if (uint32_eq_const_14_0 == 4213521316)
    if (uint32_eq_const_15_0 == 2080811512)
    if (uint32_eq_const_16_0 == 1944183873)
    if (uint32_eq_const_17_0 == 1036322321)
    if (uint32_eq_const_18_0 == 2456593773)
    if (uint32_eq_const_19_0 == 3353018533)
    if (uint32_eq_const_20_0 == 928006079)
    if (uint32_eq_const_21_0 == 4145107748)
    if (uint32_eq_const_22_0 == 815028479)
    if (uint32_eq_const_23_0 == 3035069080)
    if (uint32_eq_const_24_0 == 3492385018)
    if (uint32_eq_const_25_0 == 2220131397)
    if (uint32_eq_const_26_0 == 1820397424)
    if (uint32_eq_const_27_0 == 1692731312)
    if (uint32_eq_const_28_0 == 1227523742)
    if (uint32_eq_const_29_0 == 3107124672)
    if (uint32_eq_const_30_0 == 964686964)
    if (uint32_eq_const_31_0 == 2656705613)
    if (uint32_eq_const_32_0 == 3524698738)
    if (uint32_eq_const_33_0 == 2664858592)
    if (uint32_eq_const_34_0 == 320940649)
    if (uint32_eq_const_35_0 == 40373257)
    if (uint32_eq_const_36_0 == 107381926)
    if (uint32_eq_const_37_0 == 4033407796)
    if (uint32_eq_const_38_0 == 53370644)
    if (uint32_eq_const_39_0 == 3501912336)
    if (uint32_eq_const_40_0 == 3653454087)
    if (uint32_eq_const_41_0 == 2605300023)
    if (uint32_eq_const_42_0 == 2200924053)
    if (uint32_eq_const_43_0 == 1163797786)
    if (uint32_eq_const_44_0 == 2430661580)
    if (uint32_eq_const_45_0 == 149016017)
    if (uint32_eq_const_46_0 == 925834581)
    if (uint32_eq_const_47_0 == 2457291192)
    if (uint32_eq_const_48_0 == 2911497533)
    if (uint32_eq_const_49_0 == 305556185)
    if (uint32_eq_const_50_0 == 3283211134)
    if (uint32_eq_const_51_0 == 4129939563)
    if (uint32_eq_const_52_0 == 4243427070)
    if (uint32_eq_const_53_0 == 2677920799)
    if (uint32_eq_const_54_0 == 2366666942)
    if (uint32_eq_const_55_0 == 1931834386)
    if (uint32_eq_const_56_0 == 126074793)
    if (uint32_eq_const_57_0 == 557285748)
    if (uint32_eq_const_58_0 == 44652331)
    if (uint32_eq_const_59_0 == 1084248419)
    if (uint32_eq_const_60_0 == 4195852359)
    if (uint32_eq_const_61_0 == 1057611182)
    if (uint32_eq_const_62_0 == 882445847)
    if (uint32_eq_const_63_0 == 482397653)
    if (uint32_eq_const_64_0 == 3217770713)
    if (uint32_eq_const_65_0 == 1508350003)
    if (uint32_eq_const_66_0 == 3605895204)
    if (uint32_eq_const_67_0 == 1253515867)
    if (uint32_eq_const_68_0 == 1831244657)
    if (uint32_eq_const_69_0 == 3095299226)
    if (uint32_eq_const_70_0 == 2173001453)
    if (uint32_eq_const_71_0 == 738841139)
    if (uint32_eq_const_72_0 == 1283652119)
    if (uint32_eq_const_73_0 == 2251426823)
    if (uint32_eq_const_74_0 == 4027342863)
    if (uint32_eq_const_75_0 == 316056488)
    if (uint32_eq_const_76_0 == 3563487975)
    if (uint32_eq_const_77_0 == 463678736)
    if (uint32_eq_const_78_0 == 1103716721)
    if (uint32_eq_const_79_0 == 554314242)
    if (uint32_eq_const_80_0 == 2426387618)
    if (uint32_eq_const_81_0 == 1661471971)
    if (uint32_eq_const_82_0 == 3173856449)
    if (uint32_eq_const_83_0 == 3335510992)
    if (uint32_eq_const_84_0 == 2402601687)
    if (uint32_eq_const_85_0 == 2360677893)
    if (uint32_eq_const_86_0 == 1733693208)
    if (uint32_eq_const_87_0 == 3099376963)
    if (uint32_eq_const_88_0 == 846692950)
    if (uint32_eq_const_89_0 == 2994318394)
    if (uint32_eq_const_90_0 == 3556305127)
    if (uint32_eq_const_91_0 == 74881015)
    if (uint32_eq_const_92_0 == 1641059973)
    if (uint32_eq_const_93_0 == 2058512467)
    if (uint32_eq_const_94_0 == 3999463059)
    if (uint32_eq_const_95_0 == 1088012871)
    if (uint32_eq_const_96_0 == 4078163188)
    if (uint32_eq_const_97_0 == 1177742820)
    if (uint32_eq_const_98_0 == 545598070)
    if (uint32_eq_const_99_0 == 3034544786)
    if (uint32_eq_const_100_0 == 3463410193)
    if (uint32_eq_const_101_0 == 4134094607)
    if (uint32_eq_const_102_0 == 691784256)
    if (uint32_eq_const_103_0 == 3066481889)
    if (uint32_eq_const_104_0 == 3209193077)
    if (uint32_eq_const_105_0 == 3814512734)
    if (uint32_eq_const_106_0 == 658772978)
    if (uint32_eq_const_107_0 == 1933708631)
    if (uint32_eq_const_108_0 == 479582616)
    if (uint32_eq_const_109_0 == 728424311)
    if (uint32_eq_const_110_0 == 3666997555)
    if (uint32_eq_const_111_0 == 3265978249)
    if (uint32_eq_const_112_0 == 1938661612)
    if (uint32_eq_const_113_0 == 551715939)
    if (uint32_eq_const_114_0 == 3791109202)
    if (uint32_eq_const_115_0 == 2961100747)
    if (uint32_eq_const_116_0 == 666094023)
    if (uint32_eq_const_117_0 == 1004697936)
    if (uint32_eq_const_118_0 == 3344045546)
    if (uint32_eq_const_119_0 == 3752229679)
    if (uint32_eq_const_120_0 == 2342467457)
    if (uint32_eq_const_121_0 == 2702847035)
    if (uint32_eq_const_122_0 == 11126654)
    if (uint32_eq_const_123_0 == 71911310)
    if (uint32_eq_const_124_0 == 1308970862)
    if (uint32_eq_const_125_0 == 5277252)
    if (uint32_eq_const_126_0 == 2835200035)
    if (uint32_eq_const_127_0 == 1110421022)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
