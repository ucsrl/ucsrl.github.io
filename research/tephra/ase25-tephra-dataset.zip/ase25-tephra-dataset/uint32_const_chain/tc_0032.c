#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint32_t uint32_eq_const_11_0;
    uint32_t uint32_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint32_t uint32_eq_const_14_0;
    uint32_t uint32_eq_const_15_0;
    uint32_t uint32_eq_const_16_0;
    uint32_t uint32_eq_const_17_0;
    uint32_t uint32_eq_const_18_0;
    uint32_t uint32_eq_const_19_0;
    uint32_t uint32_eq_const_20_0;
    uint32_t uint32_eq_const_21_0;
    uint32_t uint32_eq_const_22_0;
    uint32_t uint32_eq_const_23_0;
    uint32_t uint32_eq_const_24_0;
    uint32_t uint32_eq_const_25_0;
    uint32_t uint32_eq_const_26_0;
    uint32_t uint32_eq_const_27_0;
    uint32_t uint32_eq_const_28_0;
    uint32_t uint32_eq_const_29_0;
    uint32_t uint32_eq_const_30_0;
    uint32_t uint32_eq_const_31_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_22_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_28_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_31_0, &data[i], 4);
    i += 4;


    if (uint32_eq_const_0_0 == 431520814)
    if (uint32_eq_const_1_0 == 3935451797)
    if (uint32_eq_const_2_0 == 868367195)
    if (uint32_eq_const_3_0 == 2418024668)
    if (uint32_eq_const_4_0 == 2412487183)
    if (uint32_eq_const_5_0 == 344809296)
    if (uint32_eq_const_6_0 == 1790497094)
    if (uint32_eq_const_7_0 == 2405800060)
    if (uint32_eq_const_8_0 == 430632067)
    if (uint32_eq_const_9_0 == 2623521067)
    if (uint32_eq_const_10_0 == 3952993713)
    if (uint32_eq_const_11_0 == 144781034)
    if (uint32_eq_const_12_0 == 770630703)
    if (uint32_eq_const_13_0 == 4284061577)
    if (uint32_eq_const_14_0 == 3184821903)
    if (uint32_eq_const_15_0 == 271378060)
    if (uint32_eq_const_16_0 == 1369605549)
    if (uint32_eq_const_17_0 == 2714373378)
    if (uint32_eq_const_18_0 == 3125181172)
    if (uint32_eq_const_19_0 == 123482519)
    if (uint32_eq_const_20_0 == 3489910528)
    if (uint32_eq_const_21_0 == 1651891897)
    if (uint32_eq_const_22_0 == 3645970062)
    if (uint32_eq_const_23_0 == 2196511576)
    if (uint32_eq_const_24_0 == 3491322827)
    if (uint32_eq_const_25_0 == 4245785592)
    if (uint32_eq_const_26_0 == 2361925580)
    if (uint32_eq_const_27_0 == 52429004)
    if (uint32_eq_const_28_0 == 665784713)
    if (uint32_eq_const_29_0 == 580982950)
    if (uint32_eq_const_30_0 == 2898313980)
    if (uint32_eq_const_31_0 == 2962020370)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
