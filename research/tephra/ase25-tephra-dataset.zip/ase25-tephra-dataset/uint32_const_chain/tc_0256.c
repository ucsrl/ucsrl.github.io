#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint32_t uint32_eq_const_11_0;
    uint32_t uint32_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint32_t uint32_eq_const_14_0;
    uint32_t uint32_eq_const_15_0;
    uint32_t uint32_eq_const_16_0;
    uint32_t uint32_eq_const_17_0;
    uint32_t uint32_eq_const_18_0;
    uint32_t uint32_eq_const_19_0;
    uint32_t uint32_eq_const_20_0;
    uint32_t uint32_eq_const_21_0;
    uint32_t uint32_eq_const_22_0;
    uint32_t uint32_eq_const_23_0;
    uint32_t uint32_eq_const_24_0;
    uint32_t uint32_eq_const_25_0;
    uint32_t uint32_eq_const_26_0;
    uint32_t uint32_eq_const_27_0;
    uint32_t uint32_eq_const_28_0;
    uint32_t uint32_eq_const_29_0;
    uint32_t uint32_eq_const_30_0;
    uint32_t uint32_eq_const_31_0;
    uint32_t uint32_eq_const_32_0;
    uint32_t uint32_eq_const_33_0;
    uint32_t uint32_eq_const_34_0;
    uint32_t uint32_eq_const_35_0;
    uint32_t uint32_eq_const_36_0;
    uint32_t uint32_eq_const_37_0;
    uint32_t uint32_eq_const_38_0;
    uint32_t uint32_eq_const_39_0;
    uint32_t uint32_eq_const_40_0;
    uint32_t uint32_eq_const_41_0;
    uint32_t uint32_eq_const_42_0;
    uint32_t uint32_eq_const_43_0;
    uint32_t uint32_eq_const_44_0;
    uint32_t uint32_eq_const_45_0;
    uint32_t uint32_eq_const_46_0;
    uint32_t uint32_eq_const_47_0;
    uint32_t uint32_eq_const_48_0;
    uint32_t uint32_eq_const_49_0;
    uint32_t uint32_eq_const_50_0;
    uint32_t uint32_eq_const_51_0;
    uint32_t uint32_eq_const_52_0;
    uint32_t uint32_eq_const_53_0;
    uint32_t uint32_eq_const_54_0;
    uint32_t uint32_eq_const_55_0;
    uint32_t uint32_eq_const_56_0;
    uint32_t uint32_eq_const_57_0;
    uint32_t uint32_eq_const_58_0;
    uint32_t uint32_eq_const_59_0;
    uint32_t uint32_eq_const_60_0;
    uint32_t uint32_eq_const_61_0;
    uint32_t uint32_eq_const_62_0;
    uint32_t uint32_eq_const_63_0;
    uint32_t uint32_eq_const_64_0;
    uint32_t uint32_eq_const_65_0;
    uint32_t uint32_eq_const_66_0;
    uint32_t uint32_eq_const_67_0;
    uint32_t uint32_eq_const_68_0;
    uint32_t uint32_eq_const_69_0;
    uint32_t uint32_eq_const_70_0;
    uint32_t uint32_eq_const_71_0;
    uint32_t uint32_eq_const_72_0;
    uint32_t uint32_eq_const_73_0;
    uint32_t uint32_eq_const_74_0;
    uint32_t uint32_eq_const_75_0;
    uint32_t uint32_eq_const_76_0;
    uint32_t uint32_eq_const_77_0;
    uint32_t uint32_eq_const_78_0;
    uint32_t uint32_eq_const_79_0;
    uint32_t uint32_eq_const_80_0;
    uint32_t uint32_eq_const_81_0;
    uint32_t uint32_eq_const_82_0;
    uint32_t uint32_eq_const_83_0;
    uint32_t uint32_eq_const_84_0;
    uint32_t uint32_eq_const_85_0;
    uint32_t uint32_eq_const_86_0;
    uint32_t uint32_eq_const_87_0;
    uint32_t uint32_eq_const_88_0;
    uint32_t uint32_eq_const_89_0;
    uint32_t uint32_eq_const_90_0;
    uint32_t uint32_eq_const_91_0;
    uint32_t uint32_eq_const_92_0;
    uint32_t uint32_eq_const_93_0;
    uint32_t uint32_eq_const_94_0;
    uint32_t uint32_eq_const_95_0;
    uint32_t uint32_eq_const_96_0;
    uint32_t uint32_eq_const_97_0;
    uint32_t uint32_eq_const_98_0;
    uint32_t uint32_eq_const_99_0;
    uint32_t uint32_eq_const_100_0;
    uint32_t uint32_eq_const_101_0;
    uint32_t uint32_eq_const_102_0;
    uint32_t uint32_eq_const_103_0;
    uint32_t uint32_eq_const_104_0;
    uint32_t uint32_eq_const_105_0;
    uint32_t uint32_eq_const_106_0;
    uint32_t uint32_eq_const_107_0;
    uint32_t uint32_eq_const_108_0;
    uint32_t uint32_eq_const_109_0;
    uint32_t uint32_eq_const_110_0;
    uint32_t uint32_eq_const_111_0;
    uint32_t uint32_eq_const_112_0;
    uint32_t uint32_eq_const_113_0;
    uint32_t uint32_eq_const_114_0;
    uint32_t uint32_eq_const_115_0;
    uint32_t uint32_eq_const_116_0;
    uint32_t uint32_eq_const_117_0;
    uint32_t uint32_eq_const_118_0;
    uint32_t uint32_eq_const_119_0;
    uint32_t uint32_eq_const_120_0;
    uint32_t uint32_eq_const_121_0;
    uint32_t uint32_eq_const_122_0;
    uint32_t uint32_eq_const_123_0;
    uint32_t uint32_eq_const_124_0;
    uint32_t uint32_eq_const_125_0;
    uint32_t uint32_eq_const_126_0;
    uint32_t uint32_eq_const_127_0;
    uint32_t uint32_eq_const_128_0;
    uint32_t uint32_eq_const_129_0;
    uint32_t uint32_eq_const_130_0;
    uint32_t uint32_eq_const_131_0;
    uint32_t uint32_eq_const_132_0;
    uint32_t uint32_eq_const_133_0;
    uint32_t uint32_eq_const_134_0;
    uint32_t uint32_eq_const_135_0;
    uint32_t uint32_eq_const_136_0;
    uint32_t uint32_eq_const_137_0;
    uint32_t uint32_eq_const_138_0;
    uint32_t uint32_eq_const_139_0;
    uint32_t uint32_eq_const_140_0;
    uint32_t uint32_eq_const_141_0;
    uint32_t uint32_eq_const_142_0;
    uint32_t uint32_eq_const_143_0;
    uint32_t uint32_eq_const_144_0;
    uint32_t uint32_eq_const_145_0;
    uint32_t uint32_eq_const_146_0;
    uint32_t uint32_eq_const_147_0;
    uint32_t uint32_eq_const_148_0;
    uint32_t uint32_eq_const_149_0;
    uint32_t uint32_eq_const_150_0;
    uint32_t uint32_eq_const_151_0;
    uint32_t uint32_eq_const_152_0;
    uint32_t uint32_eq_const_153_0;
    uint32_t uint32_eq_const_154_0;
    uint32_t uint32_eq_const_155_0;
    uint32_t uint32_eq_const_156_0;
    uint32_t uint32_eq_const_157_0;
    uint32_t uint32_eq_const_158_0;
    uint32_t uint32_eq_const_159_0;
    uint32_t uint32_eq_const_160_0;
    uint32_t uint32_eq_const_161_0;
    uint32_t uint32_eq_const_162_0;
    uint32_t uint32_eq_const_163_0;
    uint32_t uint32_eq_const_164_0;
    uint32_t uint32_eq_const_165_0;
    uint32_t uint32_eq_const_166_0;
    uint32_t uint32_eq_const_167_0;
    uint32_t uint32_eq_const_168_0;
    uint32_t uint32_eq_const_169_0;
    uint32_t uint32_eq_const_170_0;
    uint32_t uint32_eq_const_171_0;
    uint32_t uint32_eq_const_172_0;
    uint32_t uint32_eq_const_173_0;
    uint32_t uint32_eq_const_174_0;
    uint32_t uint32_eq_const_175_0;
    uint32_t uint32_eq_const_176_0;
    uint32_t uint32_eq_const_177_0;
    uint32_t uint32_eq_const_178_0;
    uint32_t uint32_eq_const_179_0;
    uint32_t uint32_eq_const_180_0;
    uint32_t uint32_eq_const_181_0;
    uint32_t uint32_eq_const_182_0;
    uint32_t uint32_eq_const_183_0;
    uint32_t uint32_eq_const_184_0;
    uint32_t uint32_eq_const_185_0;
    uint32_t uint32_eq_const_186_0;
    uint32_t uint32_eq_const_187_0;
    uint32_t uint32_eq_const_188_0;
    uint32_t uint32_eq_const_189_0;
    uint32_t uint32_eq_const_190_0;
    uint32_t uint32_eq_const_191_0;
    uint32_t uint32_eq_const_192_0;
    uint32_t uint32_eq_const_193_0;
    uint32_t uint32_eq_const_194_0;
    uint32_t uint32_eq_const_195_0;
    uint32_t uint32_eq_const_196_0;
    uint32_t uint32_eq_const_197_0;
    uint32_t uint32_eq_const_198_0;
    uint32_t uint32_eq_const_199_0;
    uint32_t uint32_eq_const_200_0;
    uint32_t uint32_eq_const_201_0;
    uint32_t uint32_eq_const_202_0;
    uint32_t uint32_eq_const_203_0;
    uint32_t uint32_eq_const_204_0;
    uint32_t uint32_eq_const_205_0;
    uint32_t uint32_eq_const_206_0;
    uint32_t uint32_eq_const_207_0;
    uint32_t uint32_eq_const_208_0;
    uint32_t uint32_eq_const_209_0;
    uint32_t uint32_eq_const_210_0;
    uint32_t uint32_eq_const_211_0;
    uint32_t uint32_eq_const_212_0;
    uint32_t uint32_eq_const_213_0;
    uint32_t uint32_eq_const_214_0;
    uint32_t uint32_eq_const_215_0;
    uint32_t uint32_eq_const_216_0;
    uint32_t uint32_eq_const_217_0;
    uint32_t uint32_eq_const_218_0;
    uint32_t uint32_eq_const_219_0;
    uint32_t uint32_eq_const_220_0;
    uint32_t uint32_eq_const_221_0;
    uint32_t uint32_eq_const_222_0;
    uint32_t uint32_eq_const_223_0;
    uint32_t uint32_eq_const_224_0;
    uint32_t uint32_eq_const_225_0;
    uint32_t uint32_eq_const_226_0;
    uint32_t uint32_eq_const_227_0;
    uint32_t uint32_eq_const_228_0;
    uint32_t uint32_eq_const_229_0;
    uint32_t uint32_eq_const_230_0;
    uint32_t uint32_eq_const_231_0;
    uint32_t uint32_eq_const_232_0;
    uint32_t uint32_eq_const_233_0;
    uint32_t uint32_eq_const_234_0;
    uint32_t uint32_eq_const_235_0;
    uint32_t uint32_eq_const_236_0;
    uint32_t uint32_eq_const_237_0;
    uint32_t uint32_eq_const_238_0;
    uint32_t uint32_eq_const_239_0;
    uint32_t uint32_eq_const_240_0;
    uint32_t uint32_eq_const_241_0;
    uint32_t uint32_eq_const_242_0;
    uint32_t uint32_eq_const_243_0;
    uint32_t uint32_eq_const_244_0;
    uint32_t uint32_eq_const_245_0;
    uint32_t uint32_eq_const_246_0;
    uint32_t uint32_eq_const_247_0;
    uint32_t uint32_eq_const_248_0;
    uint32_t uint32_eq_const_249_0;
    uint32_t uint32_eq_const_250_0;
    uint32_t uint32_eq_const_251_0;
    uint32_t uint32_eq_const_252_0;
    uint32_t uint32_eq_const_253_0;
    uint32_t uint32_eq_const_254_0;
    uint32_t uint32_eq_const_255_0;

    if (size < 1024)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_22_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_28_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_31_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_32_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_33_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_38_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_39_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_41_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_42_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_43_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_44_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_45_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_51_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_53_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_54_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_55_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_56_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_59_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_60_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_61_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_63_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_64_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_65_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_66_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_67_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_68_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_69_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_70_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_71_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_72_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_73_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_74_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_75_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_76_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_77_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_78_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_79_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_80_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_81_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_82_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_83_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_84_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_85_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_86_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_87_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_88_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_89_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_90_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_91_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_92_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_93_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_94_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_95_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_96_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_97_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_98_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_99_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_100_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_101_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_102_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_103_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_104_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_105_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_106_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_107_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_108_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_109_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_110_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_111_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_112_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_113_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_114_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_115_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_116_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_117_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_118_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_119_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_120_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_121_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_122_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_123_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_124_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_125_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_126_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_127_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_128_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_129_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_130_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_131_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_132_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_133_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_134_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_135_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_136_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_137_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_138_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_139_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_140_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_141_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_142_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_143_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_144_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_145_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_146_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_147_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_148_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_149_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_150_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_151_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_152_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_153_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_154_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_155_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_156_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_157_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_158_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_159_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_160_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_161_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_162_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_163_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_164_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_165_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_166_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_167_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_168_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_169_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_170_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_171_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_172_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_173_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_174_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_175_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_176_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_177_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_178_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_179_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_180_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_181_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_182_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_183_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_184_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_185_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_186_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_187_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_188_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_189_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_190_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_191_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_192_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_193_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_194_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_195_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_196_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_197_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_198_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_199_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_200_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_201_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_202_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_203_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_204_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_205_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_206_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_207_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_208_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_209_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_210_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_211_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_212_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_213_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_214_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_215_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_216_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_217_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_218_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_219_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_220_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_221_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_222_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_223_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_224_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_225_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_226_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_227_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_228_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_229_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_230_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_231_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_232_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_233_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_234_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_235_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_236_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_237_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_238_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_239_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_240_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_241_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_242_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_243_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_244_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_245_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_246_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_247_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_248_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_249_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_250_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_251_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_252_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_253_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_254_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_255_0, &data[i], 4);
    i += 4;


    if (uint32_eq_const_0_0 == 2637887078)
    if (uint32_eq_const_1_0 == 1825830971)
    if (uint32_eq_const_2_0 == 1648235598)
    if (uint32_eq_const_3_0 == 1501807936)
    if (uint32_eq_const_4_0 == 161655598)
    if (uint32_eq_const_5_0 == 395051402)
    if (uint32_eq_const_6_0 == 383931229)
    if (uint32_eq_const_7_0 == 3807199696)
    if (uint32_eq_const_8_0 == 2198764979)
    if (uint32_eq_const_9_0 == 2054068528)
    if (uint32_eq_const_10_0 == 644733378)
    if (uint32_eq_const_11_0 == 282043249)
    if (uint32_eq_const_12_0 == 1876958295)
    if (uint32_eq_const_13_0 == 4224139240)
    if (uint32_eq_const_14_0 == 3425524100)
    if (uint32_eq_const_15_0 == 1455416161)
    if (uint32_eq_const_16_0 == 3321267732)
    if (uint32_eq_const_17_0 == 3270288557)
    if (uint32_eq_const_18_0 == 2119227654)
    if (uint32_eq_const_19_0 == 3395315275)
    if (uint32_eq_const_20_0 == 1852708641)
    if (uint32_eq_const_21_0 == 3531785436)
    if (uint32_eq_const_22_0 == 2018511044)
    if (uint32_eq_const_23_0 == 2178197345)
    if (uint32_eq_const_24_0 == 3081085959)
    if (uint32_eq_const_25_0 == 2947587583)
    if (uint32_eq_const_26_0 == 2564073024)
    if (uint32_eq_const_27_0 == 1892773142)
    if (uint32_eq_const_28_0 == 3541739714)
    if (uint32_eq_const_29_0 == 1261136895)
    if (uint32_eq_const_30_0 == 2547839390)
    if (uint32_eq_const_31_0 == 2773194180)
    if (uint32_eq_const_32_0 == 3169747776)
    if (uint32_eq_const_33_0 == 3677977415)
    if (uint32_eq_const_34_0 == 3188208096)
    if (uint32_eq_const_35_0 == 587689190)
    if (uint32_eq_const_36_0 == 321306656)
    if (uint32_eq_const_37_0 == 1477347713)
    if (uint32_eq_const_38_0 == 2990491809)
    if (uint32_eq_const_39_0 == 2206897354)
    if (uint32_eq_const_40_0 == 1392146343)
    if (uint32_eq_const_41_0 == 1445180733)
    if (uint32_eq_const_42_0 == 2804635703)
    if (uint32_eq_const_43_0 == 3996287050)
    if (uint32_eq_const_44_0 == 2864626298)
    if (uint32_eq_const_45_0 == 208469379)
    if (uint32_eq_const_46_0 == 774665843)
    if (uint32_eq_const_47_0 == 4067522932)
    if (uint32_eq_const_48_0 == 256118096)
    if (uint32_eq_const_49_0 == 1854821774)
    if (uint32_eq_const_50_0 == 969044526)
    if (uint32_eq_const_51_0 == 1282685386)
    if (uint32_eq_const_52_0 == 2344023685)
    if (uint32_eq_const_53_0 == 1701986732)
    if (uint32_eq_const_54_0 == 1704568783)
    if (uint32_eq_const_55_0 == 2729579887)
    if (uint32_eq_const_56_0 == 3545602426)
    if (uint32_eq_const_57_0 == 1524894178)
    if (uint32_eq_const_58_0 == 1856890204)
    if (uint32_eq_const_59_0 == 3643388069)
    if (uint32_eq_const_60_0 == 4102841174)
    if (uint32_eq_const_61_0 == 2131720618)
    if (uint32_eq_const_62_0 == 3795148462)
    if (uint32_eq_const_63_0 == 2907458102)
    if (uint32_eq_const_64_0 == 2907424950)
    if (uint32_eq_const_65_0 == 1762144435)
    if (uint32_eq_const_66_0 == 1850061545)
    if (uint32_eq_const_67_0 == 3956904761)
    if (uint32_eq_const_68_0 == 1219039171)
    if (uint32_eq_const_69_0 == 4122641273)
    if (uint32_eq_const_70_0 == 3949264906)
    if (uint32_eq_const_71_0 == 3090028246)
    if (uint32_eq_const_72_0 == 505163698)
    if (uint32_eq_const_73_0 == 2464672543)
    if (uint32_eq_const_74_0 == 712575095)
    if (uint32_eq_const_75_0 == 180761972)
    if (uint32_eq_const_76_0 == 3270294209)
    if (uint32_eq_const_77_0 == 1980827511)
    if (uint32_eq_const_78_0 == 3469108703)
    if (uint32_eq_const_79_0 == 3271010616)
    if (uint32_eq_const_80_0 == 3198147665)
    if (uint32_eq_const_81_0 == 2574200069)
    if (uint32_eq_const_82_0 == 4294037498)
    if (uint32_eq_const_83_0 == 1713611272)
    if (uint32_eq_const_84_0 == 460940328)
    if (uint32_eq_const_85_0 == 3143600197)
    if (uint32_eq_const_86_0 == 2352311914)
    if (uint32_eq_const_87_0 == 3974327423)
    if (uint32_eq_const_88_0 == 2086790080)
    if (uint32_eq_const_89_0 == 115461172)
    if (uint32_eq_const_90_0 == 658259796)
    if (uint32_eq_const_91_0 == 3438389795)
    if (uint32_eq_const_92_0 == 2042878818)
    if (uint32_eq_const_93_0 == 2114745126)
    if (uint32_eq_const_94_0 == 3461712759)
    if (uint32_eq_const_95_0 == 3302103733)
    if (uint32_eq_const_96_0 == 3878810704)
    if (uint32_eq_const_97_0 == 3113783320)
    if (uint32_eq_const_98_0 == 4277299571)
    if (uint32_eq_const_99_0 == 3430544457)
    if (uint32_eq_const_100_0 == 1273516104)
    if (uint32_eq_const_101_0 == 317140706)
    if (uint32_eq_const_102_0 == 1486836687)
    if (uint32_eq_const_103_0 == 4101688380)
    if (uint32_eq_const_104_0 == 1216013330)
    if (uint32_eq_const_105_0 == 3626124179)
    if (uint32_eq_const_106_0 == 2011942134)
    if (uint32_eq_const_107_0 == 3950120570)
    if (uint32_eq_const_108_0 == 3695371260)
    if (uint32_eq_const_109_0 == 3160091863)
    if (uint32_eq_const_110_0 == 1408373379)
    if (uint32_eq_const_111_0 == 1472136993)
    if (uint32_eq_const_112_0 == 2103263485)
    if (uint32_eq_const_113_0 == 1338557190)
    if (uint32_eq_const_114_0 == 745595944)
    if (uint32_eq_const_115_0 == 834763664)
    if (uint32_eq_const_116_0 == 3192665474)
    if (uint32_eq_const_117_0 == 4001822993)
    if (uint32_eq_const_118_0 == 581522950)
    if (uint32_eq_const_119_0 == 3508719770)
    if (uint32_eq_const_120_0 == 3431850452)
    if (uint32_eq_const_121_0 == 1048186147)
    if (uint32_eq_const_122_0 == 3950163709)
    if (uint32_eq_const_123_0 == 1844168101)
    if (uint32_eq_const_124_0 == 1807349492)
    if (uint32_eq_const_125_0 == 121063676)
    if (uint32_eq_const_126_0 == 2771812970)
    if (uint32_eq_const_127_0 == 1818803066)
    if (uint32_eq_const_128_0 == 821589333)
    if (uint32_eq_const_129_0 == 3910488741)
    if (uint32_eq_const_130_0 == 3234228228)
    if (uint32_eq_const_131_0 == 3911093524)
    if (uint32_eq_const_132_0 == 2867034223)
    if (uint32_eq_const_133_0 == 986057947)
    if (uint32_eq_const_134_0 == 406740629)
    if (uint32_eq_const_135_0 == 2689726654)
    if (uint32_eq_const_136_0 == 3525710590)
    if (uint32_eq_const_137_0 == 521930525)
    if (uint32_eq_const_138_0 == 3278161872)
    if (uint32_eq_const_139_0 == 2061735814)
    if (uint32_eq_const_140_0 == 2540321678)
    if (uint32_eq_const_141_0 == 3067969219)
    if (uint32_eq_const_142_0 == 4114261609)
    if (uint32_eq_const_143_0 == 3229771676)
    if (uint32_eq_const_144_0 == 2741488063)
    if (uint32_eq_const_145_0 == 751235043)
    if (uint32_eq_const_146_0 == 850256310)
    if (uint32_eq_const_147_0 == 762765936)
    if (uint32_eq_const_148_0 == 1713799575)
    if (uint32_eq_const_149_0 == 1008677929)
    if (uint32_eq_const_150_0 == 2124388874)
    if (uint32_eq_const_151_0 == 4035487324)
    if (uint32_eq_const_152_0 == 1657090339)
    if (uint32_eq_const_153_0 == 3162453244)
    if (uint32_eq_const_154_0 == 2880474616)
    if (uint32_eq_const_155_0 == 3821055961)
    if (uint32_eq_const_156_0 == 1029168213)
    if (uint32_eq_const_157_0 == 2947492619)
    if (uint32_eq_const_158_0 == 3766848994)
    if (uint32_eq_const_159_0 == 688529596)
    if (uint32_eq_const_160_0 == 1890515281)
    if (uint32_eq_const_161_0 == 1220243401)
    if (uint32_eq_const_162_0 == 2138439967)
    if (uint32_eq_const_163_0 == 2985531708)
    if (uint32_eq_const_164_0 == 3122249195)
    if (uint32_eq_const_165_0 == 1705172227)
    if (uint32_eq_const_166_0 == 248937007)
    if (uint32_eq_const_167_0 == 538124443)
    if (uint32_eq_const_168_0 == 964000404)
    if (uint32_eq_const_169_0 == 4282432842)
    if (uint32_eq_const_170_0 == 1934711682)
    if (uint32_eq_const_171_0 == 3654196647)
    if (uint32_eq_const_172_0 == 4229695607)
    if (uint32_eq_const_173_0 == 626281806)
    if (uint32_eq_const_174_0 == 3388967896)
    if (uint32_eq_const_175_0 == 629858024)
    if (uint32_eq_const_176_0 == 696468663)
    if (uint32_eq_const_177_0 == 919063461)
    if (uint32_eq_const_178_0 == 1949514387)
    if (uint32_eq_const_179_0 == 2609066705)
    if (uint32_eq_const_180_0 == 1352638004)
    if (uint32_eq_const_181_0 == 681122188)
    if (uint32_eq_const_182_0 == 1931916347)
    if (uint32_eq_const_183_0 == 1154191833)
    if (uint32_eq_const_184_0 == 1700507827)
    if (uint32_eq_const_185_0 == 3624266636)
    if (uint32_eq_const_186_0 == 100747025)
    if (uint32_eq_const_187_0 == 1279218937)
    if (uint32_eq_const_188_0 == 3585536517)
    if (uint32_eq_const_189_0 == 2531101146)
    if (uint32_eq_const_190_0 == 2565093317)
    if (uint32_eq_const_191_0 == 1012825836)
    if (uint32_eq_const_192_0 == 3193794340)
    if (uint32_eq_const_193_0 == 1528438889)
    if (uint32_eq_const_194_0 == 2012333662)
    if (uint32_eq_const_195_0 == 1666946386)
    if (uint32_eq_const_196_0 == 2932512520)
    if (uint32_eq_const_197_0 == 1025744929)
    if (uint32_eq_const_198_0 == 1702904112)
    if (uint32_eq_const_199_0 == 484182172)
    if (uint32_eq_const_200_0 == 2638813480)
    if (uint32_eq_const_201_0 == 979250938)
    if (uint32_eq_const_202_0 == 652946038)
    if (uint32_eq_const_203_0 == 1865231536)
    if (uint32_eq_const_204_0 == 2741096565)
    if (uint32_eq_const_205_0 == 2212899001)
    if (uint32_eq_const_206_0 == 1471442269)
    if (uint32_eq_const_207_0 == 2683289850)
    if (uint32_eq_const_208_0 == 3683369069)
    if (uint32_eq_const_209_0 == 4221284069)
    if (uint32_eq_const_210_0 == 1458020574)
    if (uint32_eq_const_211_0 == 578554285)
    if (uint32_eq_const_212_0 == 1093607810)
    if (uint32_eq_const_213_0 == 3823094325)
    if (uint32_eq_const_214_0 == 4008795763)
    if (uint32_eq_const_215_0 == 2290120538)
    if (uint32_eq_const_216_0 == 3293412872)
    if (uint32_eq_const_217_0 == 816126494)
    if (uint32_eq_const_218_0 == 1818010678)
    if (uint32_eq_const_219_0 == 3952926924)
    if (uint32_eq_const_220_0 == 3663781438)
    if (uint32_eq_const_221_0 == 1521882546)
    if (uint32_eq_const_222_0 == 875055915)
    if (uint32_eq_const_223_0 == 2633779709)
    if (uint32_eq_const_224_0 == 3057910884)
    if (uint32_eq_const_225_0 == 273865843)
    if (uint32_eq_const_226_0 == 2393279129)
    if (uint32_eq_const_227_0 == 3324984678)
    if (uint32_eq_const_228_0 == 4181047915)
    if (uint32_eq_const_229_0 == 2693305879)
    if (uint32_eq_const_230_0 == 1209568588)
    if (uint32_eq_const_231_0 == 214480058)
    if (uint32_eq_const_232_0 == 524889361)
    if (uint32_eq_const_233_0 == 2296669184)
    if (uint32_eq_const_234_0 == 4235728539)
    if (uint32_eq_const_235_0 == 947884192)
    if (uint32_eq_const_236_0 == 567630390)
    if (uint32_eq_const_237_0 == 526639349)
    if (uint32_eq_const_238_0 == 1612788891)
    if (uint32_eq_const_239_0 == 1373020718)
    if (uint32_eq_const_240_0 == 3400895200)
    if (uint32_eq_const_241_0 == 3972346246)
    if (uint32_eq_const_242_0 == 2605582195)
    if (uint32_eq_const_243_0 == 2911715914)
    if (uint32_eq_const_244_0 == 4218217009)
    if (uint32_eq_const_245_0 == 3986204078)
    if (uint32_eq_const_246_0 == 3667301226)
    if (uint32_eq_const_247_0 == 3747248932)
    if (uint32_eq_const_248_0 == 3145660389)
    if (uint32_eq_const_249_0 == 2595612665)
    if (uint32_eq_const_250_0 == 2330372083)
    if (uint32_eq_const_251_0 == 2629091321)
    if (uint32_eq_const_252_0 == 965707470)
    if (uint32_eq_const_253_0 == 1274461782)
    if (uint32_eq_const_254_0 == 1402720605)
    if (uint32_eq_const_255_0 == 782775881)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
