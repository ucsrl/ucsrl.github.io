#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint32_t uint32_eq_const_11_0;
    uint32_t uint32_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint32_t uint32_eq_const_14_0;
    uint32_t uint32_eq_const_15_0;

    if (size < 64)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_15_0, &data[i], 4);
    i += 4;


    if (uint32_eq_const_0_0 == 1615282602)
    if (uint32_eq_const_1_0 == 3705801544)
    if (uint32_eq_const_2_0 == 2993992985)
    if (uint32_eq_const_3_0 == 687756352)
    if (uint32_eq_const_4_0 == 3436235297)
    if (uint32_eq_const_5_0 == 3115782107)
    if (uint32_eq_const_6_0 == 3413960944)
    if (uint32_eq_const_7_0 == 3535792809)
    if (uint32_eq_const_8_0 == 3651939611)
    if (uint32_eq_const_9_0 == 4230453474)
    if (uint32_eq_const_10_0 == 554594895)
    if (uint32_eq_const_11_0 == 2637517186)
    if (uint32_eq_const_12_0 == 2331629001)
    if (uint32_eq_const_13_0 == 655891942)
    if (uint32_eq_const_14_0 == 2295986479)
    if (uint32_eq_const_15_0 == 2357910128)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
