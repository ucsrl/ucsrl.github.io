#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    int64_t value;
    int64_t eps = 1000000000;
    int64_t bound = 8091213580503458784;

    if (size < sizeof(int64_t))
        return TEPHRA_EXIT_FAILURE;

    memcpy(&value, data, sizeof(int64_t));

    if (value <= (bound + eps))
        if ((bound - eps) <= value)
            BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
