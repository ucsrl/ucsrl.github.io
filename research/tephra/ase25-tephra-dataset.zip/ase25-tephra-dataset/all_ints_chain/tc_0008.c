#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    int64_t int64_eq_const_7_0;

    if (size < 36)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;


    if (int16_eq_const_0_0 == 5863)
    if (int32_eq_const_1_0 == 1199166427)
    if (int32_eq_const_2_0 == 75073767)
    if (int16_eq_const_3_0 == -27872)
    if (int32_eq_const_4_0 == -18170291)
    if (int32_eq_const_5_0 == -1392156947)
    if (uint64_eq_const_6_0 == 9174170212827787346u)
    if (int64_eq_const_7_0 == -5735582471352800382)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
