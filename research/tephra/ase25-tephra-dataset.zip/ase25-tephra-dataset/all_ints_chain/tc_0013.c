#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int8_t int8_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int8_t int8_eq_const_12_0;

    if (size < 38)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_12_0, &data[i], 1);
    i += 1;


    if (int8_eq_const_0_0 == -69)
    if (uint16_eq_const_1_0 == 47705)
    if (int32_eq_const_2_0 == -1285595627)
    if (int16_eq_const_3_0 == 10703)
    if (int32_eq_const_4_0 == -212853721)
    if (uint8_eq_const_5_0 == 100)
    if (uint64_eq_const_6_0 == 15261152831064152163u)
    if (uint32_eq_const_7_0 == 1843658441)
    if (uint8_eq_const_8_0 == 161)
    if (int16_eq_const_9_0 == -22197)
    if (int32_eq_const_10_0 == -473266611)
    if (int32_eq_const_11_0 == -375073853)
    if (int8_eq_const_12_0 == 67)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
