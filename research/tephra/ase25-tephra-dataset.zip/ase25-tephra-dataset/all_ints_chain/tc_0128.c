#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    int16_t int16_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    uint8_t uint8_eq_const_13_0;
    int32_t int32_eq_const_14_0;
    int32_t int32_eq_const_15_0;
    uint8_t uint8_eq_const_16_0;
    int32_t int32_eq_const_17_0;
    uint8_t uint8_eq_const_18_0;
    uint16_t uint16_eq_const_19_0;
    int32_t int32_eq_const_20_0;
    int32_t int32_eq_const_21_0;
    uint8_t uint8_eq_const_22_0;
    uint16_t uint16_eq_const_23_0;
    uint16_t uint16_eq_const_24_0;
    int32_t int32_eq_const_25_0;
    uint64_t uint64_eq_const_26_0;
    int8_t int8_eq_const_27_0;
    int16_t int16_eq_const_28_0;
    uint16_t uint16_eq_const_29_0;
    int16_t int16_eq_const_30_0;
    uint32_t uint32_eq_const_31_0;
    uint16_t uint16_eq_const_32_0;
    int64_t int64_eq_const_33_0;
    int32_t int32_eq_const_34_0;
    int64_t int64_eq_const_35_0;
    uint32_t uint32_eq_const_36_0;
    uint64_t uint64_eq_const_37_0;
    int64_t int64_eq_const_38_0;
    uint64_t uint64_eq_const_39_0;
    int64_t int64_eq_const_40_0;
    int64_t int64_eq_const_41_0;
    uint8_t uint8_eq_const_42_0;
    uint64_t uint64_eq_const_43_0;
    int64_t int64_eq_const_44_0;
    uint16_t uint16_eq_const_45_0;
    uint8_t uint8_eq_const_46_0;
    uint8_t uint8_eq_const_47_0;
    uint32_t uint32_eq_const_48_0;
    int32_t int32_eq_const_49_0;
    int64_t int64_eq_const_50_0;
    int64_t int64_eq_const_51_0;
    int16_t int16_eq_const_52_0;
    uint64_t uint64_eq_const_53_0;
    uint8_t uint8_eq_const_54_0;
    uint8_t uint8_eq_const_55_0;
    int64_t int64_eq_const_56_0;
    uint32_t uint32_eq_const_57_0;
    int16_t int16_eq_const_58_0;
    int8_t int8_eq_const_59_0;
    int16_t int16_eq_const_60_0;
    int32_t int32_eq_const_61_0;
    int32_t int32_eq_const_62_0;
    uint16_t uint16_eq_const_63_0;
    int16_t int16_eq_const_64_0;
    int16_t int16_eq_const_65_0;
    int32_t int32_eq_const_66_0;
    int32_t int32_eq_const_67_0;
    int8_t int8_eq_const_68_0;
    int32_t int32_eq_const_69_0;
    int64_t int64_eq_const_70_0;
    uint8_t uint8_eq_const_71_0;
    uint64_t uint64_eq_const_72_0;
    uint16_t uint16_eq_const_73_0;
    int8_t int8_eq_const_74_0;
    uint32_t uint32_eq_const_75_0;
    uint64_t uint64_eq_const_76_0;
    int16_t int16_eq_const_77_0;
    int16_t int16_eq_const_78_0;
    uint64_t uint64_eq_const_79_0;
    uint64_t uint64_eq_const_80_0;
    uint16_t uint16_eq_const_81_0;
    uint8_t uint8_eq_const_82_0;
    uint16_t uint16_eq_const_83_0;
    uint16_t uint16_eq_const_84_0;
    int64_t int64_eq_const_85_0;
    uint16_t uint16_eq_const_86_0;
    int16_t int16_eq_const_87_0;
    uint64_t uint64_eq_const_88_0;
    int16_t int16_eq_const_89_0;
    uint16_t uint16_eq_const_90_0;
    int32_t int32_eq_const_91_0;
    int8_t int8_eq_const_92_0;
    uint32_t uint32_eq_const_93_0;
    int64_t int64_eq_const_94_0;
    uint32_t uint32_eq_const_95_0;
    int64_t int64_eq_const_96_0;
    uint64_t uint64_eq_const_97_0;
    uint8_t uint8_eq_const_98_0;
    uint64_t uint64_eq_const_99_0;
    uint64_t uint64_eq_const_100_0;
    uint16_t uint16_eq_const_101_0;
    uint8_t uint8_eq_const_102_0;
    uint16_t uint16_eq_const_103_0;
    uint16_t uint16_eq_const_104_0;
    int16_t int16_eq_const_105_0;
    uint16_t uint16_eq_const_106_0;
    int32_t int32_eq_const_107_0;
    int64_t int64_eq_const_108_0;
    int64_t int64_eq_const_109_0;
    uint32_t uint32_eq_const_110_0;
    uint8_t uint8_eq_const_111_0;
    int16_t int16_eq_const_112_0;
    uint8_t uint8_eq_const_113_0;
    int16_t int16_eq_const_114_0;
    uint8_t uint8_eq_const_115_0;
    int16_t int16_eq_const_116_0;
    uint8_t uint8_eq_const_117_0;
    int16_t int16_eq_const_118_0;
    uint8_t uint8_eq_const_119_0;
    uint32_t uint32_eq_const_120_0;
    uint16_t uint16_eq_const_121_0;
    int8_t int8_eq_const_122_0;
    uint64_t uint64_eq_const_123_0;
    uint8_t uint8_eq_const_124_0;
    uint8_t uint8_eq_const_125_0;
    int16_t int16_eq_const_126_0;
    uint32_t uint32_eq_const_127_0;

    if (size < 472)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_31_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_32_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_38_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_52_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_58_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_61_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_63_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_64_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_65_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_66_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_67_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_68_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_69_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_70_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_71_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_73_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_74_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_75_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_76_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_77_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_78_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_79_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_80_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_81_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_82_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_83_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_84_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_86_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_87_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_88_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_89_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_90_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_91_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_92_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_93_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_94_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_95_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_96_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_97_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_98_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_99_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_100_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_101_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_103_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_104_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_105_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_106_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_107_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_108_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_109_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_110_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_111_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_112_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_113_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_114_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_115_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_116_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_117_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_118_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_119_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_120_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_121_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_122_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_123_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_125_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_126_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_127_0, &data[i], 4);
    i += 4;


    if (uint16_eq_const_0_0 == 21873)
    if (uint32_eq_const_1_0 == 604597510)
    if (uint64_eq_const_2_0 == 1017136837562665122u)
    if (int64_eq_const_3_0 == 2456849666535812046)
    if (uint16_eq_const_4_0 == 60776)
    if (int16_eq_const_5_0 == -24847)
    if (uint32_eq_const_6_0 == 4097502264)
    if (int16_eq_const_7_0 == 30893)
    if (int32_eq_const_8_0 == -980259641)
    if (int16_eq_const_9_0 == -14141)
    if (uint16_eq_const_10_0 == 35938)
    if (int16_eq_const_11_0 == 19741)
    if (int16_eq_const_12_0 == 6706)
    if (uint8_eq_const_13_0 == 115)
    if (int32_eq_const_14_0 == 1375019641)
    if (int32_eq_const_15_0 == 1593094748)
    if (uint8_eq_const_16_0 == 83)
    if (int32_eq_const_17_0 == 663296752)
    if (uint8_eq_const_18_0 == 212)
    if (uint16_eq_const_19_0 == 32008)
    if (int32_eq_const_20_0 == 1625123144)
    if (int32_eq_const_21_0 == 543063074)
    if (uint8_eq_const_22_0 == 77)
    if (uint16_eq_const_23_0 == 113)
    if (uint16_eq_const_24_0 == 62474)
    if (int32_eq_const_25_0 == 1500669645)
    if (uint64_eq_const_26_0 == 9697982604901839866u)
    if (int8_eq_const_27_0 == 60)
    if (int16_eq_const_28_0 == -1184)
    if (uint16_eq_const_29_0 == 5726)
    if (int16_eq_const_30_0 == -24670)
    if (uint32_eq_const_31_0 == 208859000)
    if (uint16_eq_const_32_0 == 17160)
    if (int64_eq_const_33_0 == -4766184891970874787)
    if (int32_eq_const_34_0 == -630436341)
    if (int64_eq_const_35_0 == 739798216140304212)
    if (uint32_eq_const_36_0 == 4061827730)
    if (uint64_eq_const_37_0 == 17237084547057325323u)
    if (int64_eq_const_38_0 == 2167645662031867415)
    if (uint64_eq_const_39_0 == 9610133395731386675u)
    if (int64_eq_const_40_0 == -4223423828588998438)
    if (int64_eq_const_41_0 == 2422740510711152349)
    if (uint8_eq_const_42_0 == 10)
    if (uint64_eq_const_43_0 == 15155089147435283757u)
    if (int64_eq_const_44_0 == 3437984455681637929)
    if (uint16_eq_const_45_0 == 18560)
    if (uint8_eq_const_46_0 == 149)
    if (uint8_eq_const_47_0 == 168)
    if (uint32_eq_const_48_0 == 1365954322)
    if (int32_eq_const_49_0 == 1817885507)
    if (int64_eq_const_50_0 == 6791959884616679176)
    if (int64_eq_const_51_0 == -4482203910951103828)
    if (int16_eq_const_52_0 == -29976)
    if (uint64_eq_const_53_0 == 7190112349088566439u)
    if (uint8_eq_const_54_0 == 146)
    if (uint8_eq_const_55_0 == 58)
    if (int64_eq_const_56_0 == 5215387970735799549)
    if (uint32_eq_const_57_0 == 1554800846)
    if (int16_eq_const_58_0 == 1643)
    if (int8_eq_const_59_0 == 27)
    if (int16_eq_const_60_0 == -30950)
    if (int32_eq_const_61_0 == -1313996475)
    if (int32_eq_const_62_0 == -387698792)
    if (uint16_eq_const_63_0 == 30555)
    if (int16_eq_const_64_0 == -269)
    if (int16_eq_const_65_0 == -25474)
    if (int32_eq_const_66_0 == -1191637460)
    if (int32_eq_const_67_0 == 1612939131)
    if (int8_eq_const_68_0 == 76)
    if (int32_eq_const_69_0 == -1315766412)
    if (int64_eq_const_70_0 == 1515638181760015869)
    if (uint8_eq_const_71_0 == 153)
    if (uint64_eq_const_72_0 == 8510728867277167813u)
    if (uint16_eq_const_73_0 == 13903)
    if (int8_eq_const_74_0 == -63)
    if (uint32_eq_const_75_0 == 3756756165)
    if (uint64_eq_const_76_0 == 2002399311664488508u)
    if (int16_eq_const_77_0 == 20166)
    if (int16_eq_const_78_0 == -18868)
    if (uint64_eq_const_79_0 == 12623713280992230427u)
    if (uint64_eq_const_80_0 == 14221298273424944223u)
    if (uint16_eq_const_81_0 == 13447)
    if (uint8_eq_const_82_0 == 115)
    if (uint16_eq_const_83_0 == 6179)
    if (uint16_eq_const_84_0 == 13553)
    if (int64_eq_const_85_0 == -6614095078399997320)
    if (uint16_eq_const_86_0 == 50392)
    if (int16_eq_const_87_0 == 16592)
    if (uint64_eq_const_88_0 == 15521111520898984089u)
    if (int16_eq_const_89_0 == 29637)
    if (uint16_eq_const_90_0 == 13072)
    if (int32_eq_const_91_0 == 1807348448)
    if (int8_eq_const_92_0 == -127)
    if (uint32_eq_const_93_0 == 1336215368)
    if (int64_eq_const_94_0 == -3907227262431739733)
    if (uint32_eq_const_95_0 == 1984102890)
    if (int64_eq_const_96_0 == 6495465380069362080)
    if (uint64_eq_const_97_0 == 17382116915015534273u)
    if (uint8_eq_const_98_0 == 3)
    if (uint64_eq_const_99_0 == 1570489834612602086u)
    if (uint64_eq_const_100_0 == 8555571265937689982u)
    if (uint16_eq_const_101_0 == 48484)
    if (uint8_eq_const_102_0 == 173)
    if (uint16_eq_const_103_0 == 47933)
    if (uint16_eq_const_104_0 == 808)
    if (int16_eq_const_105_0 == -25087)
    if (uint16_eq_const_106_0 == 51195)
    if (int32_eq_const_107_0 == -316237697)
    if (int64_eq_const_108_0 == -1121491754367540375)
    if (int64_eq_const_109_0 == 1554213390337862232)
    if (uint32_eq_const_110_0 == 4016122868)
    if (uint8_eq_const_111_0 == 24)
    if (int16_eq_const_112_0 == 2423)
    if (uint8_eq_const_113_0 == 128)
    if (int16_eq_const_114_0 == 13280)
    if (uint8_eq_const_115_0 == 210)
    if (int16_eq_const_116_0 == 4729)
    if (uint8_eq_const_117_0 == 179)
    if (int16_eq_const_118_0 == -12230)
    if (uint8_eq_const_119_0 == 189)
    if (uint32_eq_const_120_0 == 4123450595)
    if (uint16_eq_const_121_0 == 11488)
    if (int8_eq_const_122_0 == -117)
    if (uint64_eq_const_123_0 == 6874030642419374239u)
    if (uint8_eq_const_124_0 == 226)
    if (uint8_eq_const_125_0 == 210)
    if (int16_eq_const_126_0 == 19707)
    if (uint32_eq_const_127_0 == 1822563104)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
