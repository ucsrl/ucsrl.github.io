#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int8_t int8_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;
    int8_t int8_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;

    if (size < 39)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;


    if (int32_eq_const_0_0 == -1374962945)
    if (int8_eq_const_1_0 == -30)
    if (int16_eq_const_2_0 == -26179)
    if (int32_eq_const_3_0 == 1740061554)
    if (int32_eq_const_4_0 == -2098683559)
    if (uint8_eq_const_5_0 == 101)
    if (uint32_eq_const_6_0 == 4036745800)
    if (uint16_eq_const_7_0 == 43291)
    if (uint16_eq_const_8_0 == 41042)
    if (int16_eq_const_9_0 == 4714)
    if (int16_eq_const_10_0 == -704)
    if (int8_eq_const_11_0 == 24)
    if (int16_eq_const_12_0 == -19600)
    if (uint64_eq_const_13_0 == 12512164188043310904u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
