#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int8_t int8_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    int8_t int8_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;

    if (size < 58)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == 24324)
    if (uint16_eq_const_1_0 == 11064)
    if (int32_eq_const_2_0 == 1015139976)
    if (uint64_eq_const_3_0 == 7772146521936681717u)
    if (uint32_eq_const_4_0 == 1299065518)
    if (int32_eq_const_5_0 == 297149096)
    if (int8_eq_const_6_0 == 81)
    if (uint8_eq_const_7_0 == 255)
    if (int8_eq_const_8_0 == -60)
    if (int32_eq_const_9_0 == -158897856)
    if (int64_eq_const_10_0 == -6075281422498421699)
    if (uint64_eq_const_11_0 == 6570988777809804876u)
    if (int8_eq_const_12_0 == 120)
    if (uint64_eq_const_13_0 == 5064479542225495830u)
    if (uint16_eq_const_14_0 == 20167)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
