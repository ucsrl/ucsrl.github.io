#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int8_t int8_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    int16_t int16_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint8_t uint8_eq_const_14_0;
    uint64_t uint64_eq_const_15_0;
    uint16_t uint16_eq_const_16_0;
    uint64_t uint64_eq_const_17_0;
    uint32_t uint32_eq_const_18_0;
    uint8_t uint8_eq_const_19_0;
    uint32_t uint32_eq_const_20_0;
    int8_t int8_eq_const_21_0;
    int16_t int16_eq_const_22_0;
    int16_t int16_eq_const_23_0;
    uint64_t uint64_eq_const_24_0;
    uint32_t uint32_eq_const_25_0;
    int8_t int8_eq_const_26_0;
    uint64_t uint64_eq_const_27_0;
    uint8_t uint8_eq_const_28_0;
    uint8_t uint8_eq_const_29_0;
    int32_t int32_eq_const_30_0;
    int8_t int8_eq_const_31_0;
    uint32_t uint32_eq_const_32_0;
    int64_t int64_eq_const_33_0;
    int8_t int8_eq_const_34_0;
    uint32_t uint32_eq_const_35_0;
    int64_t int64_eq_const_36_0;
    int8_t int8_eq_const_37_0;
    int32_t int32_eq_const_38_0;
    uint16_t uint16_eq_const_39_0;
    uint32_t uint32_eq_const_40_0;
    uint32_t uint32_eq_const_41_0;
    int8_t int8_eq_const_42_0;
    uint16_t uint16_eq_const_43_0;
    int64_t int64_eq_const_44_0;
    int16_t int16_eq_const_45_0;
    uint32_t uint32_eq_const_46_0;
    int64_t int64_eq_const_47_0;
    uint8_t uint8_eq_const_48_0;
    int32_t int32_eq_const_49_0;
    uint64_t uint64_eq_const_50_0;
    uint64_t uint64_eq_const_51_0;
    int32_t int32_eq_const_52_0;
    uint8_t uint8_eq_const_53_0;
    int8_t int8_eq_const_54_0;
    int8_t int8_eq_const_55_0;
    uint64_t uint64_eq_const_56_0;
    int32_t int32_eq_const_57_0;
    uint64_t uint64_eq_const_58_0;
    uint64_t uint64_eq_const_59_0;
    uint32_t uint32_eq_const_60_0;
    int64_t int64_eq_const_61_0;
    int32_t int32_eq_const_62_0;
    int8_t int8_eq_const_63_0;

    if (size < 258)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_32_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_37_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_38_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_39_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_41_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_43_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_60_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_63_0, &data[i], 1);
    i += 1;


    if (int32_eq_const_0_0 == 883662237)
    if (int32_eq_const_1_0 == -1827289091)
    if (uint8_eq_const_2_0 == 73)
    if (uint64_eq_const_3_0 == 125394308584253450u)
    if (uint16_eq_const_4_0 == 52506)
    if (int64_eq_const_5_0 == -8114866152644498177)
    if (int8_eq_const_6_0 == -48)
    if (uint32_eq_const_7_0 == 89518385)
    if (int16_eq_const_8_0 == -7918)
    if (int32_eq_const_9_0 == 1446878542)
    if (int8_eq_const_10_0 == 115)
    if (int64_eq_const_11_0 == 7265035359609246455)
    if (int64_eq_const_12_0 == 9147231379996706935)
    if (uint32_eq_const_13_0 == 1041122822)
    if (uint8_eq_const_14_0 == 34)
    if (uint64_eq_const_15_0 == 14984523276105907583u)
    if (uint16_eq_const_16_0 == 12250)
    if (uint64_eq_const_17_0 == 3956285290376318524u)
    if (uint32_eq_const_18_0 == 545940026)
    if (uint8_eq_const_19_0 == 51)
    if (uint32_eq_const_20_0 == 3313319614)
    if (int8_eq_const_21_0 == -80)
    if (int16_eq_const_22_0 == 15146)
    if (int16_eq_const_23_0 == 25730)
    if (uint64_eq_const_24_0 == 5889509996700375555u)
    if (uint32_eq_const_25_0 == 1447747032)
    if (int8_eq_const_26_0 == -73)
    if (uint64_eq_const_27_0 == 1789091322169358358u)
    if (uint8_eq_const_28_0 == 240)
    if (uint8_eq_const_29_0 == 98)
    if (int32_eq_const_30_0 == 1345212729)
    if (int8_eq_const_31_0 == -19)
    if (uint32_eq_const_32_0 == 2899338159)
    if (int64_eq_const_33_0 == 7860644771589925238)
    if (int8_eq_const_34_0 == 6)
    if (uint32_eq_const_35_0 == 972894735)
    if (int64_eq_const_36_0 == -450907081498865753)
    if (int8_eq_const_37_0 == -45)
    if (int32_eq_const_38_0 == 673764385)
    if (uint16_eq_const_39_0 == 20882)
    if (uint32_eq_const_40_0 == 3748691108)
    if (uint32_eq_const_41_0 == 2246782988)
    if (int8_eq_const_42_0 == -4)
    if (uint16_eq_const_43_0 == 30606)
    if (int64_eq_const_44_0 == 4904114279958597178)
    if (int16_eq_const_45_0 == -6734)
    if (uint32_eq_const_46_0 == 642853461)
    if (int64_eq_const_47_0 == 2872114299663482858)
    if (uint8_eq_const_48_0 == 239)
    if (int32_eq_const_49_0 == -1990731839)
    if (uint64_eq_const_50_0 == 18125938369758664150u)
    if (uint64_eq_const_51_0 == 10404789746599914779u)
    if (int32_eq_const_52_0 == -1140184888)
    if (uint8_eq_const_53_0 == 51)
    if (int8_eq_const_54_0 == -86)
    if (int8_eq_const_55_0 == 10)
    if (uint64_eq_const_56_0 == 12269435952313245311u)
    if (int32_eq_const_57_0 == 73158498)
    if (uint64_eq_const_58_0 == 15432017343731485721u)
    if (uint64_eq_const_59_0 == 2664610758522625586u)
    if (uint32_eq_const_60_0 == 32415381)
    if (int64_eq_const_61_0 == 8039889128288105341)
    if (int32_eq_const_62_0 == -87959779)
    if (int8_eq_const_63_0 == 89)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
