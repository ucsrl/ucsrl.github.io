#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int8_t int8_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int16_t int16_eq_const_11_0;

    if (size < 50)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;


    if (int64_eq_const_0_0 == -7479637438938257408)
    if (uint32_eq_const_1_0 == 2429315092)
    if (int64_eq_const_2_0 == -5200705237591129008)
    if (int64_eq_const_3_0 == -5576266524259260806)
    if (uint8_eq_const_4_0 == 178)
    if (uint32_eq_const_5_0 == 4258518480)
    if (uint32_eq_const_6_0 == 3591717193)
    if (uint64_eq_const_7_0 == 9255817466107615939u)
    if (int8_eq_const_8_0 == 72)
    if (int8_eq_const_9_0 == -34)
    if (int8_eq_const_10_0 == 59)
    if (int16_eq_const_11_0 == 21176)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
