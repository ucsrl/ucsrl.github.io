#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t uint8_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    int8_t int8_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    uint8_t uint8_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    uint32_t uint32_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;

    if (size < 48)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;


    if (uint8_eq_const_0_0 == 108)
    if (uint8_eq_const_1_0 == 243)
    if (int8_eq_const_2_0 == -79)
    if (int16_eq_const_3_0 == -4004)
    if (uint32_eq_const_4_0 == 3307723093)
    if (int32_eq_const_5_0 == 871823471)
    if (int16_eq_const_6_0 == 8482)
    if (uint32_eq_const_7_0 == 2832720132)
    if (uint32_eq_const_8_0 == 2656967487)
    if (uint32_eq_const_9_0 == 2936014517)
    if (int32_eq_const_10_0 == -1938296268)
    if (int64_eq_const_11_0 == 8915869721612638768)
    if (uint8_eq_const_12_0 == 22)
    if (int16_eq_const_13_0 == 14716)
    if (uint32_eq_const_14_0 == 4288636393)
    if (uint16_eq_const_15_0 == 41756)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
