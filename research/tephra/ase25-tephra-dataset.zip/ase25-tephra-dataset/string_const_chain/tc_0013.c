#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    char string_eq_const_0_0[8] = { 0 };
    char string_eq_const_1_0[4] = { 0 };
    char string_eq_const_2_0[4] = { 0 };
    char string_eq_const_3_0[6] = { 0 };
    char string_eq_const_4_0[4] = { 0 };
    char string_eq_const_5_0[3] = { 0 };
    char string_eq_const_6_0[5] = { 0 };
    char string_eq_const_7_0[5] = { 0 };
    char string_eq_const_8_0[5] = { 0 };
    char string_eq_const_9_0[3] = { 0 };
    char string_eq_const_10_0[4] = { 0 };
    char string_eq_const_11_0[3] = { 0 };
    char string_eq_const_12_0[8] = { 0 };

    if (size < 49)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&string_eq_const_0_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_1_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_2_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_3_0, &data[i], 5);
    i += 5;
    memcpy(&string_eq_const_4_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&string_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&string_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&string_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_10_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_12_0, &data[i], 7);
    i += 7;


    if (strcmp(string_eq_const_0_0, "S|-?p_<") == 0)
    if (strcmp(string_eq_const_1_0, "k^>") == 0)
    if (strcmp(string_eq_const_2_0, "D^`") == 0)
    if (strcmp(string_eq_const_3_0, "5g_3 ") == 0)
    if (strcmp(string_eq_const_4_0, "J4U") == 0)
    if (strcmp(string_eq_const_5_0, "/l") == 0)
    if (strcmp(string_eq_const_6_0, "U;u&") == 0)
    if (strcmp(string_eq_const_7_0, "MtN?") == 0)
    if (strcmp(string_eq_const_8_0, " %zI") == 0)
    if (strcmp(string_eq_const_9_0, "$X") == 0)
    if (strcmp(string_eq_const_10_0, "5fP") == 0)
    if (strcmp(string_eq_const_11_0, "]P") == 0)
    if (strcmp(string_eq_const_12_0, "o+WfUQA") == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
