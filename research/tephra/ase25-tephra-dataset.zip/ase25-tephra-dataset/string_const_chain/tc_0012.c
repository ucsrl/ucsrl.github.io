#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    char string_eq_const_0_0[8] = { 0 };
    char string_eq_const_1_0[5] = { 0 };
    char string_eq_const_2_0[8] = { 0 };
    char string_eq_const_3_0[3] = { 0 };
    char string_eq_const_4_0[6] = { 0 };
    char string_eq_const_5_0[6] = { 0 };
    char string_eq_const_6_0[3] = { 0 };
    char string_eq_const_7_0[7] = { 0 };
    char string_eq_const_8_0[6] = { 0 };
    char string_eq_const_9_0[7] = { 0 };
    char string_eq_const_10_0[4] = { 0 };
    char string_eq_const_11_0[6] = { 0 };

    if (size < 57)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&string_eq_const_0_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&string_eq_const_2_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_4_0, &data[i], 5);
    i += 5;
    memcpy(&string_eq_const_5_0, &data[i], 5);
    i += 5;
    memcpy(&string_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_7_0, &data[i], 6);
    i += 6;
    memcpy(&string_eq_const_8_0, &data[i], 5);
    i += 5;
    memcpy(&string_eq_const_9_0, &data[i], 6);
    i += 6;
    memcpy(&string_eq_const_10_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_11_0, &data[i], 5);
    i += 5;


    if (strcmp(string_eq_const_0_0, "Gp@H%Y0") == 0)
    if (strcmp(string_eq_const_1_0, "VQd`") == 0)
    if (strcmp(string_eq_const_2_0, "j;CO;|V") == 0)
    if (strcmp(string_eq_const_3_0, "IT") == 0)
    if (strcmp(string_eq_const_4_0, "eXntC") == 0)
    if (strcmp(string_eq_const_5_0, "p*vZW") == 0)
    if (strcmp(string_eq_const_6_0, "~W") == 0)
    if (strcmp(string_eq_const_7_0, "Q'O1Ob") == 0)
    if (strcmp(string_eq_const_8_0, "BTiQ1") == 0)
    if (strcmp(string_eq_const_9_0, "SK@$lc") == 0)
    if (strcmp(string_eq_const_10_0, "]UQ") == 0)
    if (strcmp(string_eq_const_11_0, "9/cEK") == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
