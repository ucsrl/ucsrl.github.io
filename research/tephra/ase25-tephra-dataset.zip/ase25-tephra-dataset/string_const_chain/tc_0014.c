#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    char string_eq_const_0_0[6] = { 0 };
    char string_eq_const_1_0[3] = { 0 };
    char string_eq_const_2_0[4] = { 0 };
    char string_eq_const_3_0[7] = { 0 };
    char string_eq_const_4_0[8] = { 0 };
    char string_eq_const_5_0[8] = { 0 };
    char string_eq_const_6_0[7] = { 0 };
    char string_eq_const_7_0[3] = { 0 };
    char string_eq_const_8_0[3] = { 0 };
    char string_eq_const_9_0[6] = { 0 };
    char string_eq_const_10_0[8] = { 0 };
    char string_eq_const_11_0[4] = { 0 };
    char string_eq_const_12_0[6] = { 0 };
    char string_eq_const_13_0[3] = { 0 };

    if (size < 62)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&string_eq_const_0_0, &data[i], 5);
    i += 5;
    memcpy(&string_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_2_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_3_0, &data[i], 6);
    i += 6;
    memcpy(&string_eq_const_4_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_5_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_6_0, &data[i], 6);
    i += 6;
    memcpy(&string_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_9_0, &data[i], 5);
    i += 5;
    memcpy(&string_eq_const_10_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_11_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_12_0, &data[i], 5);
    i += 5;
    memcpy(&string_eq_const_13_0, &data[i], 2);
    i += 2;


    if (strcmp(string_eq_const_0_0, "S,uDF") == 0)
    if (strcmp(string_eq_const_1_0, "Z.") == 0)
    if (strcmp(string_eq_const_2_0, "hA9") == 0)
    if (strcmp(string_eq_const_3_0, "bXUdbb") == 0)
    if (strcmp(string_eq_const_4_0, "oOjCfnd") == 0)
    if (strcmp(string_eq_const_5_0, "#OfDY^b") == 0)
    if (strcmp(string_eq_const_6_0, "EwD:]q") == 0)
    if (strcmp(string_eq_const_7_0, "1d") == 0)
    if (strcmp(string_eq_const_8_0, "ji") == 0)
    if (strcmp(string_eq_const_9_0, "xZaRp") == 0)
    if (strcmp(string_eq_const_10_0, "1[.lQH_") == 0)
    if (strcmp(string_eq_const_11_0, "9t?") == 0)
    if (strcmp(string_eq_const_12_0, "0E xT") == 0)
    if (strcmp(string_eq_const_13_0, ",!") == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
