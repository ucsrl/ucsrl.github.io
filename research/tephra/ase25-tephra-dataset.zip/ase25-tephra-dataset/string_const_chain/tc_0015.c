#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    char string_eq_const_0_0[3] = { 0 };
    char string_eq_const_1_0[4] = { 0 };
    char string_eq_const_2_0[7] = { 0 };
    char string_eq_const_3_0[8] = { 0 };
    char string_eq_const_4_0[8] = { 0 };
    char string_eq_const_5_0[8] = { 0 };
    char string_eq_const_6_0[4] = { 0 };
    char string_eq_const_7_0[8] = { 0 };
    char string_eq_const_8_0[8] = { 0 };
    char string_eq_const_9_0[4] = { 0 };
    char string_eq_const_10_0[5] = { 0 };
    char string_eq_const_11_0[7] = { 0 };
    char string_eq_const_12_0[8] = { 0 };
    char string_eq_const_13_0[4] = { 0 };
    char string_eq_const_14_0[4] = { 0 };

    if (size < 75)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&string_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&string_eq_const_1_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_2_0, &data[i], 6);
    i += 6;
    memcpy(&string_eq_const_3_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_4_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_5_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_6_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_7_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_8_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_9_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&string_eq_const_11_0, &data[i], 6);
    i += 6;
    memcpy(&string_eq_const_12_0, &data[i], 7);
    i += 7;
    memcpy(&string_eq_const_13_0, &data[i], 3);
    i += 3;
    memcpy(&string_eq_const_14_0, &data[i], 3);
    i += 3;


    if (strcmp(string_eq_const_0_0, "xt") == 0)
    if (strcmp(string_eq_const_1_0, "%^g") == 0)
    if (strcmp(string_eq_const_2_0, "Lb)fV>") == 0)
    if (strcmp(string_eq_const_3_0, "g1D*v!E") == 0)
    if (strcmp(string_eq_const_4_0, "_[VNX3a") == 0)
    if (strcmp(string_eq_const_5_0, "X>itr4s") == 0)
    if (strcmp(string_eq_const_6_0, "g45") == 0)
    if (strcmp(string_eq_const_7_0, "*=Hl@4d") == 0)
    if (strcmp(string_eq_const_8_0, ":->f7xe") == 0)
    if (strcmp(string_eq_const_9_0, "w{L") == 0)
    if (strcmp(string_eq_const_10_0, "$[(z") == 0)
    if (strcmp(string_eq_const_11_0, "La Ovh") == 0)
    if (strcmp(string_eq_const_12_0, "~NDd[fZ") == 0)
    if (strcmp(string_eq_const_13_0, "rUO") == 0)
    if (strcmp(string_eq_const_14_0, "vh3") == 0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
