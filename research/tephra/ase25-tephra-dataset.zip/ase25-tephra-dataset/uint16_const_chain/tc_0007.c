#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;

    if (size < 14)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 53057)
    if (uint16_eq_const_1_0 == 34176)
    if (uint16_eq_const_2_0 == 54732)
    if (uint16_eq_const_3_0 == 38237)
    if (uint16_eq_const_4_0 == 45104)
    if (uint16_eq_const_5_0 == 36463)
    if (uint16_eq_const_6_0 == 7585)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
