#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;

    if (size < 2)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 47681)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
