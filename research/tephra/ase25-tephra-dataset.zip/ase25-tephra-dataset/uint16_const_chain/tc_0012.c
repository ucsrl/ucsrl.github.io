#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    uint16_t uint16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint16_t uint16_eq_const_11_0;

    if (size < 24)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_11_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 24314)
    if (uint16_eq_const_1_0 == 57135)
    if (uint16_eq_const_2_0 == 52804)
    if (uint16_eq_const_3_0 == 40384)
    if (uint16_eq_const_4_0 == 24534)
    if (uint16_eq_const_5_0 == 45694)
    if (uint16_eq_const_6_0 == 59546)
    if (uint16_eq_const_7_0 == 12854)
    if (uint16_eq_const_8_0 == 53026)
    if (uint16_eq_const_9_0 == 41152)
    if (uint16_eq_const_10_0 == 30369)
    if (uint16_eq_const_11_0 == 20026)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
