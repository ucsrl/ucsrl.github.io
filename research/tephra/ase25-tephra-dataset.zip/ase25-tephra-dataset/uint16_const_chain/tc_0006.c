#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;

    if (size < 12)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 25936)
    if (uint16_eq_const_1_0 == 61615)
    if (uint16_eq_const_2_0 == 25205)
    if (uint16_eq_const_3_0 == 42351)
    if (uint16_eq_const_4_0 == 50493)
    if (uint16_eq_const_5_0 == 58591)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
