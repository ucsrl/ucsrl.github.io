#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    uint16_t uint16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint16_t uint16_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint16_t uint16_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;
    uint16_t uint16_eq_const_16_0;
    uint16_t uint16_eq_const_17_0;
    uint16_t uint16_eq_const_18_0;
    uint16_t uint16_eq_const_19_0;
    uint16_t uint16_eq_const_20_0;
    uint16_t uint16_eq_const_21_0;
    uint16_t uint16_eq_const_22_0;
    uint16_t uint16_eq_const_23_0;
    uint16_t uint16_eq_const_24_0;
    uint16_t uint16_eq_const_25_0;
    uint16_t uint16_eq_const_26_0;
    uint16_t uint16_eq_const_27_0;
    uint16_t uint16_eq_const_28_0;
    uint16_t uint16_eq_const_29_0;
    uint16_t uint16_eq_const_30_0;
    uint16_t uint16_eq_const_31_0;
    uint16_t uint16_eq_const_32_0;
    uint16_t uint16_eq_const_33_0;
    uint16_t uint16_eq_const_34_0;
    uint16_t uint16_eq_const_35_0;
    uint16_t uint16_eq_const_36_0;
    uint16_t uint16_eq_const_37_0;
    uint16_t uint16_eq_const_38_0;
    uint16_t uint16_eq_const_39_0;
    uint16_t uint16_eq_const_40_0;
    uint16_t uint16_eq_const_41_0;
    uint16_t uint16_eq_const_42_0;
    uint16_t uint16_eq_const_43_0;
    uint16_t uint16_eq_const_44_0;
    uint16_t uint16_eq_const_45_0;
    uint16_t uint16_eq_const_46_0;
    uint16_t uint16_eq_const_47_0;
    uint16_t uint16_eq_const_48_0;
    uint16_t uint16_eq_const_49_0;
    uint16_t uint16_eq_const_50_0;
    uint16_t uint16_eq_const_51_0;
    uint16_t uint16_eq_const_52_0;
    uint16_t uint16_eq_const_53_0;
    uint16_t uint16_eq_const_54_0;
    uint16_t uint16_eq_const_55_0;
    uint16_t uint16_eq_const_56_0;
    uint16_t uint16_eq_const_57_0;
    uint16_t uint16_eq_const_58_0;
    uint16_t uint16_eq_const_59_0;
    uint16_t uint16_eq_const_60_0;
    uint16_t uint16_eq_const_61_0;
    uint16_t uint16_eq_const_62_0;
    uint16_t uint16_eq_const_63_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_32_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_33_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_35_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_36_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_37_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_39_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_40_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_41_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_42_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_43_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_44_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_46_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_47_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_48_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_49_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_50_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_51_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_52_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_53_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_55_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_56_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_57_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_58_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_59_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_61_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_62_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_63_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 9458)
    if (uint16_eq_const_1_0 == 29710)
    if (uint16_eq_const_2_0 == 9692)
    if (uint16_eq_const_3_0 == 48342)
    if (uint16_eq_const_4_0 == 17599)
    if (uint16_eq_const_5_0 == 2262)
    if (uint16_eq_const_6_0 == 57644)
    if (uint16_eq_const_7_0 == 34831)
    if (uint16_eq_const_8_0 == 58549)
    if (uint16_eq_const_9_0 == 1546)
    if (uint16_eq_const_10_0 == 29958)
    if (uint16_eq_const_11_0 == 20276)
    if (uint16_eq_const_12_0 == 10188)
    if (uint16_eq_const_13_0 == 41096)
    if (uint16_eq_const_14_0 == 30256)
    if (uint16_eq_const_15_0 == 44612)
    if (uint16_eq_const_16_0 == 37521)
    if (uint16_eq_const_17_0 == 40318)
    if (uint16_eq_const_18_0 == 46413)
    if (uint16_eq_const_19_0 == 46232)
    if (uint16_eq_const_20_0 == 34030)
    if (uint16_eq_const_21_0 == 45518)
    if (uint16_eq_const_22_0 == 16281)
    if (uint16_eq_const_23_0 == 13222)
    if (uint16_eq_const_24_0 == 38628)
    if (uint16_eq_const_25_0 == 40799)
    if (uint16_eq_const_26_0 == 57593)
    if (uint16_eq_const_27_0 == 35727)
    if (uint16_eq_const_28_0 == 64020)
    if (uint16_eq_const_29_0 == 9096)
    if (uint16_eq_const_30_0 == 21597)
    if (uint16_eq_const_31_0 == 55457)
    if (uint16_eq_const_32_0 == 43552)
    if (uint16_eq_const_33_0 == 19449)
    if (uint16_eq_const_34_0 == 15254)
    if (uint16_eq_const_35_0 == 52072)
    if (uint16_eq_const_36_0 == 42553)
    if (uint16_eq_const_37_0 == 20921)
    if (uint16_eq_const_38_0 == 11296)
    if (uint16_eq_const_39_0 == 25338)
    if (uint16_eq_const_40_0 == 42602)
    if (uint16_eq_const_41_0 == 44069)
    if (uint16_eq_const_42_0 == 39559)
    if (uint16_eq_const_43_0 == 14223)
    if (uint16_eq_const_44_0 == 49020)
    if (uint16_eq_const_45_0 == 43025)
    if (uint16_eq_const_46_0 == 12901)
    if (uint16_eq_const_47_0 == 412)
    if (uint16_eq_const_48_0 == 12403)
    if (uint16_eq_const_49_0 == 29025)
    if (uint16_eq_const_50_0 == 13595)
    if (uint16_eq_const_51_0 == 36866)
    if (uint16_eq_const_52_0 == 9475)
    if (uint16_eq_const_53_0 == 10196)
    if (uint16_eq_const_54_0 == 52682)
    if (uint16_eq_const_55_0 == 28156)
    if (uint16_eq_const_56_0 == 37014)
    if (uint16_eq_const_57_0 == 18886)
    if (uint16_eq_const_58_0 == 58664)
    if (uint16_eq_const_59_0 == 4077)
    if (uint16_eq_const_60_0 == 26010)
    if (uint16_eq_const_61_0 == 31271)
    if (uint16_eq_const_62_0 == 58431)
    if (uint16_eq_const_63_0 == 31786)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
