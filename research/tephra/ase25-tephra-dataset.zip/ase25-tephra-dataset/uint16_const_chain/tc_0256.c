#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    uint16_t uint16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint16_t uint16_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint16_t uint16_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;
    uint16_t uint16_eq_const_16_0;
    uint16_t uint16_eq_const_17_0;
    uint16_t uint16_eq_const_18_0;
    uint16_t uint16_eq_const_19_0;
    uint16_t uint16_eq_const_20_0;
    uint16_t uint16_eq_const_21_0;
    uint16_t uint16_eq_const_22_0;
    uint16_t uint16_eq_const_23_0;
    uint16_t uint16_eq_const_24_0;
    uint16_t uint16_eq_const_25_0;
    uint16_t uint16_eq_const_26_0;
    uint16_t uint16_eq_const_27_0;
    uint16_t uint16_eq_const_28_0;
    uint16_t uint16_eq_const_29_0;
    uint16_t uint16_eq_const_30_0;
    uint16_t uint16_eq_const_31_0;
    uint16_t uint16_eq_const_32_0;
    uint16_t uint16_eq_const_33_0;
    uint16_t uint16_eq_const_34_0;
    uint16_t uint16_eq_const_35_0;
    uint16_t uint16_eq_const_36_0;
    uint16_t uint16_eq_const_37_0;
    uint16_t uint16_eq_const_38_0;
    uint16_t uint16_eq_const_39_0;
    uint16_t uint16_eq_const_40_0;
    uint16_t uint16_eq_const_41_0;
    uint16_t uint16_eq_const_42_0;
    uint16_t uint16_eq_const_43_0;
    uint16_t uint16_eq_const_44_0;
    uint16_t uint16_eq_const_45_0;
    uint16_t uint16_eq_const_46_0;
    uint16_t uint16_eq_const_47_0;
    uint16_t uint16_eq_const_48_0;
    uint16_t uint16_eq_const_49_0;
    uint16_t uint16_eq_const_50_0;
    uint16_t uint16_eq_const_51_0;
    uint16_t uint16_eq_const_52_0;
    uint16_t uint16_eq_const_53_0;
    uint16_t uint16_eq_const_54_0;
    uint16_t uint16_eq_const_55_0;
    uint16_t uint16_eq_const_56_0;
    uint16_t uint16_eq_const_57_0;
    uint16_t uint16_eq_const_58_0;
    uint16_t uint16_eq_const_59_0;
    uint16_t uint16_eq_const_60_0;
    uint16_t uint16_eq_const_61_0;
    uint16_t uint16_eq_const_62_0;
    uint16_t uint16_eq_const_63_0;
    uint16_t uint16_eq_const_64_0;
    uint16_t uint16_eq_const_65_0;
    uint16_t uint16_eq_const_66_0;
    uint16_t uint16_eq_const_67_0;
    uint16_t uint16_eq_const_68_0;
    uint16_t uint16_eq_const_69_0;
    uint16_t uint16_eq_const_70_0;
    uint16_t uint16_eq_const_71_0;
    uint16_t uint16_eq_const_72_0;
    uint16_t uint16_eq_const_73_0;
    uint16_t uint16_eq_const_74_0;
    uint16_t uint16_eq_const_75_0;
    uint16_t uint16_eq_const_76_0;
    uint16_t uint16_eq_const_77_0;
    uint16_t uint16_eq_const_78_0;
    uint16_t uint16_eq_const_79_0;
    uint16_t uint16_eq_const_80_0;
    uint16_t uint16_eq_const_81_0;
    uint16_t uint16_eq_const_82_0;
    uint16_t uint16_eq_const_83_0;
    uint16_t uint16_eq_const_84_0;
    uint16_t uint16_eq_const_85_0;
    uint16_t uint16_eq_const_86_0;
    uint16_t uint16_eq_const_87_0;
    uint16_t uint16_eq_const_88_0;
    uint16_t uint16_eq_const_89_0;
    uint16_t uint16_eq_const_90_0;
    uint16_t uint16_eq_const_91_0;
    uint16_t uint16_eq_const_92_0;
    uint16_t uint16_eq_const_93_0;
    uint16_t uint16_eq_const_94_0;
    uint16_t uint16_eq_const_95_0;
    uint16_t uint16_eq_const_96_0;
    uint16_t uint16_eq_const_97_0;
    uint16_t uint16_eq_const_98_0;
    uint16_t uint16_eq_const_99_0;
    uint16_t uint16_eq_const_100_0;
    uint16_t uint16_eq_const_101_0;
    uint16_t uint16_eq_const_102_0;
    uint16_t uint16_eq_const_103_0;
    uint16_t uint16_eq_const_104_0;
    uint16_t uint16_eq_const_105_0;
    uint16_t uint16_eq_const_106_0;
    uint16_t uint16_eq_const_107_0;
    uint16_t uint16_eq_const_108_0;
    uint16_t uint16_eq_const_109_0;
    uint16_t uint16_eq_const_110_0;
    uint16_t uint16_eq_const_111_0;
    uint16_t uint16_eq_const_112_0;
    uint16_t uint16_eq_const_113_0;
    uint16_t uint16_eq_const_114_0;
    uint16_t uint16_eq_const_115_0;
    uint16_t uint16_eq_const_116_0;
    uint16_t uint16_eq_const_117_0;
    uint16_t uint16_eq_const_118_0;
    uint16_t uint16_eq_const_119_0;
    uint16_t uint16_eq_const_120_0;
    uint16_t uint16_eq_const_121_0;
    uint16_t uint16_eq_const_122_0;
    uint16_t uint16_eq_const_123_0;
    uint16_t uint16_eq_const_124_0;
    uint16_t uint16_eq_const_125_0;
    uint16_t uint16_eq_const_126_0;
    uint16_t uint16_eq_const_127_0;
    uint16_t uint16_eq_const_128_0;
    uint16_t uint16_eq_const_129_0;
    uint16_t uint16_eq_const_130_0;
    uint16_t uint16_eq_const_131_0;
    uint16_t uint16_eq_const_132_0;
    uint16_t uint16_eq_const_133_0;
    uint16_t uint16_eq_const_134_0;
    uint16_t uint16_eq_const_135_0;
    uint16_t uint16_eq_const_136_0;
    uint16_t uint16_eq_const_137_0;
    uint16_t uint16_eq_const_138_0;
    uint16_t uint16_eq_const_139_0;
    uint16_t uint16_eq_const_140_0;
    uint16_t uint16_eq_const_141_0;
    uint16_t uint16_eq_const_142_0;
    uint16_t uint16_eq_const_143_0;
    uint16_t uint16_eq_const_144_0;
    uint16_t uint16_eq_const_145_0;
    uint16_t uint16_eq_const_146_0;
    uint16_t uint16_eq_const_147_0;
    uint16_t uint16_eq_const_148_0;
    uint16_t uint16_eq_const_149_0;
    uint16_t uint16_eq_const_150_0;
    uint16_t uint16_eq_const_151_0;
    uint16_t uint16_eq_const_152_0;
    uint16_t uint16_eq_const_153_0;
    uint16_t uint16_eq_const_154_0;
    uint16_t uint16_eq_const_155_0;
    uint16_t uint16_eq_const_156_0;
    uint16_t uint16_eq_const_157_0;
    uint16_t uint16_eq_const_158_0;
    uint16_t uint16_eq_const_159_0;
    uint16_t uint16_eq_const_160_0;
    uint16_t uint16_eq_const_161_0;
    uint16_t uint16_eq_const_162_0;
    uint16_t uint16_eq_const_163_0;
    uint16_t uint16_eq_const_164_0;
    uint16_t uint16_eq_const_165_0;
    uint16_t uint16_eq_const_166_0;
    uint16_t uint16_eq_const_167_0;
    uint16_t uint16_eq_const_168_0;
    uint16_t uint16_eq_const_169_0;
    uint16_t uint16_eq_const_170_0;
    uint16_t uint16_eq_const_171_0;
    uint16_t uint16_eq_const_172_0;
    uint16_t uint16_eq_const_173_0;
    uint16_t uint16_eq_const_174_0;
    uint16_t uint16_eq_const_175_0;
    uint16_t uint16_eq_const_176_0;
    uint16_t uint16_eq_const_177_0;
    uint16_t uint16_eq_const_178_0;
    uint16_t uint16_eq_const_179_0;
    uint16_t uint16_eq_const_180_0;
    uint16_t uint16_eq_const_181_0;
    uint16_t uint16_eq_const_182_0;
    uint16_t uint16_eq_const_183_0;
    uint16_t uint16_eq_const_184_0;
    uint16_t uint16_eq_const_185_0;
    uint16_t uint16_eq_const_186_0;
    uint16_t uint16_eq_const_187_0;
    uint16_t uint16_eq_const_188_0;
    uint16_t uint16_eq_const_189_0;
    uint16_t uint16_eq_const_190_0;
    uint16_t uint16_eq_const_191_0;
    uint16_t uint16_eq_const_192_0;
    uint16_t uint16_eq_const_193_0;
    uint16_t uint16_eq_const_194_0;
    uint16_t uint16_eq_const_195_0;
    uint16_t uint16_eq_const_196_0;
    uint16_t uint16_eq_const_197_0;
    uint16_t uint16_eq_const_198_0;
    uint16_t uint16_eq_const_199_0;
    uint16_t uint16_eq_const_200_0;
    uint16_t uint16_eq_const_201_0;
    uint16_t uint16_eq_const_202_0;
    uint16_t uint16_eq_const_203_0;
    uint16_t uint16_eq_const_204_0;
    uint16_t uint16_eq_const_205_0;
    uint16_t uint16_eq_const_206_0;
    uint16_t uint16_eq_const_207_0;
    uint16_t uint16_eq_const_208_0;
    uint16_t uint16_eq_const_209_0;
    uint16_t uint16_eq_const_210_0;
    uint16_t uint16_eq_const_211_0;
    uint16_t uint16_eq_const_212_0;
    uint16_t uint16_eq_const_213_0;
    uint16_t uint16_eq_const_214_0;
    uint16_t uint16_eq_const_215_0;
    uint16_t uint16_eq_const_216_0;
    uint16_t uint16_eq_const_217_0;
    uint16_t uint16_eq_const_218_0;
    uint16_t uint16_eq_const_219_0;
    uint16_t uint16_eq_const_220_0;
    uint16_t uint16_eq_const_221_0;
    uint16_t uint16_eq_const_222_0;
    uint16_t uint16_eq_const_223_0;
    uint16_t uint16_eq_const_224_0;
    uint16_t uint16_eq_const_225_0;
    uint16_t uint16_eq_const_226_0;
    uint16_t uint16_eq_const_227_0;
    uint16_t uint16_eq_const_228_0;
    uint16_t uint16_eq_const_229_0;
    uint16_t uint16_eq_const_230_0;
    uint16_t uint16_eq_const_231_0;
    uint16_t uint16_eq_const_232_0;
    uint16_t uint16_eq_const_233_0;
    uint16_t uint16_eq_const_234_0;
    uint16_t uint16_eq_const_235_0;
    uint16_t uint16_eq_const_236_0;
    uint16_t uint16_eq_const_237_0;
    uint16_t uint16_eq_const_238_0;
    uint16_t uint16_eq_const_239_0;
    uint16_t uint16_eq_const_240_0;
    uint16_t uint16_eq_const_241_0;
    uint16_t uint16_eq_const_242_0;
    uint16_t uint16_eq_const_243_0;
    uint16_t uint16_eq_const_244_0;
    uint16_t uint16_eq_const_245_0;
    uint16_t uint16_eq_const_246_0;
    uint16_t uint16_eq_const_247_0;
    uint16_t uint16_eq_const_248_0;
    uint16_t uint16_eq_const_249_0;
    uint16_t uint16_eq_const_250_0;
    uint16_t uint16_eq_const_251_0;
    uint16_t uint16_eq_const_252_0;
    uint16_t uint16_eq_const_253_0;
    uint16_t uint16_eq_const_254_0;
    uint16_t uint16_eq_const_255_0;

    if (size < 512)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_32_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_33_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_35_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_36_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_37_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_39_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_40_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_41_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_42_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_43_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_44_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_46_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_47_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_48_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_49_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_50_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_51_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_52_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_53_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_55_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_56_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_57_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_58_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_59_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_61_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_62_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_63_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_64_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_65_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_66_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_67_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_68_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_69_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_70_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_71_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_72_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_73_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_74_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_75_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_76_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_77_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_78_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_79_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_80_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_81_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_82_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_83_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_84_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_85_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_86_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_87_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_88_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_89_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_90_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_91_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_92_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_93_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_94_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_95_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_96_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_97_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_98_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_99_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_100_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_101_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_102_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_103_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_104_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_105_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_106_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_107_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_108_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_109_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_110_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_111_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_112_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_113_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_114_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_115_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_116_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_117_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_118_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_119_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_120_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_121_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_122_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_123_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_124_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_125_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_126_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_127_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_128_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_129_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_130_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_131_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_132_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_133_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_134_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_135_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_136_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_137_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_138_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_139_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_140_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_141_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_142_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_143_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_144_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_145_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_146_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_147_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_148_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_149_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_150_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_151_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_152_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_153_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_154_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_155_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_156_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_157_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_158_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_159_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_160_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_161_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_162_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_163_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_164_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_165_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_166_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_167_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_168_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_169_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_170_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_171_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_172_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_173_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_174_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_175_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_176_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_177_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_178_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_179_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_180_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_181_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_182_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_183_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_184_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_185_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_186_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_187_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_188_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_189_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_190_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_191_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_192_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_193_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_194_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_195_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_196_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_197_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_198_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_199_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_200_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_201_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_202_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_203_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_204_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_205_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_206_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_207_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_208_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_209_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_210_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_211_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_212_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_213_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_214_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_215_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_216_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_217_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_218_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_219_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_220_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_221_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_222_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_223_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_224_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_225_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_226_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_227_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_228_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_229_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_230_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_231_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_232_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_233_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_234_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_235_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_236_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_237_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_238_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_239_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_240_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_241_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_242_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_243_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_244_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_245_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_246_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_247_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_248_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_249_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_250_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_251_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_252_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_253_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_254_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_255_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 6327)
    if (uint16_eq_const_1_0 == 27689)
    if (uint16_eq_const_2_0 == 43400)
    if (uint16_eq_const_3_0 == 19858)
    if (uint16_eq_const_4_0 == 35450)
    if (uint16_eq_const_5_0 == 19906)
    if (uint16_eq_const_6_0 == 33662)
    if (uint16_eq_const_7_0 == 65260)
    if (uint16_eq_const_8_0 == 30286)
    if (uint16_eq_const_9_0 == 39001)
    if (uint16_eq_const_10_0 == 53690)
    if (uint16_eq_const_11_0 == 43411)
    if (uint16_eq_const_12_0 == 51798)
    if (uint16_eq_const_13_0 == 21088)
    if (uint16_eq_const_14_0 == 3078)
    if (uint16_eq_const_15_0 == 33982)
    if (uint16_eq_const_16_0 == 41048)
    if (uint16_eq_const_17_0 == 46251)
    if (uint16_eq_const_18_0 == 4885)
    if (uint16_eq_const_19_0 == 18746)
    if (uint16_eq_const_20_0 == 445)
    if (uint16_eq_const_21_0 == 52506)
    if (uint16_eq_const_22_0 == 36706)
    if (uint16_eq_const_23_0 == 20704)
    if (uint16_eq_const_24_0 == 1365)
    if (uint16_eq_const_25_0 == 24850)
    if (uint16_eq_const_26_0 == 54845)
    if (uint16_eq_const_27_0 == 62395)
    if (uint16_eq_const_28_0 == 25810)
    if (uint16_eq_const_29_0 == 32497)
    if (uint16_eq_const_30_0 == 15886)
    if (uint16_eq_const_31_0 == 8710)
    if (uint16_eq_const_32_0 == 53235)
    if (uint16_eq_const_33_0 == 12250)
    if (uint16_eq_const_34_0 == 14055)
    if (uint16_eq_const_35_0 == 8330)
    if (uint16_eq_const_36_0 == 13254)
    if (uint16_eq_const_37_0 == 50557)
    if (uint16_eq_const_38_0 == 12528)
    if (uint16_eq_const_39_0 == 47914)
    if (uint16_eq_const_40_0 == 58498)
    if (uint16_eq_const_41_0 == 20923)
    if (uint16_eq_const_42_0 == 22090)
    if (uint16_eq_const_43_0 == 14219)
    if (uint16_eq_const_44_0 == 6356)
    if (uint16_eq_const_45_0 == 61519)
    if (uint16_eq_const_46_0 == 25195)
    if (uint16_eq_const_47_0 == 53294)
    if (uint16_eq_const_48_0 == 28081)
    if (uint16_eq_const_49_0 == 44240)
    if (uint16_eq_const_50_0 == 27926)
    if (uint16_eq_const_51_0 == 34413)
    if (uint16_eq_const_52_0 == 14845)
    if (uint16_eq_const_53_0 == 63934)
    if (uint16_eq_const_54_0 == 21364)
    if (uint16_eq_const_55_0 == 43048)
    if (uint16_eq_const_56_0 == 20882)
    if (uint16_eq_const_57_0 == 57200)
    if (uint16_eq_const_58_0 == 34283)
    if (uint16_eq_const_59_0 == 31780)
    if (uint16_eq_const_60_0 == 30606)
    if (uint16_eq_const_61_0 == 17422)
    if (uint16_eq_const_62_0 == 26034)
    if (uint16_eq_const_63_0 == 9809)
    if (uint16_eq_const_64_0 == 10203)
    if (uint16_eq_const_65_0 == 61424)
    if (uint16_eq_const_66_0 == 2391)
    if (uint16_eq_const_67_0 == 64396)
    if (uint16_eq_const_68_0 == 36965)
    if (uint16_eq_const_69_0 == 15370)
    if (uint16_eq_const_70_0 == 13210)
    if (uint16_eq_const_71_0 == 10898)
    if (uint16_eq_const_72_0 == 35440)
    if (uint16_eq_const_73_0 == 43589)
    if (uint16_eq_const_74_0 == 33884)
    if (uint16_eq_const_75_0 == 54825)
    if (uint16_eq_const_76_0 == 9466)
    if (uint16_eq_const_77_0 == 494)
    if (uint16_eq_const_78_0 == 28563)
    if (uint16_eq_const_79_0 == 31425)
    if (uint16_eq_const_80_0 == 55597)
    if (uint16_eq_const_81_0 == 60554)
    if (uint16_eq_const_82_0 == 21102)
    if (uint16_eq_const_83_0 == 49171)
    if (uint16_eq_const_84_0 == 53809)
    if (uint16_eq_const_85_0 == 31179)
    if (uint16_eq_const_86_0 == 4896)
    if (uint16_eq_const_87_0 == 42359)
    if (uint16_eq_const_88_0 == 51708)
    if (uint16_eq_const_89_0 == 25453)
    if (uint16_eq_const_90_0 == 5123)
    if (uint16_eq_const_91_0 == 19968)
    if (uint16_eq_const_92_0 == 56553)
    if (uint16_eq_const_93_0 == 25658)
    if (uint16_eq_const_94_0 == 59144)
    if (uint16_eq_const_95_0 == 36750)
    if (uint16_eq_const_96_0 == 24102)
    if (uint16_eq_const_97_0 == 30587)
    if (uint16_eq_const_98_0 == 6813)
    if (uint16_eq_const_99_0 == 52850)
    if (uint16_eq_const_100_0 == 10069)
    if (uint16_eq_const_101_0 == 24712)
    if (uint16_eq_const_102_0 == 44424)
    if (uint16_eq_const_103_0 == 40261)
    if (uint16_eq_const_104_0 == 5609)
    if (uint16_eq_const_105_0 == 27735)
    if (uint16_eq_const_106_0 == 13150)
    if (uint16_eq_const_107_0 == 3858)
    if (uint16_eq_const_108_0 == 26900)
    if (uint16_eq_const_109_0 == 63791)
    if (uint16_eq_const_110_0 == 30601)
    if (uint16_eq_const_111_0 == 43012)
    if (uint16_eq_const_112_0 == 31578)
    if (uint16_eq_const_113_0 == 62159)
    if (uint16_eq_const_114_0 == 31002)
    if (uint16_eq_const_115_0 == 24351)
    if (uint16_eq_const_116_0 == 58133)
    if (uint16_eq_const_117_0 == 7113)
    if (uint16_eq_const_118_0 == 60879)
    if (uint16_eq_const_119_0 == 12743)
    if (uint16_eq_const_120_0 == 23940)
    if (uint16_eq_const_121_0 == 44758)
    if (uint16_eq_const_122_0 == 5878)
    if (uint16_eq_const_123_0 == 24593)
    if (uint16_eq_const_124_0 == 2098)
    if (uint16_eq_const_125_0 == 40280)
    if (uint16_eq_const_126_0 == 38718)
    if (uint16_eq_const_127_0 == 34605)
    if (uint16_eq_const_128_0 == 21705)
    if (uint16_eq_const_129_0 == 29284)
    if (uint16_eq_const_130_0 == 9344)
    if (uint16_eq_const_131_0 == 30039)
    if (uint16_eq_const_132_0 == 54173)
    if (uint16_eq_const_133_0 == 44024)
    if (uint16_eq_const_134_0 == 25877)
    if (uint16_eq_const_135_0 == 49448)
    if (uint16_eq_const_136_0 == 27022)
    if (uint16_eq_const_137_0 == 11836)
    if (uint16_eq_const_138_0 == 1107)
    if (uint16_eq_const_139_0 == 58424)
    if (uint16_eq_const_140_0 == 50694)
    if (uint16_eq_const_141_0 == 20213)
    if (uint16_eq_const_142_0 == 3634)
    if (uint16_eq_const_143_0 == 55126)
    if (uint16_eq_const_144_0 == 63016)
    if (uint16_eq_const_145_0 == 55693)
    if (uint16_eq_const_146_0 == 60990)
    if (uint16_eq_const_147_0 == 62689)
    if (uint16_eq_const_148_0 == 49805)
    if (uint16_eq_const_149_0 == 22083)
    if (uint16_eq_const_150_0 == 601)
    if (uint16_eq_const_151_0 == 13304)
    if (uint16_eq_const_152_0 == 7435)
    if (uint16_eq_const_153_0 == 53634)
    if (uint16_eq_const_154_0 == 36331)
    if (uint16_eq_const_155_0 == 42379)
    if (uint16_eq_const_156_0 == 17522)
    if (uint16_eq_const_157_0 == 23132)
    if (uint16_eq_const_158_0 == 65154)
    if (uint16_eq_const_159_0 == 31376)
    if (uint16_eq_const_160_0 == 27709)
    if (uint16_eq_const_161_0 == 29103)
    if (uint16_eq_const_162_0 == 57101)
    if (uint16_eq_const_163_0 == 49361)
    if (uint16_eq_const_164_0 == 42638)
    if (uint16_eq_const_165_0 == 44414)
    if (uint16_eq_const_166_0 == 35621)
    if (uint16_eq_const_167_0 == 29223)
    if (uint16_eq_const_168_0 == 34578)
    if (uint16_eq_const_169_0 == 58982)
    if (uint16_eq_const_170_0 == 45076)
    if (uint16_eq_const_171_0 == 26653)
    if (uint16_eq_const_172_0 == 30091)
    if (uint16_eq_const_173_0 == 24407)
    if (uint16_eq_const_174_0 == 60817)
    if (uint16_eq_const_175_0 == 17456)
    if (uint16_eq_const_176_0 == 61223)
    if (uint16_eq_const_177_0 == 31212)
    if (uint16_eq_const_178_0 == 29791)
    if (uint16_eq_const_179_0 == 25415)
    if (uint16_eq_const_180_0 == 1508)
    if (uint16_eq_const_181_0 == 46086)
    if (uint16_eq_const_182_0 == 21826)
    if (uint16_eq_const_183_0 == 33041)
    if (uint16_eq_const_184_0 == 17826)
    if (uint16_eq_const_185_0 == 56722)
    if (uint16_eq_const_186_0 == 20217)
    if (uint16_eq_const_187_0 == 50766)
    if (uint16_eq_const_188_0 == 50856)
    if (uint16_eq_const_189_0 == 44941)
    if (uint16_eq_const_190_0 == 20027)
    if (uint16_eq_const_191_0 == 39763)
    if (uint16_eq_const_192_0 == 40376)
    if (uint16_eq_const_193_0 == 12218)
    if (uint16_eq_const_194_0 == 32468)
    if (uint16_eq_const_195_0 == 48694)
    if (uint16_eq_const_196_0 == 2559)
    if (uint16_eq_const_197_0 == 38560)
    if (uint16_eq_const_198_0 == 49514)
    if (uint16_eq_const_199_0 == 51829)
    if (uint16_eq_const_200_0 == 47476)
    if (uint16_eq_const_201_0 == 49078)
    if (uint16_eq_const_202_0 == 38283)
    if (uint16_eq_const_203_0 == 38416)
    if (uint16_eq_const_204_0 == 15479)
    if (uint16_eq_const_205_0 == 34269)
    if (uint16_eq_const_206_0 == 3077)
    if (uint16_eq_const_207_0 == 34399)
    if (uint16_eq_const_208_0 == 18884)
    if (uint16_eq_const_209_0 == 53391)
    if (uint16_eq_const_210_0 == 8617)
    if (uint16_eq_const_211_0 == 17695)
    if (uint16_eq_const_212_0 == 50191)
    if (uint16_eq_const_213_0 == 32864)
    if (uint16_eq_const_214_0 == 63225)
    if (uint16_eq_const_215_0 == 3199)
    if (uint16_eq_const_216_0 == 35531)
    if (uint16_eq_const_217_0 == 56242)
    if (uint16_eq_const_218_0 == 46448)
    if (uint16_eq_const_219_0 == 5927)
    if (uint16_eq_const_220_0 == 12)
    if (uint16_eq_const_221_0 == 38597)
    if (uint16_eq_const_222_0 == 38735)
    if (uint16_eq_const_223_0 == 40838)
    if (uint16_eq_const_224_0 == 54643)
    if (uint16_eq_const_225_0 == 5245)
    if (uint16_eq_const_226_0 == 29483)
    if (uint16_eq_const_227_0 == 16346)
    if (uint16_eq_const_228_0 == 8849)
    if (uint16_eq_const_229_0 == 1926)
    if (uint16_eq_const_230_0 == 24737)
    if (uint16_eq_const_231_0 == 29384)
    if (uint16_eq_const_232_0 == 65352)
    if (uint16_eq_const_233_0 == 11700)
    if (uint16_eq_const_234_0 == 34809)
    if (uint16_eq_const_235_0 == 27246)
    if (uint16_eq_const_236_0 == 56566)
    if (uint16_eq_const_237_0 == 31170)
    if (uint16_eq_const_238_0 == 62089)
    if (uint16_eq_const_239_0 == 29255)
    if (uint16_eq_const_240_0 == 41362)
    if (uint16_eq_const_241_0 == 41429)
    if (uint16_eq_const_242_0 == 15913)
    if (uint16_eq_const_243_0 == 38484)
    if (uint16_eq_const_244_0 == 6121)
    if (uint16_eq_const_245_0 == 45923)
    if (uint16_eq_const_246_0 == 27163)
    if (uint16_eq_const_247_0 == 22614)
    if (uint16_eq_const_248_0 == 41144)
    if (uint16_eq_const_249_0 == 65369)
    if (uint16_eq_const_250_0 == 36881)
    if (uint16_eq_const_251_0 == 53780)
    if (uint16_eq_const_252_0 == 12367)
    if (uint16_eq_const_253_0 == 27568)
    if (uint16_eq_const_254_0 == 16480)
    if (uint16_eq_const_255_0 == 49648)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
