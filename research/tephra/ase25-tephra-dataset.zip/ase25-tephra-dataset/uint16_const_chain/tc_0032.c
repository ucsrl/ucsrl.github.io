#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    uint16_t uint16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint16_t uint16_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint16_t uint16_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;
    uint16_t uint16_eq_const_16_0;
    uint16_t uint16_eq_const_17_0;
    uint16_t uint16_eq_const_18_0;
    uint16_t uint16_eq_const_19_0;
    uint16_t uint16_eq_const_20_0;
    uint16_t uint16_eq_const_21_0;
    uint16_t uint16_eq_const_22_0;
    uint16_t uint16_eq_const_23_0;
    uint16_t uint16_eq_const_24_0;
    uint16_t uint16_eq_const_25_0;
    uint16_t uint16_eq_const_26_0;
    uint16_t uint16_eq_const_27_0;
    uint16_t uint16_eq_const_28_0;
    uint16_t uint16_eq_const_29_0;
    uint16_t uint16_eq_const_30_0;
    uint16_t uint16_eq_const_31_0;

    if (size < 64)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_31_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 6743)
    if (uint16_eq_const_1_0 == 6806)
    if (uint16_eq_const_2_0 == 11352)
    if (uint16_eq_const_3_0 == 58827)
    if (uint16_eq_const_4_0 == 27450)
    if (uint16_eq_const_5_0 == 55539)
    if (uint16_eq_const_6_0 == 22053)
    if (uint16_eq_const_7_0 == 27734)
    if (uint16_eq_const_8_0 == 3434)
    if (uint16_eq_const_9_0 == 39511)
    if (uint16_eq_const_10_0 == 10889)
    if (uint16_eq_const_11_0 == 31603)
    if (uint16_eq_const_12_0 == 37535)
    if (uint16_eq_const_13_0 == 33901)
    if (uint16_eq_const_14_0 == 46607)
    if (uint16_eq_const_15_0 == 44327)
    if (uint16_eq_const_16_0 == 55778)
    if (uint16_eq_const_17_0 == 51401)
    if (uint16_eq_const_18_0 == 18998)
    if (uint16_eq_const_19_0 == 24214)
    if (uint16_eq_const_20_0 == 33118)
    if (uint16_eq_const_21_0 == 18639)
    if (uint16_eq_const_22_0 == 63898)
    if (uint16_eq_const_23_0 == 37480)
    if (uint16_eq_const_24_0 == 8030)
    if (uint16_eq_const_25_0 == 28482)
    if (uint16_eq_const_26_0 == 35990)
    if (uint16_eq_const_27_0 == 37796)
    if (uint16_eq_const_28_0 == 47679)
    if (uint16_eq_const_29_0 == 39063)
    if (uint16_eq_const_30_0 == 53612)
    if (uint16_eq_const_31_0 == 57918)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
