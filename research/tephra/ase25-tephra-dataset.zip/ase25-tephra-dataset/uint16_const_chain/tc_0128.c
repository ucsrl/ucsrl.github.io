#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    uint16_t uint16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint16_t uint16_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint16_t uint16_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;
    uint16_t uint16_eq_const_16_0;
    uint16_t uint16_eq_const_17_0;
    uint16_t uint16_eq_const_18_0;
    uint16_t uint16_eq_const_19_0;
    uint16_t uint16_eq_const_20_0;
    uint16_t uint16_eq_const_21_0;
    uint16_t uint16_eq_const_22_0;
    uint16_t uint16_eq_const_23_0;
    uint16_t uint16_eq_const_24_0;
    uint16_t uint16_eq_const_25_0;
    uint16_t uint16_eq_const_26_0;
    uint16_t uint16_eq_const_27_0;
    uint16_t uint16_eq_const_28_0;
    uint16_t uint16_eq_const_29_0;
    uint16_t uint16_eq_const_30_0;
    uint16_t uint16_eq_const_31_0;
    uint16_t uint16_eq_const_32_0;
    uint16_t uint16_eq_const_33_0;
    uint16_t uint16_eq_const_34_0;
    uint16_t uint16_eq_const_35_0;
    uint16_t uint16_eq_const_36_0;
    uint16_t uint16_eq_const_37_0;
    uint16_t uint16_eq_const_38_0;
    uint16_t uint16_eq_const_39_0;
    uint16_t uint16_eq_const_40_0;
    uint16_t uint16_eq_const_41_0;
    uint16_t uint16_eq_const_42_0;
    uint16_t uint16_eq_const_43_0;
    uint16_t uint16_eq_const_44_0;
    uint16_t uint16_eq_const_45_0;
    uint16_t uint16_eq_const_46_0;
    uint16_t uint16_eq_const_47_0;
    uint16_t uint16_eq_const_48_0;
    uint16_t uint16_eq_const_49_0;
    uint16_t uint16_eq_const_50_0;
    uint16_t uint16_eq_const_51_0;
    uint16_t uint16_eq_const_52_0;
    uint16_t uint16_eq_const_53_0;
    uint16_t uint16_eq_const_54_0;
    uint16_t uint16_eq_const_55_0;
    uint16_t uint16_eq_const_56_0;
    uint16_t uint16_eq_const_57_0;
    uint16_t uint16_eq_const_58_0;
    uint16_t uint16_eq_const_59_0;
    uint16_t uint16_eq_const_60_0;
    uint16_t uint16_eq_const_61_0;
    uint16_t uint16_eq_const_62_0;
    uint16_t uint16_eq_const_63_0;
    uint16_t uint16_eq_const_64_0;
    uint16_t uint16_eq_const_65_0;
    uint16_t uint16_eq_const_66_0;
    uint16_t uint16_eq_const_67_0;
    uint16_t uint16_eq_const_68_0;
    uint16_t uint16_eq_const_69_0;
    uint16_t uint16_eq_const_70_0;
    uint16_t uint16_eq_const_71_0;
    uint16_t uint16_eq_const_72_0;
    uint16_t uint16_eq_const_73_0;
    uint16_t uint16_eq_const_74_0;
    uint16_t uint16_eq_const_75_0;
    uint16_t uint16_eq_const_76_0;
    uint16_t uint16_eq_const_77_0;
    uint16_t uint16_eq_const_78_0;
    uint16_t uint16_eq_const_79_0;
    uint16_t uint16_eq_const_80_0;
    uint16_t uint16_eq_const_81_0;
    uint16_t uint16_eq_const_82_0;
    uint16_t uint16_eq_const_83_0;
    uint16_t uint16_eq_const_84_0;
    uint16_t uint16_eq_const_85_0;
    uint16_t uint16_eq_const_86_0;
    uint16_t uint16_eq_const_87_0;
    uint16_t uint16_eq_const_88_0;
    uint16_t uint16_eq_const_89_0;
    uint16_t uint16_eq_const_90_0;
    uint16_t uint16_eq_const_91_0;
    uint16_t uint16_eq_const_92_0;
    uint16_t uint16_eq_const_93_0;
    uint16_t uint16_eq_const_94_0;
    uint16_t uint16_eq_const_95_0;
    uint16_t uint16_eq_const_96_0;
    uint16_t uint16_eq_const_97_0;
    uint16_t uint16_eq_const_98_0;
    uint16_t uint16_eq_const_99_0;
    uint16_t uint16_eq_const_100_0;
    uint16_t uint16_eq_const_101_0;
    uint16_t uint16_eq_const_102_0;
    uint16_t uint16_eq_const_103_0;
    uint16_t uint16_eq_const_104_0;
    uint16_t uint16_eq_const_105_0;
    uint16_t uint16_eq_const_106_0;
    uint16_t uint16_eq_const_107_0;
    uint16_t uint16_eq_const_108_0;
    uint16_t uint16_eq_const_109_0;
    uint16_t uint16_eq_const_110_0;
    uint16_t uint16_eq_const_111_0;
    uint16_t uint16_eq_const_112_0;
    uint16_t uint16_eq_const_113_0;
    uint16_t uint16_eq_const_114_0;
    uint16_t uint16_eq_const_115_0;
    uint16_t uint16_eq_const_116_0;
    uint16_t uint16_eq_const_117_0;
    uint16_t uint16_eq_const_118_0;
    uint16_t uint16_eq_const_119_0;
    uint16_t uint16_eq_const_120_0;
    uint16_t uint16_eq_const_121_0;
    uint16_t uint16_eq_const_122_0;
    uint16_t uint16_eq_const_123_0;
    uint16_t uint16_eq_const_124_0;
    uint16_t uint16_eq_const_125_0;
    uint16_t uint16_eq_const_126_0;
    uint16_t uint16_eq_const_127_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_32_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_33_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_35_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_36_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_37_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_39_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_40_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_41_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_42_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_43_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_44_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_46_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_47_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_48_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_49_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_50_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_51_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_52_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_53_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_55_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_56_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_57_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_58_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_59_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_61_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_62_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_63_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_64_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_65_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_66_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_67_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_68_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_69_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_70_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_71_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_72_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_73_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_74_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_75_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_76_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_77_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_78_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_79_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_80_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_81_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_82_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_83_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_84_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_85_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_86_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_87_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_88_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_89_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_90_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_91_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_92_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_93_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_94_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_95_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_96_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_97_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_98_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_99_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_100_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_101_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_102_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_103_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_104_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_105_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_106_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_107_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_108_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_109_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_110_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_111_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_112_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_113_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_114_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_115_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_116_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_117_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_118_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_119_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_120_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_121_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_122_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_123_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_124_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_125_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_126_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_127_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 28131)
    if (uint16_eq_const_1_0 == 41223)
    if (uint16_eq_const_2_0 == 10571)
    if (uint16_eq_const_3_0 == 25546)
    if (uint16_eq_const_4_0 == 27044)
    if (uint16_eq_const_5_0 == 50114)
    if (uint16_eq_const_6_0 == 24687)
    if (uint16_eq_const_7_0 == 59862)
    if (uint16_eq_const_8_0 == 62158)
    if (uint16_eq_const_9_0 == 34056)
    if (uint16_eq_const_10_0 == 12409)
    if (uint16_eq_const_11_0 == 20743)
    if (uint16_eq_const_12_0 == 14850)
    if (uint16_eq_const_13_0 == 21563)
    if (uint16_eq_const_14_0 == 5658)
    if (uint16_eq_const_15_0 == 64038)
    if (uint16_eq_const_16_0 == 37103)
    if (uint16_eq_const_17_0 == 22701)
    if (uint16_eq_const_18_0 == 20820)
    if (uint16_eq_const_19_0 == 55639)
    if (uint16_eq_const_20_0 == 25977)
    if (uint16_eq_const_21_0 == 54645)
    if (uint16_eq_const_22_0 == 63725)
    if (uint16_eq_const_23_0 == 33566)
    if (uint16_eq_const_24_0 == 1921)
    if (uint16_eq_const_25_0 == 35782)
    if (uint16_eq_const_26_0 == 20692)
    if (uint16_eq_const_27_0 == 25029)
    if (uint16_eq_const_28_0 == 44807)
    if (uint16_eq_const_29_0 == 41741)
    if (uint16_eq_const_30_0 == 9332)
    if (uint16_eq_const_31_0 == 43614)
    if (uint16_eq_const_32_0 == 24796)
    if (uint16_eq_const_33_0 == 40997)
    if (uint16_eq_const_34_0 == 21028)
    if (uint16_eq_const_35_0 == 36594)
    if (uint16_eq_const_36_0 == 16394)
    if (uint16_eq_const_37_0 == 65343)
    if (uint16_eq_const_38_0 == 26915)
    if (uint16_eq_const_39_0 == 39301)
    if (uint16_eq_const_40_0 == 37551)
    if (uint16_eq_const_41_0 == 5749)
    if (uint16_eq_const_42_0 == 14293)
    if (uint16_eq_const_43_0 == 4622)
    if (uint16_eq_const_44_0 == 16635)
    if (uint16_eq_const_45_0 == 269)
    if (uint16_eq_const_46_0 == 27696)
    if (uint16_eq_const_47_0 == 53140)
    if (uint16_eq_const_48_0 == 56699)
    if (uint16_eq_const_49_0 == 30189)
    if (uint16_eq_const_50_0 == 62610)
    if (uint16_eq_const_51_0 == 56048)
    if (uint16_eq_const_52_0 == 22000)
    if (uint16_eq_const_53_0 == 38343)
    if (uint16_eq_const_54_0 == 41830)
    if (uint16_eq_const_55_0 == 55295)
    if (uint16_eq_const_56_0 == 17494)
    if (uint16_eq_const_57_0 == 61422)
    if (uint16_eq_const_58_0 == 46170)
    if (uint16_eq_const_59_0 == 16459)
    if (uint16_eq_const_60_0 == 30684)
    if (uint16_eq_const_61_0 == 14072)
    if (uint16_eq_const_62_0 == 13828)
    if (uint16_eq_const_63_0 == 6227)
    if (uint16_eq_const_64_0 == 46574)
    if (uint16_eq_const_65_0 == 24704)
    if (uint16_eq_const_66_0 == 1855)
    if (uint16_eq_const_67_0 == 61207)
    if (uint16_eq_const_68_0 == 58261)
    if (uint16_eq_const_69_0 == 13754)
    if (uint16_eq_const_70_0 == 2970)
    if (uint16_eq_const_71_0 == 42381)
    if (uint16_eq_const_72_0 == 49103)
    if (uint16_eq_const_73_0 == 44213)
    if (uint16_eq_const_74_0 == 30373)
    if (uint16_eq_const_75_0 == 45585)
    if (uint16_eq_const_76_0 == 6047)
    if (uint16_eq_const_77_0 == 48232)
    if (uint16_eq_const_78_0 == 37360)
    if (uint16_eq_const_79_0 == 21006)
    if (uint16_eq_const_80_0 == 58614)
    if (uint16_eq_const_81_0 == 49139)
    if (uint16_eq_const_82_0 == 11787)
    if (uint16_eq_const_83_0 == 25185)
    if (uint16_eq_const_84_0 == 6589)
    if (uint16_eq_const_85_0 == 59319)
    if (uint16_eq_const_86_0 == 744)
    if (uint16_eq_const_87_0 == 25910)
    if (uint16_eq_const_88_0 == 61595)
    if (uint16_eq_const_89_0 == 43291)
    if (uint16_eq_const_90_0 == 41042)
    if (uint16_eq_const_91_0 == 37482)
    if (uint16_eq_const_92_0 == 32064)
    if (uint16_eq_const_93_0 == 38964)
    if (uint16_eq_const_94_0 == 13168)
    if (uint16_eq_const_95_0 == 44452)
    if (uint16_eq_const_96_0 == 56907)
    if (uint16_eq_const_97_0 == 39066)
    if (uint16_eq_const_98_0 == 21129)
    if (uint16_eq_const_99_0 == 50105)
    if (uint16_eq_const_100_0 == 58144)
    if (uint16_eq_const_101_0 == 56613)
    if (uint16_eq_const_102_0 == 13420)
    if (uint16_eq_const_103_0 == 57105)
    if (uint16_eq_const_104_0 == 12347)
    if (uint16_eq_const_105_0 == 49246)
    if (uint16_eq_const_106_0 == 13635)
    if (uint16_eq_const_107_0 == 14614)
    if (uint16_eq_const_108_0 == 60628)
    if (uint16_eq_const_109_0 == 6609)
    if (uint16_eq_const_110_0 == 20142)
    if (uint16_eq_const_111_0 == 27873)
    if (uint16_eq_const_112_0 == 52457)
    if (uint16_eq_const_113_0 == 22184)
    if (uint16_eq_const_114_0 == 13674)
    if (uint16_eq_const_115_0 == 46528)
    if (uint16_eq_const_116_0 == 56054)
    if (uint16_eq_const_117_0 == 17953)
    if (uint16_eq_const_118_0 == 8937)
    if (uint16_eq_const_119_0 == 21057)
    if (uint16_eq_const_120_0 == 48380)
    if (uint16_eq_const_121_0 == 15565)
    if (uint16_eq_const_122_0 == 60823)
    if (uint16_eq_const_123_0 == 47817)
    if (uint16_eq_const_124_0 == 20637)
    if (uint16_eq_const_125_0 == 60342)
    if (uint16_eq_const_126_0 == 63155)
    if (uint16_eq_const_127_0 == 30977)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
