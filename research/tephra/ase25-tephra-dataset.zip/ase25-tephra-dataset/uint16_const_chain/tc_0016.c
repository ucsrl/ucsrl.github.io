#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    uint16_t uint16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint16_t uint16_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint16_t uint16_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;

    if (size < 32)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 25936)
    if (uint16_eq_const_1_0 == 61615)
    if (uint16_eq_const_2_0 == 25205)
    if (uint16_eq_const_3_0 == 42351)
    if (uint16_eq_const_4_0 == 50493)
    if (uint16_eq_const_5_0 == 58591)
    if (uint16_eq_const_6_0 == 39245)
    if (uint16_eq_const_7_0 == 63965)
    if (uint16_eq_const_8_0 == 5051)
    if (uint16_eq_const_9_0 == 50798)
    if (uint16_eq_const_10_0 == 18272)
    if (uint16_eq_const_11_0 == 58930)
    if (uint16_eq_const_12_0 == 24499)
    if (uint16_eq_const_13_0 == 28266)
    if (uint16_eq_const_14_0 == 21779)
    if (uint16_eq_const_15_0 == 20653)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
