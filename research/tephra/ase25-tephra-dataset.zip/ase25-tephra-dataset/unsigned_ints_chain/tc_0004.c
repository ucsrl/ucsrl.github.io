#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;

    if (size < 9)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;


    if (uint16_eq_const_0_0 == 23609)
    if (uint8_eq_const_1_0 == 111)
    if (uint16_eq_const_2_0 == 29970)
    if (uint32_eq_const_3_0 == 2030181308)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
