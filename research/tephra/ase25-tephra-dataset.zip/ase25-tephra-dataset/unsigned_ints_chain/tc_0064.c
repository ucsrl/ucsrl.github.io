#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint32_t uint32_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;
    uint16_t uint16_eq_const_16_0;
    uint64_t uint64_eq_const_17_0;
    uint32_t uint32_eq_const_18_0;
    uint8_t uint8_eq_const_19_0;
    uint16_t uint16_eq_const_20_0;
    uint16_t uint16_eq_const_21_0;
    uint8_t uint8_eq_const_22_0;
    uint16_t uint16_eq_const_23_0;
    uint32_t uint32_eq_const_24_0;
    uint32_t uint32_eq_const_25_0;
    uint64_t uint64_eq_const_26_0;
    uint16_t uint16_eq_const_27_0;
    uint16_t uint16_eq_const_28_0;
    uint8_t uint8_eq_const_29_0;
    uint16_t uint16_eq_const_30_0;
    uint16_t uint16_eq_const_31_0;
    uint8_t uint8_eq_const_32_0;
    uint8_t uint8_eq_const_33_0;
    uint16_t uint16_eq_const_34_0;
    uint32_t uint32_eq_const_35_0;
    uint8_t uint8_eq_const_36_0;
    uint16_t uint16_eq_const_37_0;
    uint8_t uint8_eq_const_38_0;
    uint16_t uint16_eq_const_39_0;
    uint32_t uint32_eq_const_40_0;
    uint64_t uint64_eq_const_41_0;
    uint8_t uint8_eq_const_42_0;
    uint32_t uint32_eq_const_43_0;
    uint8_t uint8_eq_const_44_0;
    uint8_t uint8_eq_const_45_0;
    uint64_t uint64_eq_const_46_0;
    uint8_t uint8_eq_const_47_0;
    uint32_t uint32_eq_const_48_0;
    uint8_t uint8_eq_const_49_0;
    uint32_t uint32_eq_const_50_0;
    uint64_t uint64_eq_const_51_0;
    uint32_t uint32_eq_const_52_0;
    uint16_t uint16_eq_const_53_0;
    uint64_t uint64_eq_const_54_0;
    uint64_t uint64_eq_const_55_0;
    uint16_t uint16_eq_const_56_0;
    uint16_t uint16_eq_const_57_0;
    uint64_t uint64_eq_const_58_0;
    uint64_t uint64_eq_const_59_0;
    uint8_t uint8_eq_const_60_0;
    uint8_t uint8_eq_const_61_0;
    uint64_t uint64_eq_const_62_0;
    uint16_t uint16_eq_const_63_0;

    if (size < 222)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_32_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_37_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_39_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_43_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_53_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_55_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_56_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_57_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_63_0, &data[i], 2);
    i += 2;


    if (uint32_eq_const_0_0 == 466184747)
    if (uint32_eq_const_1_0 == 3989776806)
    if (uint8_eq_const_2_0 == 49)
    if (uint32_eq_const_3_0 == 1568967266)
    if (uint8_eq_const_4_0 == 174)
    if (uint64_eq_const_5_0 == 1654729790736347088u)
    if (uint16_eq_const_6_0 == 24593)
    if (uint16_eq_const_7_0 == 2098)
    if (uint32_eq_const_8_0 == 2639814771)
    if (uint32_eq_const_9_0 == 2537450319)
    if (uint32_eq_const_10_0 == 2267893641)
    if (uint64_eq_const_11_0 == 6109526924490284214u)
    if (uint64_eq_const_12_0 == 8242927398060529240u)
    if (uint32_eq_const_13_0 == 612402799)
    if (uint16_eq_const_14_0 == 30039)
    if (uint16_eq_const_15_0 == 54173)
    if (uint16_eq_const_16_0 == 44024)
    if (uint64_eq_const_17_0 == 7283858864505898335u)
    if (uint32_eq_const_18_0 == 3240677775)
    if (uint8_eq_const_19_0 == 105)
    if (uint16_eq_const_20_0 == 11836)
    if (uint16_eq_const_21_0 == 1107)
    if (uint8_eq_const_22_0 == 228)
    if (uint16_eq_const_23_0 == 50694)
    if (uint32_eq_const_24_0 == 1324723708)
    if (uint32_eq_const_25_0 == 238172272)
    if (uint64_eq_const_26_0 == 15516795137884275432u)
    if (uint16_eq_const_27_0 == 63016)
    if (uint16_eq_const_28_0 == 55693)
    if (uint8_eq_const_29_0 == 238)
    if (uint16_eq_const_30_0 == 62689)
    if (uint16_eq_const_31_0 == 49805)
    if (uint8_eq_const_32_0 == 86)
    if (uint8_eq_const_33_0 == 2)
    if (uint16_eq_const_34_0 == 13304)
    if (uint32_eq_const_35_0 == 487280238)
    if (uint8_eq_const_36_0 == 209)
    if (uint16_eq_const_37_0 == 36331)
    if (uint8_eq_const_38_0 == 165)
    if (uint16_eq_const_39_0 == 17522)
    if (uint32_eq_const_40_0 == 1515985896)
    if (uint64_eq_const_41_0 == 18339248424836592779u)
    if (uint8_eq_const_42_0 == 122)
    if (uint32_eq_const_43_0 == 1815943292)
    if (uint8_eq_const_44_0 == 113)
    if (uint8_eq_const_45_0 == 223)
    if (uint64_eq_const_46_0 == 13893957542045068335u)
    if (uint8_eq_const_47_0 == 166)
    if (uint32_eq_const_48_0 == 2910775226)
    if (uint8_eq_const_49_0 == 139)
    if (uint32_eq_const_50_0 == 1915223935)
    if (uint64_eq_const_51_0 == 9732875359205951525u)
    if (uint32_eq_const_52_0 == 3865504387)
    if (uint16_eq_const_53_0 == 45076)
    if (uint64_eq_const_54_0 == 7502306347631752522u)
    if (uint64_eq_const_55_0 == 8469949503834067651u)
    if (uint16_eq_const_56_0 == 24407)
    if (uint16_eq_const_57_0 == 60817)
    if (uint64_eq_const_58_0 == 4913586931431524099u)
    if (uint64_eq_const_59_0 == 17232781805040838195u)
    if (uint8_eq_const_60_0 == 121)
    if (uint8_eq_const_61_0 == 116)
    if (uint64_eq_const_62_0 == 7153936509151361545u)
    if (uint16_eq_const_63_0 == 1508)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
