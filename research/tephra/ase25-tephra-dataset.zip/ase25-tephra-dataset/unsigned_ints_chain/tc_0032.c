#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint32_t uint32_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint8_t uint8_eq_const_6_0;
    uint16_t uint16_eq_const_7_0;
    uint16_t uint16_eq_const_8_0;
    uint16_t uint16_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint16_t uint16_eq_const_15_0;
    uint16_t uint16_eq_const_16_0;
    uint32_t uint32_eq_const_17_0;
    uint64_t uint64_eq_const_18_0;
    uint16_t uint16_eq_const_19_0;
    uint32_t uint32_eq_const_20_0;
    uint64_t uint64_eq_const_21_0;
    uint8_t uint8_eq_const_22_0;
    uint64_t uint64_eq_const_23_0;
    uint8_t uint8_eq_const_24_0;
    uint16_t uint16_eq_const_25_0;
    uint16_t uint16_eq_const_26_0;
    uint64_t uint64_eq_const_27_0;
    uint8_t uint8_eq_const_28_0;
    uint16_t uint16_eq_const_29_0;
    uint8_t uint8_eq_const_30_0;
    uint8_t uint8_eq_const_31_0;

    if (size < 109)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_31_0, &data[i], 1);
    i += 1;


    if (uint64_eq_const_0_0 == 12774805286162651865u)
    if (uint64_eq_const_1_0 == 11204871657361309748u)
    if (uint16_eq_const_2_0 == 45240)
    if (uint32_eq_const_3_0 == 3508342625)
    if (uint32_eq_const_4_0 == 1116961728)
    if (uint8_eq_const_5_0 == 102)
    if (uint8_eq_const_6_0 == 44)
    if (uint16_eq_const_7_0 == 17923)
    if (uint16_eq_const_8_0 == 4984)
    if (uint16_eq_const_9_0 == 22955)
    if (uint16_eq_const_10_0 == 41101)
    if (uint64_eq_const_11_0 == 10471256173098652964u)
    if (uint16_eq_const_12_0 == 3922)
    if (uint32_eq_const_13_0 == 1358259664)
    if (uint16_eq_const_14_0 == 36335)
    if (uint16_eq_const_15_0 == 64293)
    if (uint16_eq_const_16_0 == 31750)
    if (uint32_eq_const_17_0 == 1944183873)
    if (uint64_eq_const_18_0 == 4450970641213978013u)
    if (uint16_eq_const_19_0 == 37484)
    if (uint32_eq_const_20_0 == 3353018533)
    if (uint64_eq_const_21_0 == 3985755699625045958u)
    if (uint8_eq_const_22_0 == 247)
    if (uint64_eq_const_23_0 == 3500520392002252439u)
    if (uint8_eq_const_24_0 == 180)
    if (uint16_eq_const_25_0 == 53289)
    if (uint16_eq_const_26_0 == 33876)
    if (uint64_eq_const_27_0 == 7818547228960496085u)
    if (uint8_eq_const_28_0 == 100)
    if (uint16_eq_const_29_0 == 18730)
    if (uint8_eq_const_30_0 == 185)
    if (uint8_eq_const_31_0 == 57)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
