#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint16_t uint16_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint16_t uint16_eq_const_10_0;
    uint8_t uint8_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;

    if (size < 45)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 53140)
    if (uint64_eq_const_1_0 == 15959501568123251412u)
    if (uint32_eq_const_2_0 == 1978498088)
    if (uint16_eq_const_3_0 == 62610)
    if (uint8_eq_const_4_0 == 218)
    if (uint32_eq_const_5_0 == 1441852240)
    if (uint16_eq_const_6_0 == 38343)
    if (uint8_eq_const_7_0 == 163)
    if (uint64_eq_const_8_0 == 15564377680023697404u)
    if (uint64_eq_const_9_0 == 4924331122756930186u)
    if (uint16_eq_const_10_0 == 61422)
    if (uint8_eq_const_11_0 == 180)
    if (uint16_eq_const_12_0 == 16459)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
