#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint16_t uint16_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint8_t uint8_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint32_t uint32_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint32_t uint32_eq_const_15_0;
    uint64_t uint64_eq_const_16_0;
    uint32_t uint32_eq_const_17_0;
    uint16_t uint16_eq_const_18_0;
    uint8_t uint8_eq_const_19_0;
    uint64_t uint64_eq_const_20_0;
    uint32_t uint32_eq_const_21_0;
    uint16_t uint16_eq_const_22_0;
    uint64_t uint64_eq_const_23_0;
    uint64_t uint64_eq_const_24_0;
    uint16_t uint16_eq_const_25_0;
    uint64_t uint64_eq_const_26_0;
    uint64_t uint64_eq_const_27_0;
    uint16_t uint16_eq_const_28_0;
    uint16_t uint16_eq_const_29_0;
    uint16_t uint16_eq_const_30_0;
    uint8_t uint8_eq_const_31_0;
    uint32_t uint32_eq_const_32_0;
    uint32_t uint32_eq_const_33_0;
    uint32_t uint32_eq_const_34_0;
    uint8_t uint8_eq_const_35_0;
    uint32_t uint32_eq_const_36_0;
    uint32_t uint32_eq_const_37_0;
    uint8_t uint8_eq_const_38_0;
    uint8_t uint8_eq_const_39_0;
    uint32_t uint32_eq_const_40_0;
    uint8_t uint8_eq_const_41_0;
    uint8_t uint8_eq_const_42_0;
    uint64_t uint64_eq_const_43_0;
    uint8_t uint8_eq_const_44_0;
    uint16_t uint16_eq_const_45_0;
    uint8_t uint8_eq_const_46_0;
    uint32_t uint32_eq_const_47_0;
    uint64_t uint64_eq_const_48_0;
    uint32_t uint32_eq_const_49_0;
    uint8_t uint8_eq_const_50_0;
    uint64_t uint64_eq_const_51_0;
    uint64_t uint64_eq_const_52_0;
    uint8_t uint8_eq_const_53_0;
    uint16_t uint16_eq_const_54_0;
    uint8_t uint8_eq_const_55_0;
    uint32_t uint32_eq_const_56_0;
    uint8_t uint8_eq_const_57_0;
    uint64_t uint64_eq_const_58_0;
    uint8_t uint8_eq_const_59_0;
    uint16_t uint16_eq_const_60_0;
    uint64_t uint64_eq_const_61_0;
    uint32_t uint32_eq_const_62_0;
    uint32_t uint32_eq_const_63_0;
    uint64_t uint64_eq_const_64_0;
    uint32_t uint32_eq_const_65_0;
    uint64_t uint64_eq_const_66_0;
    uint64_t uint64_eq_const_67_0;
    uint16_t uint16_eq_const_68_0;
    uint8_t uint8_eq_const_69_0;
    uint8_t uint8_eq_const_70_0;
    uint16_t uint16_eq_const_71_0;
    uint8_t uint8_eq_const_72_0;
    uint16_t uint16_eq_const_73_0;
    uint8_t uint8_eq_const_74_0;
    uint64_t uint64_eq_const_75_0;
    uint32_t uint32_eq_const_76_0;
    uint16_t uint16_eq_const_77_0;
    uint32_t uint32_eq_const_78_0;
    uint64_t uint64_eq_const_79_0;
    uint8_t uint8_eq_const_80_0;
    uint16_t uint16_eq_const_81_0;
    uint8_t uint8_eq_const_82_0;
    uint8_t uint8_eq_const_83_0;
    uint8_t uint8_eq_const_84_0;
    uint32_t uint32_eq_const_85_0;
    uint16_t uint16_eq_const_86_0;
    uint16_t uint16_eq_const_87_0;
    uint16_t uint16_eq_const_88_0;
    uint8_t uint8_eq_const_89_0;
    uint64_t uint64_eq_const_90_0;
    uint64_t uint64_eq_const_91_0;
    uint32_t uint32_eq_const_92_0;
    uint8_t uint8_eq_const_93_0;
    uint16_t uint16_eq_const_94_0;
    uint16_t uint16_eq_const_95_0;
    uint8_t uint8_eq_const_96_0;
    uint16_t uint16_eq_const_97_0;
    uint8_t uint8_eq_const_98_0;
    uint8_t uint8_eq_const_99_0;
    uint8_t uint8_eq_const_100_0;
    uint32_t uint32_eq_const_101_0;
    uint8_t uint8_eq_const_102_0;
    uint16_t uint16_eq_const_103_0;
    uint32_t uint32_eq_const_104_0;
    uint32_t uint32_eq_const_105_0;
    uint8_t uint8_eq_const_106_0;
    uint64_t uint64_eq_const_107_0;
    uint8_t uint8_eq_const_108_0;
    uint32_t uint32_eq_const_109_0;
    uint8_t uint8_eq_const_110_0;
    uint16_t uint16_eq_const_111_0;
    uint64_t uint64_eq_const_112_0;
    uint64_t uint64_eq_const_113_0;
    uint64_t uint64_eq_const_114_0;
    uint32_t uint32_eq_const_115_0;
    uint8_t uint8_eq_const_116_0;
    uint16_t uint16_eq_const_117_0;
    uint8_t uint8_eq_const_118_0;
    uint16_t uint16_eq_const_119_0;
    uint32_t uint32_eq_const_120_0;
    uint64_t uint64_eq_const_121_0;
    uint8_t uint8_eq_const_122_0;
    uint16_t uint16_eq_const_123_0;
    uint8_t uint8_eq_const_124_0;
    uint16_t uint16_eq_const_125_0;
    uint64_t uint64_eq_const_126_0;
    uint64_t uint64_eq_const_127_0;

    if (size < 456)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_32_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_33_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_52_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_56_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_57_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_63_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_64_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_65_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_66_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_67_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_68_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_69_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_71_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_72_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_73_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_74_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_75_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_76_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_77_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_78_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_79_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_81_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_82_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_83_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_85_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_86_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_87_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_88_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_89_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_91_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_92_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_94_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_95_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_97_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_98_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_99_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_100_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_101_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_103_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_104_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_105_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_106_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_107_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_108_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_109_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_110_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_111_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_112_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_113_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_114_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_115_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_116_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_117_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_118_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_119_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_120_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_121_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_122_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_123_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_125_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_126_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_127_0, &data[i], 8);
    i += 8;


    if (uint32_eq_const_0_0 == 2069896248)
    if (uint8_eq_const_1_0 == 22)
    if (uint8_eq_const_2_0 == 31)
    if (uint64_eq_const_3_0 == 897042578289693280u)
    if (uint16_eq_const_4_0 == 17160)
    if (uint64_eq_const_5_0 == 13680559181738676829u)
    if (uint32_eq_const_6_0 == 1517047307)
    if (uint32_eq_const_7_0 == 172247733)
    if (uint8_eq_const_8_0 == 242)
    if (uint32_eq_const_9_0 == 4013321523)
    if (uint64_eq_const_10_0 == 2167645662031867415u)
    if (uint8_eq_const_11_0 == 133)
    if (uint64_eq_const_12_0 == 14223320245120553178u)
    if (uint32_eq_const_13_0 == 564088224)
    if (uint16_eq_const_14_0 == 2662)
    if (uint32_eq_const_15_0 == 3528569205)
    if (uint64_eq_const_16_0 == 3437984455681637929u)
    if (uint32_eq_const_17_0 == 1216410189)
    if (uint16_eq_const_18_0 == 38288)
    if (uint8_eq_const_19_0 == 168)
    if (uint64_eq_const_20_0 == 5866729069013411510u)
    if (uint32_eq_const_21_0 == 3965369155)
    if (uint16_eq_const_22_0 == 24129)
    if (uint64_eq_const_23_0 == 13964540162758447788u)
    if (uint64_eq_const_24_0 == 786041802897296393u)
    if (uint16_eq_const_25_0 == 25544)
    if (uint64_eq_const_26_0 == 10523845513589691274u)
    if (uint64_eq_const_27_0 == 4181587344867985555u)
    if (uint16_eq_const_28_0 == 18528)
    if (uint16_eq_const_29_0 == 23724)
    if (uint16_eq_const_30_0 == 34411)
    if (uint8_eq_const_31_0 == 155)
    if (uint32_eq_const_32_0 == 119197640)
    if (uint32_eq_const_33_0 == 833487173)
    if (uint32_eq_const_34_0 == 1759784856)
    if (uint8_eq_const_35_0 == 119)
    if (uint32_eq_const_36_0 == 2129912947)
    if (uint32_eq_const_37_0 == 478021279)
    if (uint8_eq_const_38_0 == 56)
    if (uint8_eq_const_39_0 == 224)
    if (uint32_eq_const_40_0 == 3438562427)
    if (uint8_eq_const_41_0 == 49)
    if (uint8_eq_const_42_0 == 21)
    if (uint64_eq_const_43_0 == 11052409905627227594u)
    if (uint8_eq_const_44_0 == 118)
    if (uint16_eq_const_45_0 == 13903)
    if (uint8_eq_const_46_0 == 65)
    if (uint32_eq_const_47_0 == 3756756165)
    if (uint64_eq_const_48_0 == 2002399311664488508u)
    if (uint32_eq_const_49_0 == 3469102022)
    if (uint8_eq_const_50_0 == 54)
    if (uint64_eq_const_51_0 == 12623713280992230427u)
    if (uint64_eq_const_52_0 == 14221298273424944223u)
    if (uint8_eq_const_53_0 == 52)
    if (uint16_eq_const_54_0 == 29488)
    if (uint8_eq_const_55_0 == 24)
    if (uint32_eq_const_56_0 == 888223947)
    if (uint8_eq_const_57_0 == 164)
    if (uint64_eq_const_58_0 == 14184298404235054935u)
    if (uint8_eq_const_59_0 == 192)
    if (uint16_eq_const_60_0 == 55142)
    if (uint64_eq_const_61_0 == 17565606751172167125u)
    if (uint32_eq_const_62_0 == 856746254)
    if (uint32_eq_const_63_0 == 3954832096)
    if (uint64_eq_const_64_0 == 141628118770202492u)
    if (uint32_eq_const_65_0 == 1336215368)
    if (uint64_eq_const_66_0 == 14539516811277811883u)
    if (uint64_eq_const_67_0 == 8521656868388377505u)
    if (uint16_eq_const_68_0 == 23076)
    if (uint8_eq_const_69_0 == 241)
    if (uint8_eq_const_70_0 == 3)
    if (uint16_eq_const_71_0 == 5579)
    if (uint8_eq_const_72_0 == 118)
    if (uint16_eq_const_73_0 == 48484)
    if (uint8_eq_const_74_0 == 173)
    if (uint64_eq_const_75_0 == 13491967048019404384u)
    if (uint32_eq_const_76_0 == 52955742)
    if (uint16_eq_const_77_0 == 7681)
    if (uint32_eq_const_78_0 == 3355144964)
    if (uint64_eq_const_79_0 == 7865141350202557566u)
    if (uint8_eq_const_80_0 == 240)
    if (uint16_eq_const_81_0 == 5521)
    if (uint8_eq_const_82_0 == 239)
    if (uint8_eq_const_83_0 == 24)
    if (uint8_eq_const_84_0 == 137)
    if (uint32_eq_const_85_0 == 2156264645)
    if (uint16_eq_const_86_0 == 46048)
    if (uint16_eq_const_87_0 == 53780)
    if (uint16_eq_const_88_0 == 37497)
    if (uint8_eq_const_89_0 == 179)
    if (uint64_eq_const_90_0 == 5781058054434132576u)
    if (uint64_eq_const_91_0 == 13629053215668524558u)
    if (uint32_eq_const_92_0 == 4123450595)
    if (uint8_eq_const_93_0 == 44)
    if (uint16_eq_const_94_0 == 2998)
    if (uint16_eq_const_95_0 == 24421)
    if (uint8_eq_const_96_0 == 226)
    if (uint16_eq_const_97_0 == 53937)
    if (uint8_eq_const_98_0 == 204)
    if (uint8_eq_const_99_0 == 108)
    if (uint8_eq_const_100_0 == 170)
    if (uint32_eq_const_101_0 == 1564596207)
    if (uint8_eq_const_102_0 == 52)
    if (uint16_eq_const_103_0 == 14273)
    if (uint32_eq_const_104_0 == 582998588)
    if (uint32_eq_const_105_0 == 3543981757)
    if (uint8_eq_const_106_0 == 238)
    if (uint64_eq_const_107_0 == 15108275527880131637u)
    if (uint8_eq_const_108_0 == 193)
    if (uint32_eq_const_109_0 == 3009200999)
    if (uint8_eq_const_110_0 == 190)
    if (uint16_eq_const_111_0 == 34878)
    if (uint64_eq_const_112_0 == 3549836825774777071u)
    if (uint64_eq_const_113_0 == 5367146415350246886u)
    if (uint64_eq_const_114_0 == 4974107375755966252u)
    if (uint32_eq_const_115_0 == 3887970888)
    if (uint8_eq_const_116_0 == 170)
    if (uint16_eq_const_117_0 == 60375)
    if (uint8_eq_const_118_0 == 83)
    if (uint16_eq_const_119_0 == 39220)
    if (uint32_eq_const_120_0 == 3819924412)
    if (uint64_eq_const_121_0 == 4408788987810757340u)
    if (uint8_eq_const_122_0 == 35)
    if (uint16_eq_const_123_0 == 30897)
    if (uint8_eq_const_124_0 == 23)
    if (uint16_eq_const_125_0 == 36028)
    if (uint64_eq_const_126_0 == 14998378753972127614u)
    if (uint64_eq_const_127_0 == 459317890184846574u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
