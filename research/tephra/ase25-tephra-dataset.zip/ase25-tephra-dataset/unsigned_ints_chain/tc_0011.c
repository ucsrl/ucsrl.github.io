#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;

    if (size < 51)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;


    if (uint64_eq_const_0_0 == 9784206241361647647u)
    if (uint64_eq_const_1_0 == 6735118498617410369u)
    if (uint32_eq_const_2_0 == 2313779149)
    if (uint8_eq_const_3_0 == 19)
    if (uint32_eq_const_4_0 == 3455709536)
    if (uint64_eq_const_5_0 == 493620696264573684u)
    if (uint32_eq_const_6_0 == 2486365316)
    if (uint8_eq_const_7_0 == 91)
    if (uint8_eq_const_8_0 == 92)
    if (uint64_eq_const_9_0 == 2575588197121449184u)
    if (uint32_eq_const_10_0 == 2259487670)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
