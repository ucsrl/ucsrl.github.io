#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint32_t uint32_eq_const_5_0;
    uint16_t uint16_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;

    if (size < 45)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;


    if (uint64_eq_const_0_0 == 6144393435780948362u)
    if (uint16_eq_const_1_0 == 26861)
    if (uint32_eq_const_2_0 == 19312425)
    if (uint64_eq_const_3_0 == 822769306409976732u)
    if (uint64_eq_const_4_0 == 17588804737465148700u)
    if (uint32_eq_const_5_0 == 1874926715)
    if (uint16_eq_const_6_0 == 9545)
    if (uint8_eq_const_7_0 == 10)
    if (uint32_eq_const_8_0 == 2544346141)
    if (uint32_eq_const_9_0 == 1185741869)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
