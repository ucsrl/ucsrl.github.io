#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint32_t uint32_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint32_t uint32_eq_const_4_0;
    uint16_t uint16_eq_const_5_0;
    uint8_t uint8_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint32_t uint32_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint8_t uint8_eq_const_11_0;

    if (size < 39)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_11_0, &data[i], 1);
    i += 1;


    if (uint32_eq_const_0_0 == 3553429501)
    if (uint16_eq_const_1_0 == 31708)
    if (uint32_eq_const_2_0 == 2674462384)
    if (uint64_eq_const_3_0 == 14169976314798524249u)
    if (uint32_eq_const_4_0 == 3493256105)
    if (uint16_eq_const_5_0 == 25780)
    if (uint8_eq_const_6_0 == 88)
    if (uint8_eq_const_7_0 == 117)
    if (uint32_eq_const_8_0 == 2116980428)
    if (uint32_eq_const_9_0 == 627701808)
    if (uint32_eq_const_10_0 == 2199032313)
    if (uint8_eq_const_11_0 == 232)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
