#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint32_t uint32_eq_const_0_0;
    uint16_t uint16_eq_const_1_0;
    uint16_t uint16_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint32_t uint32_eq_const_8_0;
    uint8_t uint8_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint32_t uint32_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint8_t uint8_eq_const_13_0;
    uint16_t uint16_eq_const_14_0;
    uint8_t uint8_eq_const_15_0;
    uint64_t uint64_eq_const_16_0;
    uint8_t uint8_eq_const_17_0;
    uint64_t uint64_eq_const_18_0;
    uint8_t uint8_eq_const_19_0;
    uint64_t uint64_eq_const_20_0;
    uint32_t uint32_eq_const_21_0;
    uint64_t uint64_eq_const_22_0;
    uint16_t uint16_eq_const_23_0;
    uint16_t uint16_eq_const_24_0;
    uint16_t uint16_eq_const_25_0;
    uint16_t uint16_eq_const_26_0;
    uint16_t uint16_eq_const_27_0;
    uint64_t uint64_eq_const_28_0;
    uint8_t uint8_eq_const_29_0;
    uint64_t uint64_eq_const_30_0;
    uint64_t uint64_eq_const_31_0;
    uint64_t uint64_eq_const_32_0;
    uint64_t uint64_eq_const_33_0;
    uint16_t uint16_eq_const_34_0;
    uint64_t uint64_eq_const_35_0;
    uint16_t uint16_eq_const_36_0;
    uint32_t uint32_eq_const_37_0;
    uint8_t uint8_eq_const_38_0;
    uint32_t uint32_eq_const_39_0;
    uint8_t uint8_eq_const_40_0;
    uint8_t uint8_eq_const_41_0;
    uint64_t uint64_eq_const_42_0;
    uint8_t uint8_eq_const_43_0;
    uint16_t uint16_eq_const_44_0;
    uint16_t uint16_eq_const_45_0;
    uint32_t uint32_eq_const_46_0;
    uint16_t uint16_eq_const_47_0;
    uint16_t uint16_eq_const_48_0;
    uint8_t uint8_eq_const_49_0;
    uint8_t uint8_eq_const_50_0;
    uint16_t uint16_eq_const_51_0;
    uint8_t uint8_eq_const_52_0;
    uint64_t uint64_eq_const_53_0;
    uint16_t uint16_eq_const_54_0;
    uint16_t uint16_eq_const_55_0;
    uint64_t uint64_eq_const_56_0;
    uint32_t uint32_eq_const_57_0;
    uint32_t uint32_eq_const_58_0;
    uint64_t uint64_eq_const_59_0;
    uint32_t uint32_eq_const_60_0;
    uint16_t uint16_eq_const_61_0;
    uint32_t uint32_eq_const_62_0;
    uint64_t uint64_eq_const_63_0;
    uint8_t uint8_eq_const_64_0;
    uint16_t uint16_eq_const_65_0;
    uint8_t uint8_eq_const_66_0;
    uint16_t uint16_eq_const_67_0;
    uint16_t uint16_eq_const_68_0;
    uint64_t uint64_eq_const_69_0;
    uint8_t uint8_eq_const_70_0;
    uint16_t uint16_eq_const_71_0;
    uint64_t uint64_eq_const_72_0;
    uint8_t uint8_eq_const_73_0;
    uint16_t uint16_eq_const_74_0;
    uint32_t uint32_eq_const_75_0;
    uint8_t uint8_eq_const_76_0;
    uint16_t uint16_eq_const_77_0;
    uint8_t uint8_eq_const_78_0;
    uint32_t uint32_eq_const_79_0;
    uint8_t uint8_eq_const_80_0;
    uint8_t uint8_eq_const_81_0;
    uint32_t uint32_eq_const_82_0;
    uint64_t uint64_eq_const_83_0;
    uint8_t uint8_eq_const_84_0;
    uint64_t uint64_eq_const_85_0;
    uint64_t uint64_eq_const_86_0;
    uint32_t uint32_eq_const_87_0;
    uint8_t uint8_eq_const_88_0;
    uint64_t uint64_eq_const_89_0;
    uint64_t uint64_eq_const_90_0;
    uint64_t uint64_eq_const_91_0;
    uint8_t uint8_eq_const_92_0;
    uint8_t uint8_eq_const_93_0;
    uint8_t uint8_eq_const_94_0;
    uint32_t uint32_eq_const_95_0;
    uint8_t uint8_eq_const_96_0;
    uint16_t uint16_eq_const_97_0;
    uint16_t uint16_eq_const_98_0;
    uint32_t uint32_eq_const_99_0;
    uint32_t uint32_eq_const_100_0;
    uint16_t uint16_eq_const_101_0;
    uint8_t uint8_eq_const_102_0;
    uint32_t uint32_eq_const_103_0;
    uint32_t uint32_eq_const_104_0;
    uint8_t uint8_eq_const_105_0;
    uint16_t uint16_eq_const_106_0;
    uint16_t uint16_eq_const_107_0;
    uint32_t uint32_eq_const_108_0;
    uint16_t uint16_eq_const_109_0;
    uint8_t uint8_eq_const_110_0;
    uint16_t uint16_eq_const_111_0;
    uint32_t uint32_eq_const_112_0;
    uint64_t uint64_eq_const_113_0;
    uint64_t uint64_eq_const_114_0;
    uint8_t uint8_eq_const_115_0;
    uint32_t uint32_eq_const_116_0;
    uint16_t uint16_eq_const_117_0;
    uint32_t uint32_eq_const_118_0;
    uint32_t uint32_eq_const_119_0;
    uint64_t uint64_eq_const_120_0;
    uint8_t uint8_eq_const_121_0;
    uint32_t uint32_eq_const_122_0;
    uint8_t uint8_eq_const_123_0;
    uint8_t uint8_eq_const_124_0;
    uint64_t uint64_eq_const_125_0;
    uint16_t uint16_eq_const_126_0;
    uint16_t uint16_eq_const_127_0;
    uint16_t uint16_eq_const_128_0;
    uint32_t uint32_eq_const_129_0;
    uint8_t uint8_eq_const_130_0;
    uint64_t uint64_eq_const_131_0;
    uint8_t uint8_eq_const_132_0;
    uint64_t uint64_eq_const_133_0;
    uint64_t uint64_eq_const_134_0;
    uint16_t uint16_eq_const_135_0;
    uint32_t uint32_eq_const_136_0;
    uint16_t uint16_eq_const_137_0;
    uint64_t uint64_eq_const_138_0;
    uint32_t uint32_eq_const_139_0;
    uint8_t uint8_eq_const_140_0;
    uint32_t uint32_eq_const_141_0;
    uint32_t uint32_eq_const_142_0;
    uint8_t uint8_eq_const_143_0;
    uint16_t uint16_eq_const_144_0;
    uint64_t uint64_eq_const_145_0;
    uint64_t uint64_eq_const_146_0;
    uint8_t uint8_eq_const_147_0;
    uint64_t uint64_eq_const_148_0;
    uint32_t uint32_eq_const_149_0;
    uint8_t uint8_eq_const_150_0;
    uint8_t uint8_eq_const_151_0;
    uint8_t uint8_eq_const_152_0;
    uint32_t uint32_eq_const_153_0;
    uint64_t uint64_eq_const_154_0;
    uint16_t uint16_eq_const_155_0;
    uint64_t uint64_eq_const_156_0;
    uint16_t uint16_eq_const_157_0;
    uint64_t uint64_eq_const_158_0;
    uint32_t uint32_eq_const_159_0;
    uint64_t uint64_eq_const_160_0;
    uint32_t uint32_eq_const_161_0;
    uint64_t uint64_eq_const_162_0;
    uint64_t uint64_eq_const_163_0;
    uint16_t uint16_eq_const_164_0;
    uint64_t uint64_eq_const_165_0;
    uint16_t uint16_eq_const_166_0;
    uint64_t uint64_eq_const_167_0;
    uint8_t uint8_eq_const_168_0;
    uint8_t uint8_eq_const_169_0;
    uint64_t uint64_eq_const_170_0;
    uint8_t uint8_eq_const_171_0;
    uint64_t uint64_eq_const_172_0;
    uint32_t uint32_eq_const_173_0;
    uint16_t uint16_eq_const_174_0;
    uint16_t uint16_eq_const_175_0;
    uint64_t uint64_eq_const_176_0;
    uint16_t uint16_eq_const_177_0;
    uint32_t uint32_eq_const_178_0;
    uint16_t uint16_eq_const_179_0;
    uint16_t uint16_eq_const_180_0;
    uint16_t uint16_eq_const_181_0;
    uint16_t uint16_eq_const_182_0;
    uint64_t uint64_eq_const_183_0;
    uint64_t uint64_eq_const_184_0;
    uint32_t uint32_eq_const_185_0;
    uint32_t uint32_eq_const_186_0;
    uint8_t uint8_eq_const_187_0;
    uint16_t uint16_eq_const_188_0;
    uint16_t uint16_eq_const_189_0;
    uint64_t uint64_eq_const_190_0;
    uint16_t uint16_eq_const_191_0;
    uint8_t uint8_eq_const_192_0;
    uint8_t uint8_eq_const_193_0;
    uint8_t uint8_eq_const_194_0;
    uint16_t uint16_eq_const_195_0;
    uint64_t uint64_eq_const_196_0;
    uint64_t uint64_eq_const_197_0;
    uint8_t uint8_eq_const_198_0;
    uint8_t uint8_eq_const_199_0;
    uint16_t uint16_eq_const_200_0;
    uint32_t uint32_eq_const_201_0;
    uint16_t uint16_eq_const_202_0;
    uint8_t uint8_eq_const_203_0;
    uint16_t uint16_eq_const_204_0;
    uint64_t uint64_eq_const_205_0;
    uint16_t uint16_eq_const_206_0;
    uint64_t uint64_eq_const_207_0;
    uint32_t uint32_eq_const_208_0;
    uint8_t uint8_eq_const_209_0;
    uint8_t uint8_eq_const_210_0;
    uint16_t uint16_eq_const_211_0;
    uint64_t uint64_eq_const_212_0;
    uint16_t uint16_eq_const_213_0;
    uint64_t uint64_eq_const_214_0;
    uint16_t uint16_eq_const_215_0;
    uint8_t uint8_eq_const_216_0;
    uint16_t uint16_eq_const_217_0;
    uint8_t uint8_eq_const_218_0;
    uint64_t uint64_eq_const_219_0;
    uint64_t uint64_eq_const_220_0;
    uint64_t uint64_eq_const_221_0;
    uint16_t uint16_eq_const_222_0;
    uint64_t uint64_eq_const_223_0;
    uint64_t uint64_eq_const_224_0;
    uint16_t uint16_eq_const_225_0;
    uint64_t uint64_eq_const_226_0;
    uint64_t uint64_eq_const_227_0;
    uint64_t uint64_eq_const_228_0;
    uint16_t uint16_eq_const_229_0;
    uint16_t uint16_eq_const_230_0;
    uint16_t uint16_eq_const_231_0;
    uint64_t uint64_eq_const_232_0;
    uint8_t uint8_eq_const_233_0;
    uint64_t uint64_eq_const_234_0;
    uint16_t uint16_eq_const_235_0;
    uint64_t uint64_eq_const_236_0;
    uint64_t uint64_eq_const_237_0;
    uint16_t uint16_eq_const_238_0;
    uint64_t uint64_eq_const_239_0;
    uint64_t uint64_eq_const_240_0;
    uint64_t uint64_eq_const_241_0;
    uint64_t uint64_eq_const_242_0;
    uint32_t uint32_eq_const_243_0;
    uint8_t uint8_eq_const_244_0;
    uint8_t uint8_eq_const_245_0;
    uint16_t uint16_eq_const_246_0;
    uint8_t uint8_eq_const_247_0;
    uint32_t uint32_eq_const_248_0;
    uint64_t uint64_eq_const_249_0;
    uint16_t uint16_eq_const_250_0;
    uint64_t uint64_eq_const_251_0;
    uint32_t uint32_eq_const_252_0;
    uint8_t uint8_eq_const_253_0;
    uint64_t uint64_eq_const_254_0;
    uint32_t uint32_eq_const_255_0;

    if (size < 993)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_31_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_36_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_39_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_40_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_44_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_47_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_48_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_51_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_55_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_60_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_61_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_63_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_64_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_65_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_66_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_67_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_68_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_69_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_71_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_73_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_74_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_75_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_76_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_77_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_78_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_79_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_81_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_82_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_83_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_86_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_87_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_88_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_89_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_91_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_92_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_94_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_95_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_97_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_98_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_99_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_100_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_101_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_103_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_104_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_105_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_106_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_107_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_108_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_109_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_110_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_111_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_112_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_113_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_114_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_115_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_116_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_117_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_118_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_119_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_120_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_121_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_122_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_123_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_125_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_126_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_127_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_128_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_129_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_130_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_131_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_132_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_133_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_134_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_135_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_136_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_137_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_138_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_139_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_140_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_141_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_142_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_143_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_144_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_145_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_146_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_147_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_148_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_149_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_150_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_151_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_152_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_153_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_154_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_155_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_156_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_157_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_158_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_159_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_160_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_161_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_162_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_163_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_164_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_165_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_166_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_167_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_168_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_169_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_170_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_171_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_172_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_173_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_174_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_175_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_176_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_177_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_178_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_179_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_180_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_181_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_182_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_183_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_184_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_185_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_186_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_187_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_188_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_189_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_190_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_191_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_192_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_193_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_194_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_195_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_196_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_197_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_198_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_199_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_200_0, &data[i], 2);
    i += 2;
    memcpy(&uint32_eq_const_201_0, &data[i], 4);
    i += 4;
    memcpy(&uint16_eq_const_202_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_203_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_204_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_205_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_206_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_207_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_208_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_209_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_210_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_211_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_212_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_213_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_214_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_215_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_216_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_217_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_218_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_219_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_220_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_221_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_222_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_223_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_224_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_225_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_226_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_227_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_228_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_229_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_230_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_231_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_232_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_233_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_234_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_235_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_236_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_237_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_238_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_239_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_240_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_241_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_242_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_243_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_244_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_245_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_246_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_247_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_248_0, &data[i], 4);
    i += 4;
    memcpy(&uint64_eq_const_249_0, &data[i], 8);
    i += 8;
    memcpy(&uint16_eq_const_250_0, &data[i], 2);
    i += 2;
    memcpy(&uint64_eq_const_251_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_252_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_253_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_254_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_255_0, &data[i], 4);
    i += 4;


    if (uint32_eq_const_0_0 == 26764053)
    if (uint16_eq_const_1_0 == 56156)
    if (uint16_eq_const_2_0 == 24542)
    if (uint8_eq_const_3_0 == 239)
    if (uint64_eq_const_4_0 == 13803600329450006092u)
    if (uint8_eq_const_5_0 == 2)
    if (uint32_eq_const_6_0 == 1708256790)
    if (uint64_eq_const_7_0 == 16198744185747447250u)
    if (uint32_eq_const_8_0 == 689893225)
    if (uint8_eq_const_9_0 == 49)
    if (uint32_eq_const_10_0 == 1390363614)
    if (uint32_eq_const_11_0 == 3775523847)
    if (uint16_eq_const_12_0 == 20396)
    if (uint8_eq_const_13_0 == 249)
    if (uint16_eq_const_14_0 == 21563)
    if (uint8_eq_const_15_0 == 172)
    if (uint64_eq_const_16_0 == 4079749578182300216u)
    if (uint8_eq_const_17_0 == 190)
    if (uint64_eq_const_18_0 == 14416822246587836377u)
    if (uint8_eq_const_19_0 == 228)
    if (uint64_eq_const_20_0 == 5434054283893710728u)
    if (uint32_eq_const_21_0 == 2853502276)
    if (uint64_eq_const_22_0 == 3824422371079391477u)
    if (uint16_eq_const_23_0 == 11532)
    if (uint16_eq_const_24_0 == 17078)
    if (uint16_eq_const_25_0 == 13670)
    if (uint16_eq_const_26_0 == 46804)
    if (uint16_eq_const_27_0 == 60221)
    if (uint64_eq_const_28_0 == 4016611923613991865u)
    if (uint8_eq_const_29_0 == 165)
    if (uint64_eq_const_30_0 == 9683529068691612228u)
    if (uint64_eq_const_31_0 == 15288501471513365014u)
    if (uint64_eq_const_32_0 == 7007175284356737733u)
    if (uint64_eq_const_33_0 == 3090006668402134812u)
    if (uint16_eq_const_34_0 == 11369)
    if (uint64_eq_const_35_0 == 7440378664477864605u)
    if (uint16_eq_const_36_0 == 10672)
    if (uint32_eq_const_37_0 == 598077179)
    if (uint8_eq_const_38_0 == 88)
    if (uint32_eq_const_39_0 == 761261974)
    if (uint8_eq_const_40_0 == 82)
    if (uint8_eq_const_41_0 == 222)
    if (uint64_eq_const_42_0 == 5870415438049999664u)
    if (uint8_eq_const_43_0 == 18)
    if (uint16_eq_const_44_0 == 62720)
    if (uint16_eq_const_45_0 == 39934)
    if (uint32_eq_const_46_0 == 1766551328)
    if (uint16_eq_const_47_0 == 31036)
    if (uint16_eq_const_48_0 == 20949)
    if (uint8_eq_const_49_0 == 12)
    if (uint8_eq_const_50_0 == 244)
    if (uint16_eq_const_51_0 == 46866)
    if (uint8_eq_const_52_0 == 142)
    if (uint64_eq_const_53_0 == 5889871633771706345u)
    if (uint16_eq_const_54_0 == 49414)
    if (uint16_eq_const_55_0 == 33224)
    if (uint64_eq_const_56_0 == 12320858255540680613u)
    if (uint32_eq_const_57_0 == 3223114633)
    if (uint32_eq_const_58_0 == 723523432)
    if (uint64_eq_const_59_0 == 8425524414862651279u)
    if (uint32_eq_const_60_0 == 1088922784)
    if (uint16_eq_const_61_0 == 60208)
    if (uint32_eq_const_62_0 == 2335689095)
    if (uint64_eq_const_63_0 == 4614098383702611195u)
    if (uint8_eq_const_64_0 == 203)
    if (uint16_eq_const_65_0 == 15940)
    if (uint8_eq_const_66_0 == 216)
    if (uint16_eq_const_67_0 == 15779)
    if (uint16_eq_const_68_0 == 39896)
    if (uint64_eq_const_69_0 == 6106212860351246264u)
    if (uint8_eq_const_70_0 == 19)
    if (uint16_eq_const_71_0 == 11200)
    if (uint64_eq_const_72_0 == 15203995913816286277u)
    if (uint8_eq_const_73_0 == 129)
    if (uint16_eq_const_74_0 == 12404)
    if (uint32_eq_const_75_0 == 2123511050)
    if (uint8_eq_const_76_0 == 50)
    if (uint16_eq_const_77_0 == 31550)
    if (uint8_eq_const_78_0 == 26)
    if (uint32_eq_const_79_0 == 1317398783)
    if (uint8_eq_const_80_0 == 221)
    if (uint8_eq_const_81_0 == 232)
    if (uint32_eq_const_82_0 == 2079598498)
    if (uint64_eq_const_83_0 == 3671917415145036390u)
    if (uint8_eq_const_84_0 == 152)
    if (uint64_eq_const_85_0 == 11992479715796809688u)
    if (uint64_eq_const_86_0 == 17977917856688291598u)
    if (uint32_eq_const_87_0 == 1930196258)
    if (uint8_eq_const_88_0 == 148)
    if (uint64_eq_const_89_0 == 18074888893582969076u)
    if (uint64_eq_const_90_0 == 13884163588859787317u)
    if (uint64_eq_const_91_0 == 15472851376067512653u)
    if (uint8_eq_const_92_0 == 48)
    if (uint8_eq_const_93_0 == 124)
    if (uint8_eq_const_94_0 == 57)
    if (uint32_eq_const_95_0 == 163391176)
    if (uint8_eq_const_96_0 == 188)
    if (uint16_eq_const_97_0 == 32676)
    if (uint16_eq_const_98_0 == 3426)
    if (uint32_eq_const_99_0 == 4078445570)
    if (uint32_eq_const_100_0 == 3130710980)
    if (uint16_eq_const_101_0 == 63144)
    if (uint8_eq_const_102_0 == 156)
    if (uint32_eq_const_103_0 == 2609754841)
    if (uint32_eq_const_104_0 == 3285556328)
    if (uint8_eq_const_105_0 == 53)
    if (uint16_eq_const_106_0 == 34013)
    if (uint16_eq_const_107_0 == 15846)
    if (uint32_eq_const_108_0 == 3085987004)
    if (uint16_eq_const_109_0 == 54113)
    if (uint8_eq_const_110_0 == 190)
    if (uint16_eq_const_111_0 == 58397)
    if (uint32_eq_const_112_0 == 2564886107)
    if (uint64_eq_const_113_0 == 16868853071502262519u)
    if (uint64_eq_const_114_0 == 8482337485472607169u)
    if (uint8_eq_const_115_0 == 132)
    if (uint32_eq_const_116_0 == 224452205)
    if (uint16_eq_const_117_0 == 18703)
    if (uint32_eq_const_118_0 == 3317234284)
    if (uint32_eq_const_119_0 == 3960814222)
    if (uint64_eq_const_120_0 == 4535006815968326018u)
    if (uint8_eq_const_121_0 == 208)
    if (uint32_eq_const_122_0 == 271071296)
    if (uint8_eq_const_123_0 == 220)
    if (uint8_eq_const_124_0 == 128)
    if (uint64_eq_const_125_0 == 605417926066982352u)
    if (uint16_eq_const_126_0 == 54577)
    if (uint16_eq_const_127_0 == 48333)
    if (uint16_eq_const_128_0 == 60255)
    if (uint32_eq_const_129_0 == 1042859555)
    if (uint8_eq_const_130_0 == 139)
    if (uint64_eq_const_131_0 == 15047500276745126041u)
    if (uint8_eq_const_132_0 == 241)
    if (uint64_eq_const_133_0 == 15257325876243860652u)
    if (uint64_eq_const_134_0 == 2908328219107347024u)
    if (uint16_eq_const_135_0 == 34356)
    if (uint32_eq_const_136_0 == 2809510012)
    if (uint16_eq_const_137_0 == 16567)
    if (uint64_eq_const_138_0 == 14487092204691661308u)
    if (uint32_eq_const_139_0 == 2228455918)
    if (uint8_eq_const_140_0 == 118)
    if (uint32_eq_const_141_0 == 898297573)
    if (uint32_eq_const_142_0 == 337814835)
    if (uint8_eq_const_143_0 == 79)
    if (uint16_eq_const_144_0 == 47425)
    if (uint64_eq_const_145_0 == 12084405064848931950u)
    if (uint64_eq_const_146_0 == 14905015696654512766u)
    if (uint8_eq_const_147_0 == 11)
    if (uint64_eq_const_148_0 == 12955330001719784439u)
    if (uint32_eq_const_149_0 == 519445943)
    if (uint8_eq_const_150_0 == 87)
    if (uint8_eq_const_151_0 == 143)
    if (uint8_eq_const_152_0 == 84)
    if (uint32_eq_const_153_0 == 2017697725)
    if (uint64_eq_const_154_0 == 11215182277574407645u)
    if (uint16_eq_const_155_0 == 24661)
    if (uint64_eq_const_156_0 == 1345294616440419953u)
    if (uint16_eq_const_157_0 == 30554)
    if (uint64_eq_const_158_0 == 8156454908825662184u)
    if (uint32_eq_const_159_0 == 943551443)
    if (uint64_eq_const_160_0 == 6043911193686956848u)
    if (uint32_eq_const_161_0 == 3963174518)
    if (uint64_eq_const_162_0 == 3794836801479585014u)
    if (uint64_eq_const_163_0 == 14650875058960674743u)
    if (uint16_eq_const_164_0 == 48877)
    if (uint64_eq_const_165_0 == 16563400500756963371u)
    if (uint16_eq_const_166_0 == 58267)
    if (uint64_eq_const_167_0 == 2969109433568528039u)
    if (uint8_eq_const_168_0 == 253)
    if (uint8_eq_const_169_0 == 104)
    if (uint64_eq_const_170_0 == 17646887360304122341u)
    if (uint8_eq_const_171_0 == 149)
    if (uint64_eq_const_172_0 == 9383869488687436124u)
    if (uint32_eq_const_173_0 == 1576674003)
    if (uint16_eq_const_174_0 == 42123)
    if (uint16_eq_const_175_0 == 197)
    if (uint64_eq_const_176_0 == 1161289458101558742u)
    if (uint16_eq_const_177_0 == 4157)
    if (uint32_eq_const_178_0 == 1911397225)
    if (uint16_eq_const_179_0 == 22709)
    if (uint16_eq_const_180_0 == 58539)
    if (uint16_eq_const_181_0 == 14370)
    if (uint16_eq_const_182_0 == 7476)
    if (uint64_eq_const_183_0 == 13789741294050956099u)
    if (uint64_eq_const_184_0 == 11439762775783981956u)
    if (uint32_eq_const_185_0 == 3882817557)
    if (uint32_eq_const_186_0 == 2263351050)
    if (uint8_eq_const_187_0 == 89)
    if (uint16_eq_const_188_0 == 12666)
    if (uint16_eq_const_189_0 == 57171)
    if (uint64_eq_const_190_0 == 8284144453835404414u)
    if (uint16_eq_const_191_0 == 51409)
    if (uint8_eq_const_192_0 == 119)
    if (uint8_eq_const_193_0 == 157)
    if (uint8_eq_const_194_0 == 86)
    if (uint16_eq_const_195_0 == 42137)
    if (uint64_eq_const_196_0 == 4688537789819201350u)
    if (uint64_eq_const_197_0 == 6680959183180228782u)
    if (uint8_eq_const_198_0 == 7)
    if (uint8_eq_const_199_0 == 32)
    if (uint16_eq_const_200_0 == 5795)
    if (uint32_eq_const_201_0 == 2062582085)
    if (uint16_eq_const_202_0 == 22047)
    if (uint8_eq_const_203_0 == 242)
    if (uint16_eq_const_204_0 == 10620)
    if (uint64_eq_const_205_0 == 5353321829687490892u)
    if (uint16_eq_const_206_0 == 24914)
    if (uint64_eq_const_207_0 == 17865602821460503831u)
    if (uint32_eq_const_208_0 == 1869461628)
    if (uint8_eq_const_209_0 == 11)
    if (uint8_eq_const_210_0 == 175)
    if (uint16_eq_const_211_0 == 30587)
    if (uint64_eq_const_212_0 == 3911239838485686134u)
    if (uint16_eq_const_213_0 == 62848)
    if (uint64_eq_const_214_0 == 17182147879364443582u)
    if (uint16_eq_const_215_0 == 60365)
    if (uint8_eq_const_216_0 == 251)
    if (uint16_eq_const_217_0 == 31760)
    if (uint8_eq_const_218_0 == 143)
    if (uint64_eq_const_219_0 == 3464860778713857465u)
    if (uint64_eq_const_220_0 == 14463886281716701685u)
    if (uint64_eq_const_221_0 == 13470645197977031258u)
    if (uint16_eq_const_222_0 == 20759)
    if (uint64_eq_const_223_0 == 9461855628190543101u)
    if (uint64_eq_const_224_0 == 16184772333959940861u)
    if (uint16_eq_const_225_0 == 50810)
    if (uint64_eq_const_226_0 == 3431272376712687605u)
    if (uint64_eq_const_227_0 == 5654030167659746591u)
    if (uint64_eq_const_228_0 == 105350473557421023u)
    if (uint16_eq_const_229_0 == 58375)
    if (uint16_eq_const_230_0 == 10350)
    if (uint16_eq_const_231_0 == 53255)
    if (uint64_eq_const_232_0 == 3008991948250748546u)
    if (uint8_eq_const_233_0 == 34)
    if (uint64_eq_const_234_0 == 12140328508554952111u)
    if (uint16_eq_const_235_0 == 53120)
    if (uint64_eq_const_236_0 == 6088844365173169697u)
    if (uint64_eq_const_237_0 == 10355162608114948469u)
    if (uint16_eq_const_238_0 == 34270)
    if (uint64_eq_const_239_0 == 4906854668550913260u)
    if (uint64_eq_const_240_0 == 5612582569463817676u)
    if (uint64_eq_const_241_0 == 6422018487505500472u)
    if (uint64_eq_const_242_0 == 16560687550664273029u)
    if (uint32_eq_const_243_0 == 1776066857)
    if (uint8_eq_const_244_0 == 104)
    if (uint8_eq_const_245_0 == 111)
    if (uint16_eq_const_246_0 == 32753)
    if (uint8_eq_const_247_0 == 24)
    if (uint32_eq_const_248_0 == 2396052016)
    if (uint64_eq_const_249_0 == 17079396805082217301u)
    if (uint16_eq_const_250_0 == 17858)
    if (uint64_eq_const_251_0 == 5918665948915668083u)
    if (uint32_eq_const_252_0 == 3813276080)
    if (uint8_eq_const_253_0 == 95)
    if (uint64_eq_const_254_0 == 10655264795612925369u)
    if (uint32_eq_const_255_0 == 3736775716)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
