#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint16_t uint16_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint32_t uint32_eq_const_6_0;
    uint32_t uint32_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint8_t uint8_eq_const_9_0;
    uint32_t uint32_eq_const_10_0;
    uint8_t uint8_eq_const_11_0;
    uint16_t uint16_eq_const_12_0;
    uint16_t uint16_eq_const_13_0;

    if (size < 40)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&uint32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&uint32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&uint8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&uint16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&uint16_eq_const_13_0, &data[i], 2);
    i += 2;


    if (uint16_eq_const_0_0 == 37196)
    if (uint8_eq_const_1_0 == 127)
    if (uint64_eq_const_2_0 == 3392432691347329549u)
    if (uint8_eq_const_3_0 == 233)
    if (uint8_eq_const_4_0 == 192)
    if (uint64_eq_const_5_0 == 3710170943865492017u)
    if (uint32_eq_const_6_0 == 1847021433)
    if (uint32_eq_const_7_0 == 3464938874)
    if (uint8_eq_const_8_0 == 79)
    if (uint8_eq_const_9_0 == 72)
    if (uint32_eq_const_10_0 == 3157282617)
    if (uint8_eq_const_11_0 == 137)
    if (uint16_eq_const_12_0 == 189)
    if (uint16_eq_const_13_0 == 46302)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
