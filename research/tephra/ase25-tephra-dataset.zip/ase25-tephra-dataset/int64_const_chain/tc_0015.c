#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int64_t int64_eq_const_14_0;

    if (size < 120)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_14_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == -7332919709832619375)
    if (int64_eq_const_1_0 == -4536038153002589437)
    if (int64_eq_const_2_0 == -6983341473431127839)
    if (int64_eq_const_3_0 == -2673067601344179626)
    if (int64_eq_const_4_0 == 350557125579769306)
    if (int64_eq_const_5_0 == -4971273498913296668)
    if (int64_eq_const_6_0 == 4039219840176353340)
    if (int64_eq_const_7_0 == -2982272156735275605)
    if (int64_eq_const_8_0 == 2610497026406850589)
    if (int64_eq_const_9_0 == 7898681562881700474)
    if (int64_eq_const_10_0 == 2359676772999738037)
    if (int64_eq_const_11_0 == -8571289038448328216)
    if (int64_eq_const_12_0 == 4877360414496464758)
    if (int64_eq_const_13_0 == 5167840787859070600)
    if (int64_eq_const_14_0 == -5239586333698876832)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
