#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;

    if (size < 88)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == -5025562857975149833)
    if (int64_eq_const_1_0 == -5843495416241995736)
    if (int64_eq_const_2_0 == 5694868678511409995)
    if (int64_eq_const_3_0 == 5111195811822994797)
    if (int64_eq_const_4_0 == -6169532649852302182)
    if (int64_eq_const_5_0 == -1782466964123969572)
    if (int64_eq_const_6_0 == 6802844026563419272)
    if (int64_eq_const_7_0 == 5086654115216342560)
    if (int64_eq_const_8_0 == 8552898714322622292)
    if (int64_eq_const_9_0 == -4004755535478349341)
    if (int64_eq_const_10_0 == -1488139573943419793)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
