#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;

    if (size < 96)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == 6877418189800339820)
    if (int64_eq_const_1_0 == -6523644025635478660)
    if (int64_eq_const_2_0 == -2949796275229152759)
    if (int64_eq_const_3_0 == 1786721879601088065)
    if (int64_eq_const_4_0 == -1599065251699696142)
    if (int64_eq_const_5_0 == -7131096085120997057)
    if (int64_eq_const_6_0 == -7631148909251407357)
    if (int64_eq_const_7_0 == 2971056645043808722)
    if (int64_eq_const_8_0 == -5619672559603971)
    if (int64_eq_const_9_0 == -7572858850093070837)
    if (int64_eq_const_10_0 == -4072991298245223304)
    if (int64_eq_const_11_0 == -8900932582867031355)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
