#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int64_t int64_eq_const_14_0;
    int64_t int64_eq_const_15_0;
    int64_t int64_eq_const_16_0;
    int64_t int64_eq_const_17_0;
    int64_t int64_eq_const_18_0;
    int64_t int64_eq_const_19_0;
    int64_t int64_eq_const_20_0;
    int64_t int64_eq_const_21_0;
    int64_t int64_eq_const_22_0;
    int64_t int64_eq_const_23_0;
    int64_t int64_eq_const_24_0;
    int64_t int64_eq_const_25_0;
    int64_t int64_eq_const_26_0;
    int64_t int64_eq_const_27_0;
    int64_t int64_eq_const_28_0;
    int64_t int64_eq_const_29_0;
    int64_t int64_eq_const_30_0;
    int64_t int64_eq_const_31_0;
    int64_t int64_eq_const_32_0;
    int64_t int64_eq_const_33_0;
    int64_t int64_eq_const_34_0;
    int64_t int64_eq_const_35_0;
    int64_t int64_eq_const_36_0;
    int64_t int64_eq_const_37_0;
    int64_t int64_eq_const_38_0;
    int64_t int64_eq_const_39_0;
    int64_t int64_eq_const_40_0;
    int64_t int64_eq_const_41_0;
    int64_t int64_eq_const_42_0;
    int64_t int64_eq_const_43_0;
    int64_t int64_eq_const_44_0;
    int64_t int64_eq_const_45_0;
    int64_t int64_eq_const_46_0;
    int64_t int64_eq_const_47_0;
    int64_t int64_eq_const_48_0;
    int64_t int64_eq_const_49_0;
    int64_t int64_eq_const_50_0;
    int64_t int64_eq_const_51_0;
    int64_t int64_eq_const_52_0;
    int64_t int64_eq_const_53_0;
    int64_t int64_eq_const_54_0;
    int64_t int64_eq_const_55_0;
    int64_t int64_eq_const_56_0;
    int64_t int64_eq_const_57_0;
    int64_t int64_eq_const_58_0;
    int64_t int64_eq_const_59_0;
    int64_t int64_eq_const_60_0;
    int64_t int64_eq_const_61_0;
    int64_t int64_eq_const_62_0;
    int64_t int64_eq_const_63_0;
    int64_t int64_eq_const_64_0;
    int64_t int64_eq_const_65_0;
    int64_t int64_eq_const_66_0;
    int64_t int64_eq_const_67_0;
    int64_t int64_eq_const_68_0;
    int64_t int64_eq_const_69_0;
    int64_t int64_eq_const_70_0;
    int64_t int64_eq_const_71_0;
    int64_t int64_eq_const_72_0;
    int64_t int64_eq_const_73_0;
    int64_t int64_eq_const_74_0;
    int64_t int64_eq_const_75_0;
    int64_t int64_eq_const_76_0;
    int64_t int64_eq_const_77_0;
    int64_t int64_eq_const_78_0;
    int64_t int64_eq_const_79_0;
    int64_t int64_eq_const_80_0;
    int64_t int64_eq_const_81_0;
    int64_t int64_eq_const_82_0;
    int64_t int64_eq_const_83_0;
    int64_t int64_eq_const_84_0;
    int64_t int64_eq_const_85_0;
    int64_t int64_eq_const_86_0;
    int64_t int64_eq_const_87_0;
    int64_t int64_eq_const_88_0;
    int64_t int64_eq_const_89_0;
    int64_t int64_eq_const_90_0;
    int64_t int64_eq_const_91_0;
    int64_t int64_eq_const_92_0;
    int64_t int64_eq_const_93_0;
    int64_t int64_eq_const_94_0;
    int64_t int64_eq_const_95_0;
    int64_t int64_eq_const_96_0;
    int64_t int64_eq_const_97_0;
    int64_t int64_eq_const_98_0;
    int64_t int64_eq_const_99_0;
    int64_t int64_eq_const_100_0;
    int64_t int64_eq_const_101_0;
    int64_t int64_eq_const_102_0;
    int64_t int64_eq_const_103_0;
    int64_t int64_eq_const_104_0;
    int64_t int64_eq_const_105_0;
    int64_t int64_eq_const_106_0;
    int64_t int64_eq_const_107_0;
    int64_t int64_eq_const_108_0;
    int64_t int64_eq_const_109_0;
    int64_t int64_eq_const_110_0;
    int64_t int64_eq_const_111_0;
    int64_t int64_eq_const_112_0;
    int64_t int64_eq_const_113_0;
    int64_t int64_eq_const_114_0;
    int64_t int64_eq_const_115_0;
    int64_t int64_eq_const_116_0;
    int64_t int64_eq_const_117_0;
    int64_t int64_eq_const_118_0;
    int64_t int64_eq_const_119_0;
    int64_t int64_eq_const_120_0;
    int64_t int64_eq_const_121_0;
    int64_t int64_eq_const_122_0;
    int64_t int64_eq_const_123_0;
    int64_t int64_eq_const_124_0;
    int64_t int64_eq_const_125_0;
    int64_t int64_eq_const_126_0;
    int64_t int64_eq_const_127_0;
    int64_t int64_eq_const_128_0;
    int64_t int64_eq_const_129_0;
    int64_t int64_eq_const_130_0;
    int64_t int64_eq_const_131_0;
    int64_t int64_eq_const_132_0;
    int64_t int64_eq_const_133_0;
    int64_t int64_eq_const_134_0;
    int64_t int64_eq_const_135_0;
    int64_t int64_eq_const_136_0;
    int64_t int64_eq_const_137_0;
    int64_t int64_eq_const_138_0;
    int64_t int64_eq_const_139_0;
    int64_t int64_eq_const_140_0;
    int64_t int64_eq_const_141_0;
    int64_t int64_eq_const_142_0;
    int64_t int64_eq_const_143_0;
    int64_t int64_eq_const_144_0;
    int64_t int64_eq_const_145_0;
    int64_t int64_eq_const_146_0;
    int64_t int64_eq_const_147_0;
    int64_t int64_eq_const_148_0;
    int64_t int64_eq_const_149_0;
    int64_t int64_eq_const_150_0;
    int64_t int64_eq_const_151_0;
    int64_t int64_eq_const_152_0;
    int64_t int64_eq_const_153_0;
    int64_t int64_eq_const_154_0;
    int64_t int64_eq_const_155_0;
    int64_t int64_eq_const_156_0;
    int64_t int64_eq_const_157_0;
    int64_t int64_eq_const_158_0;
    int64_t int64_eq_const_159_0;
    int64_t int64_eq_const_160_0;
    int64_t int64_eq_const_161_0;
    int64_t int64_eq_const_162_0;
    int64_t int64_eq_const_163_0;
    int64_t int64_eq_const_164_0;
    int64_t int64_eq_const_165_0;
    int64_t int64_eq_const_166_0;
    int64_t int64_eq_const_167_0;
    int64_t int64_eq_const_168_0;
    int64_t int64_eq_const_169_0;
    int64_t int64_eq_const_170_0;
    int64_t int64_eq_const_171_0;
    int64_t int64_eq_const_172_0;
    int64_t int64_eq_const_173_0;
    int64_t int64_eq_const_174_0;
    int64_t int64_eq_const_175_0;
    int64_t int64_eq_const_176_0;
    int64_t int64_eq_const_177_0;
    int64_t int64_eq_const_178_0;
    int64_t int64_eq_const_179_0;
    int64_t int64_eq_const_180_0;
    int64_t int64_eq_const_181_0;
    int64_t int64_eq_const_182_0;
    int64_t int64_eq_const_183_0;
    int64_t int64_eq_const_184_0;
    int64_t int64_eq_const_185_0;
    int64_t int64_eq_const_186_0;
    int64_t int64_eq_const_187_0;
    int64_t int64_eq_const_188_0;
    int64_t int64_eq_const_189_0;
    int64_t int64_eq_const_190_0;
    int64_t int64_eq_const_191_0;
    int64_t int64_eq_const_192_0;
    int64_t int64_eq_const_193_0;
    int64_t int64_eq_const_194_0;
    int64_t int64_eq_const_195_0;
    int64_t int64_eq_const_196_0;
    int64_t int64_eq_const_197_0;
    int64_t int64_eq_const_198_0;
    int64_t int64_eq_const_199_0;
    int64_t int64_eq_const_200_0;
    int64_t int64_eq_const_201_0;
    int64_t int64_eq_const_202_0;
    int64_t int64_eq_const_203_0;
    int64_t int64_eq_const_204_0;
    int64_t int64_eq_const_205_0;
    int64_t int64_eq_const_206_0;
    int64_t int64_eq_const_207_0;
    int64_t int64_eq_const_208_0;
    int64_t int64_eq_const_209_0;
    int64_t int64_eq_const_210_0;
    int64_t int64_eq_const_211_0;
    int64_t int64_eq_const_212_0;
    int64_t int64_eq_const_213_0;
    int64_t int64_eq_const_214_0;
    int64_t int64_eq_const_215_0;
    int64_t int64_eq_const_216_0;
    int64_t int64_eq_const_217_0;
    int64_t int64_eq_const_218_0;
    int64_t int64_eq_const_219_0;
    int64_t int64_eq_const_220_0;
    int64_t int64_eq_const_221_0;
    int64_t int64_eq_const_222_0;
    int64_t int64_eq_const_223_0;
    int64_t int64_eq_const_224_0;
    int64_t int64_eq_const_225_0;
    int64_t int64_eq_const_226_0;
    int64_t int64_eq_const_227_0;
    int64_t int64_eq_const_228_0;
    int64_t int64_eq_const_229_0;
    int64_t int64_eq_const_230_0;
    int64_t int64_eq_const_231_0;
    int64_t int64_eq_const_232_0;
    int64_t int64_eq_const_233_0;
    int64_t int64_eq_const_234_0;
    int64_t int64_eq_const_235_0;
    int64_t int64_eq_const_236_0;
    int64_t int64_eq_const_237_0;
    int64_t int64_eq_const_238_0;
    int64_t int64_eq_const_239_0;
    int64_t int64_eq_const_240_0;
    int64_t int64_eq_const_241_0;
    int64_t int64_eq_const_242_0;
    int64_t int64_eq_const_243_0;
    int64_t int64_eq_const_244_0;
    int64_t int64_eq_const_245_0;
    int64_t int64_eq_const_246_0;
    int64_t int64_eq_const_247_0;
    int64_t int64_eq_const_248_0;
    int64_t int64_eq_const_249_0;
    int64_t int64_eq_const_250_0;
    int64_t int64_eq_const_251_0;
    int64_t int64_eq_const_252_0;
    int64_t int64_eq_const_253_0;
    int64_t int64_eq_const_254_0;
    int64_t int64_eq_const_255_0;

    if (size < 2048)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_31_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_34_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_38_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_45_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_49_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_52_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_55_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_60_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_63_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_64_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_65_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_66_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_67_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_68_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_69_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_70_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_71_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_73_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_74_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_75_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_76_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_77_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_78_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_79_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_80_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_81_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_82_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_83_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_84_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_86_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_87_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_88_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_89_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_91_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_92_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_93_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_94_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_95_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_96_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_97_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_98_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_99_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_100_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_101_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_102_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_103_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_104_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_105_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_106_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_107_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_108_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_109_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_110_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_111_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_112_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_113_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_114_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_115_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_116_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_117_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_118_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_119_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_120_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_121_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_122_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_123_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_124_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_125_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_126_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_127_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_128_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_129_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_130_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_131_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_132_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_133_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_134_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_135_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_136_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_137_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_138_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_139_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_140_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_141_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_142_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_143_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_144_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_145_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_146_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_147_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_148_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_149_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_150_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_151_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_152_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_153_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_154_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_155_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_156_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_157_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_158_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_159_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_160_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_161_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_162_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_163_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_164_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_165_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_166_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_167_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_168_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_169_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_170_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_171_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_172_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_173_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_174_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_175_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_176_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_177_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_178_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_179_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_180_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_181_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_182_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_183_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_184_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_185_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_186_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_187_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_188_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_189_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_190_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_191_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_192_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_193_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_194_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_195_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_196_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_197_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_198_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_199_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_200_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_201_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_202_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_203_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_204_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_205_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_206_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_207_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_208_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_209_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_210_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_211_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_212_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_213_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_214_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_215_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_216_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_217_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_218_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_219_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_220_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_221_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_222_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_223_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_224_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_225_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_226_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_227_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_228_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_229_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_230_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_231_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_232_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_233_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_234_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_235_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_236_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_237_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_238_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_239_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_240_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_241_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_242_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_243_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_244_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_245_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_246_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_247_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_248_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_249_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_250_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_251_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_252_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_253_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_254_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_255_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == 229108740804658691)
    if (int64_eq_const_1_0 == -8962459314939855396)
    if (int64_eq_const_2_0 == 5429535350377724520)
    if (int64_eq_const_3_0 == -1002712508123912319)
    if (int64_eq_const_4_0 == 1410336233247827030)
    if (int64_eq_const_5_0 == -7923930171552966369)
    if (int64_eq_const_6_0 == 5063244654720747907)
    if (int64_eq_const_7_0 == -6466401553205983777)
    if (int64_eq_const_8_0 == -410411785050374000)
    if (int64_eq_const_9_0 == -7751089344937262616)
    if (int64_eq_const_10_0 == -2154136208893621122)
    if (int64_eq_const_11_0 == -8746543879307309838)
    if (int64_eq_const_12_0 == 6021213678741470049)
    if (int64_eq_const_13_0 == 1838078094470672921)
    if (int64_eq_const_14_0 == 4059298655495109714)
    if (int64_eq_const_15_0 == -5583702880620293901)
    if (int64_eq_const_16_0 == -1435360255226715991)
    if (int64_eq_const_17_0 == -4503905638844079132)
    if (int64_eq_const_18_0 == 4317146854130203756)
    if (int64_eq_const_19_0 == -6773228643208718416)
    if (int64_eq_const_20_0 == -7479657088135521791)
    if (int64_eq_const_21_0 == -7400504499640104879)
    if (int64_eq_const_22_0 == -7793231502556580565)
    if (int64_eq_const_23_0 == 593674083644061450)
    if (int64_eq_const_24_0 == 200186894141993267)
    if (int64_eq_const_25_0 == -1473445230355968581)
    if (int64_eq_const_26_0 == 3504212306406129253)
    if (int64_eq_const_27_0 == 3543169728241091447)
    if (int64_eq_const_28_0 == -8569132360935857474)
    if (int64_eq_const_29_0 == -2304683735370860973)
    if (int64_eq_const_30_0 == -5709985895760389662)
    if (int64_eq_const_31_0 == 1667051595881090688)
    if (int64_eq_const_32_0 == 641943988258914387)
    if (int64_eq_const_33_0 == 3163339065842122396)
    if (int64_eq_const_34_0 == 4378745352313994720)
    if (int64_eq_const_35_0 == -4969361012698958524)
    if (int64_eq_const_36_0 == 2205123011584533338)
    if (int64_eq_const_37_0 == 579063433168049133)
    if (int64_eq_const_38_0 == 6881462224130322318)
    if (int64_eq_const_39_0 == 2317437615941353204)
    if (int64_eq_const_40_0 == -5716248240791621778)
    if (int64_eq_const_41_0 == -7204739116899214606)
    if (int64_eq_const_42_0 == -8969573840644510319)
    if (int64_eq_const_43_0 == -6135067426331718827)
    if (int64_eq_const_44_0 == -3517977609116228387)
    if (int64_eq_const_45_0 == 1129022313790326315)
    if (int64_eq_const_46_0 == 3092217934064429697)
    if (int64_eq_const_47_0 == -8674718423855050431)
    if (int64_eq_const_48_0 == -2510116233095560407)
    if (int64_eq_const_49_0 == 9118537003884035180)
    if (int64_eq_const_50_0 == -6135786784792406163)
    if (int64_eq_const_51_0 == 3333215660752825638)
    if (int64_eq_const_52_0 == -5570015211817501815)
    if (int64_eq_const_53_0 == 1962663212927864668)
    if (int64_eq_const_54_0 == 3508702183373766227)
    if (int64_eq_const_55_0 == 816470935371366277)
    if (int64_eq_const_56_0 == -1846799961350524055)
    if (int64_eq_const_57_0 == -1533614138862337546)
    if (int64_eq_const_58_0 == 1911757768644521129)
    if (int64_eq_const_59_0 == -2892606218940851340)
    if (int64_eq_const_60_0 == -5384086147143919899)
    if (int64_eq_const_61_0 == -6770026576669139190)
    if (int64_eq_const_62_0 == 4132119876125765079)
    if (int64_eq_const_63_0 == 3316816712935949597)
    if (int64_eq_const_64_0 == 1217127503547923282)
    if (int64_eq_const_65_0 == 6565240687785467837)
    if (int64_eq_const_66_0 == 7441686752425612730)
    if (int64_eq_const_67_0 == 8616376140962365501)
    if (int64_eq_const_68_0 == 3621027395731116470)
    if (int64_eq_const_69_0 == 521360271526814213)
    if (int64_eq_const_70_0 == -528893276035474653)
    if (int64_eq_const_71_0 == 7551516464095522469)
    if (int64_eq_const_72_0 == -5587004707514160821)
    if (int64_eq_const_73_0 == -4550912970081865938)
    if (int64_eq_const_74_0 == -950168083067321770)
    if (int64_eq_const_75_0 == -2769925431065346371)
    if (int64_eq_const_76_0 == -8039091568889265664)
    if (int64_eq_const_77_0 == 6883056090078220887)
    if (int64_eq_const_78_0 == -6938548077860071540)
    if (int64_eq_const_79_0 == -885249636016182788)
    if (int64_eq_const_80_0 == -4882667546195972360)
    if (int64_eq_const_81_0 == -278841926274089226)
    if (int64_eq_const_82_0 == 723329891045734769)
    if (int64_eq_const_83_0 == 6683108111420539761)
    if (int64_eq_const_84_0 == -5139539406302443256)
    if (int64_eq_const_85_0 == 7266499720964491088)
    if (int64_eq_const_86_0 == 2978943871125091238)
    if (int64_eq_const_87_0 == 3935550639647921725)
    if (int64_eq_const_88_0 == -6642715883626843843)
    if (int64_eq_const_89_0 == -2648410073530244350)
    if (int64_eq_const_90_0 == 729786762644351296)
    if (int64_eq_const_91_0 == -7920262972168580073)
    if (int64_eq_const_92_0 == 9197070280570086228)
    if (int64_eq_const_93_0 == -2818746619579398789)
    if (int64_eq_const_94_0 == 736096161468305223)
    if (int64_eq_const_95_0 == 3675448393776550854)
    if (int64_eq_const_96_0 == -2014386098955528127)
    if (int64_eq_const_97_0 == 62713387310269567)
    if (int64_eq_const_98_0 == 6176012673530967864)
    if (int64_eq_const_99_0 == 6152064888361263019)
    if (int64_eq_const_100_0 == 6619750700327024809)
    if (int64_eq_const_101_0 == -2919395137120661851)
    if (int64_eq_const_102_0 == 3266357937036749188)
    if (int64_eq_const_103_0 == 8654154030769230900)
    if (int64_eq_const_104_0 == -8169923529896927385)
    if (int64_eq_const_105_0 == 5968373432109953498)
    if (int64_eq_const_106_0 == 2523915679428104207)
    if (int64_eq_const_107_0 == 1209196031949393514)
    if (int64_eq_const_108_0 == 82103392920284170)
    if (int64_eq_const_109_0 == -2740237794759560739)
    if (int64_eq_const_110_0 == 7355520848481759409)
    if (int64_eq_const_111_0 == 8215403371339328100)
    if (int64_eq_const_112_0 == -6384744010420017835)
    if (int64_eq_const_113_0 == -3299068266727100736)
    if (int64_eq_const_114_0 == 7791200149064726456)
    if (int64_eq_const_115_0 == 2012991373993021905)
    if (int64_eq_const_116_0 == -5041845587519132737)
    if (int64_eq_const_117_0 == 7806139178788526957)
    if (int64_eq_const_118_0 == -4552701227439959452)
    if (int64_eq_const_119_0 == 2672133310289599091)
    if (int64_eq_const_120_0 == 4791538423072095217)
    if (int64_eq_const_121_0 == -149403146853514209)
    if (int64_eq_const_122_0 == -8498912982919358102)
    if (int64_eq_const_123_0 == 7475202211505566878)
    if (int64_eq_const_124_0 == -7436798331234811574)
    if (int64_eq_const_125_0 == -3075453699041712923)
    if (int64_eq_const_126_0 == 6554069637301373810)
    if (int64_eq_const_127_0 == -6459556396517152323)
    if (int64_eq_const_128_0 == -7047546926293813154)
    if (int64_eq_const_129_0 == 2345739862326218786)
    if (int64_eq_const_130_0 == 4906025660298876825)
    if (int64_eq_const_131_0 == -1746628484984952114)
    if (int64_eq_const_132_0 == -2847432946459057805)
    if (int64_eq_const_133_0 == 3633878146113774863)
    if (int64_eq_const_134_0 == -6085706371653928976)
    if (int64_eq_const_135_0 == -2149071839013343519)
    if (int64_eq_const_136_0 == -5653671415734418686)
    if (int64_eq_const_137_0 == 3076629186813548088)
    if (int64_eq_const_138_0 == 6625081670528588795)
    if (int64_eq_const_139_0 == 7659464731131666844)
    if (int64_eq_const_140_0 == 529577165931592764)
    if (int64_eq_const_141_0 == -3979445223741865989)
    if (int64_eq_const_142_0 == 7306547181352837938)
    if (int64_eq_const_143_0 == -9083051386153934406)
    if (int64_eq_const_144_0 == -1675219126155057277)
    if (int64_eq_const_145_0 == -385385663068893428)
    if (int64_eq_const_146_0 == -2302240631320582269)
    if (int64_eq_const_147_0 == -3454050972933058681)
    if (int64_eq_const_148_0 == -3207241372361061140)
    if (int64_eq_const_149_0 == -8370391014232443148)
    if (int64_eq_const_150_0 == 6609945435317442510)
    if (int64_eq_const_151_0 == 145758014112951142)
    if (int64_eq_const_152_0 == 605255413637063876)
    if (int64_eq_const_153_0 == 3638379623156840589)
    if (int64_eq_const_154_0 == -3689196596192927128)
    if (int64_eq_const_155_0 == -3131254892496927669)
    if (int64_eq_const_156_0 == -7869800318543812088)
    if (int64_eq_const_157_0 == 1955305245142726792)
    if (int64_eq_const_158_0 == 1318217176086556569)
    if (int64_eq_const_159_0 == 5241002489899152962)
    if (int64_eq_const_160_0 == 8093977822951521515)
    if (int64_eq_const_161_0 == -176865976894183961)
    if (int64_eq_const_162_0 == -4191235479610905570)
    if (int64_eq_const_163_0 == -2886018587380680474)
    if (int64_eq_const_164_0 == -2372540075880835756)
    if (int64_eq_const_165_0 == -5205839395926986621)
    if (int64_eq_const_166_0 == -2158726378474413145)
    if (int64_eq_const_167_0 == 5733089360245538282)
    if (int64_eq_const_168_0 == 3988281588976436573)
    if (int64_eq_const_169_0 == 7367962444693000071)
    if (int64_eq_const_170_0 == -1129431933735441574)
    if (int64_eq_const_171_0 == 6617858637652844436)
    if (int64_eq_const_172_0 == -2332904037559972907)
    if (int64_eq_const_173_0 == -952052255069956109)
    if (int64_eq_const_174_0 == -2643694717521732530)
    if (int64_eq_const_175_0 == -5803702267729469635)
    if (int64_eq_const_176_0 == -2830567588223781185)
    if (int64_eq_const_177_0 == 2119880041286214426)
    if (int64_eq_const_178_0 == 3985081171996302865)
    if (int64_eq_const_179_0 == 2550855460936496082)
    if (int64_eq_const_180_0 == 1790021230541411793)
    if (int64_eq_const_181_0 == 1560600347716076836)
    if (int64_eq_const_182_0 == -3565777875872055005)
    if (int64_eq_const_183_0 == 2398307373717022806)
    if (int64_eq_const_184_0 == 7807593267753483510)
    if (int64_eq_const_185_0 == -3179604651213089907)
    if (int64_eq_const_186_0 == -9008942909252703879)
    if (int64_eq_const_187_0 == 2904770550203943518)
    if (int64_eq_const_188_0 == -2647300850763573556)
    if (int64_eq_const_189_0 == -8839098269223175260)
    if (int64_eq_const_190_0 == 2619170389921057019)
    if (int64_eq_const_191_0 == 4857882108437276819)
    if (int64_eq_const_192_0 == -6713786917040568537)
    if (int64_eq_const_193_0 == -8683736337513010931)
    if (int64_eq_const_194_0 == -6047990546532750843)
    if (int64_eq_const_195_0 == -3076052131708722892)
    if (int64_eq_const_196_0 == -6139263805082083956)
    if (int64_eq_const_197_0 == -6814310140979250113)
    if (int64_eq_const_198_0 == 7963569187761129962)
    if (int64_eq_const_199_0 == 3853708032059342993)
    if (int64_eq_const_200_0 == -134030911384037449)
    if (int64_eq_const_201_0 == 7249888137043497223)
    if (int64_eq_const_202_0 == 3760117637111563116)
    if (int64_eq_const_203_0 == 3989296430672523153)
    if (int64_eq_const_204_0 == 3982990090109858838)
    if (int64_eq_const_205_0 == -2289770235746167548)
    if (int64_eq_const_206_0 == -2739995487695681210)
    if (int64_eq_const_207_0 == -2650225401026907603)
    if (int64_eq_const_208_0 == 16595474870309963)
    if (int64_eq_const_209_0 == 2081398369849814568)
    if (int64_eq_const_210_0 == 877272962165190818)
    if (int64_eq_const_211_0 == 1619823613615158770)
    if (int64_eq_const_212_0 == -4670564885504823379)
    if (int64_eq_const_213_0 == 2918739978270159165)
    if (int64_eq_const_214_0 == -1463971928214336605)
    if (int64_eq_const_215_0 == -2917025810928815997)
    if (int64_eq_const_216_0 == 5208005500356564424)
    if (int64_eq_const_217_0 == -3138299601955002274)
    if (int64_eq_const_218_0 == -1042052613736721443)
    if (int64_eq_const_219_0 == 2823665191510429205)
    if (int64_eq_const_220_0 == -738334855588216616)
    if (int64_eq_const_221_0 == -6168624181684115079)
    if (int64_eq_const_222_0 == 3522153583095751896)
    if (int64_eq_const_223_0 == -8030879039994007566)
    if (int64_eq_const_224_0 == -2900611799301130158)
    if (int64_eq_const_225_0 == 470971019632573652)
    if (int64_eq_const_226_0 == 3156996844753159824)
    if (int64_eq_const_227_0 == -4206784936317060361)
    if (int64_eq_const_228_0 == -4232465283930913956)
    if (int64_eq_const_229_0 == -5189692341417536635)
    if (int64_eq_const_230_0 == -3756601203010926600)
    if (int64_eq_const_231_0 == -3597051502134118891)
    if (int64_eq_const_232_0 == -560102299009701040)
    if (int64_eq_const_233_0 == 178286164654099961)
    if (int64_eq_const_234_0 == -5548618115658978958)
    if (int64_eq_const_235_0 == -1493778199052977965)
    if (int64_eq_const_236_0 == -8746880403250999747)
    if (int64_eq_const_237_0 == 6837825044179014254)
    if (int64_eq_const_238_0 == 455014285343954776)
    if (int64_eq_const_239_0 == -4402061223153915446)
    if (int64_eq_const_240_0 == 8863684921935839590)
    if (int64_eq_const_241_0 == -2158146259222809736)
    if (int64_eq_const_242_0 == 576242270562235511)
    if (int64_eq_const_243_0 == 5791059129266048296)
    if (int64_eq_const_244_0 == -8706154416721525823)
    if (int64_eq_const_245_0 == -4340779144703170944)
    if (int64_eq_const_246_0 == 5914493747752006799)
    if (int64_eq_const_247_0 == -7894853820526337234)
    if (int64_eq_const_248_0 == 5435797397402566776)
    if (int64_eq_const_249_0 == 1894031287004219968)
    if (int64_eq_const_250_0 == 5192798831569520340)
    if (int64_eq_const_251_0 == -1592310724209256782)
    if (int64_eq_const_252_0 == -726566158377754260)
    if (int64_eq_const_253_0 == -9185568508793569976)
    if (int64_eq_const_254_0 == 7028528109882003568)
    if (int64_eq_const_255_0 == -6673014889520710754)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
