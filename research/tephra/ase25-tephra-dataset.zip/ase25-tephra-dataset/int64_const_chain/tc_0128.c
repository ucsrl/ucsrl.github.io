#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int64_t int64_eq_const_14_0;
    int64_t int64_eq_const_15_0;
    int64_t int64_eq_const_16_0;
    int64_t int64_eq_const_17_0;
    int64_t int64_eq_const_18_0;
    int64_t int64_eq_const_19_0;
    int64_t int64_eq_const_20_0;
    int64_t int64_eq_const_21_0;
    int64_t int64_eq_const_22_0;
    int64_t int64_eq_const_23_0;
    int64_t int64_eq_const_24_0;
    int64_t int64_eq_const_25_0;
    int64_t int64_eq_const_26_0;
    int64_t int64_eq_const_27_0;
    int64_t int64_eq_const_28_0;
    int64_t int64_eq_const_29_0;
    int64_t int64_eq_const_30_0;
    int64_t int64_eq_const_31_0;
    int64_t int64_eq_const_32_0;
    int64_t int64_eq_const_33_0;
    int64_t int64_eq_const_34_0;
    int64_t int64_eq_const_35_0;
    int64_t int64_eq_const_36_0;
    int64_t int64_eq_const_37_0;
    int64_t int64_eq_const_38_0;
    int64_t int64_eq_const_39_0;
    int64_t int64_eq_const_40_0;
    int64_t int64_eq_const_41_0;
    int64_t int64_eq_const_42_0;
    int64_t int64_eq_const_43_0;
    int64_t int64_eq_const_44_0;
    int64_t int64_eq_const_45_0;
    int64_t int64_eq_const_46_0;
    int64_t int64_eq_const_47_0;
    int64_t int64_eq_const_48_0;
    int64_t int64_eq_const_49_0;
    int64_t int64_eq_const_50_0;
    int64_t int64_eq_const_51_0;
    int64_t int64_eq_const_52_0;
    int64_t int64_eq_const_53_0;
    int64_t int64_eq_const_54_0;
    int64_t int64_eq_const_55_0;
    int64_t int64_eq_const_56_0;
    int64_t int64_eq_const_57_0;
    int64_t int64_eq_const_58_0;
    int64_t int64_eq_const_59_0;
    int64_t int64_eq_const_60_0;
    int64_t int64_eq_const_61_0;
    int64_t int64_eq_const_62_0;
    int64_t int64_eq_const_63_0;
    int64_t int64_eq_const_64_0;
    int64_t int64_eq_const_65_0;
    int64_t int64_eq_const_66_0;
    int64_t int64_eq_const_67_0;
    int64_t int64_eq_const_68_0;
    int64_t int64_eq_const_69_0;
    int64_t int64_eq_const_70_0;
    int64_t int64_eq_const_71_0;
    int64_t int64_eq_const_72_0;
    int64_t int64_eq_const_73_0;
    int64_t int64_eq_const_74_0;
    int64_t int64_eq_const_75_0;
    int64_t int64_eq_const_76_0;
    int64_t int64_eq_const_77_0;
    int64_t int64_eq_const_78_0;
    int64_t int64_eq_const_79_0;
    int64_t int64_eq_const_80_0;
    int64_t int64_eq_const_81_0;
    int64_t int64_eq_const_82_0;
    int64_t int64_eq_const_83_0;
    int64_t int64_eq_const_84_0;
    int64_t int64_eq_const_85_0;
    int64_t int64_eq_const_86_0;
    int64_t int64_eq_const_87_0;
    int64_t int64_eq_const_88_0;
    int64_t int64_eq_const_89_0;
    int64_t int64_eq_const_90_0;
    int64_t int64_eq_const_91_0;
    int64_t int64_eq_const_92_0;
    int64_t int64_eq_const_93_0;
    int64_t int64_eq_const_94_0;
    int64_t int64_eq_const_95_0;
    int64_t int64_eq_const_96_0;
    int64_t int64_eq_const_97_0;
    int64_t int64_eq_const_98_0;
    int64_t int64_eq_const_99_0;
    int64_t int64_eq_const_100_0;
    int64_t int64_eq_const_101_0;
    int64_t int64_eq_const_102_0;
    int64_t int64_eq_const_103_0;
    int64_t int64_eq_const_104_0;
    int64_t int64_eq_const_105_0;
    int64_t int64_eq_const_106_0;
    int64_t int64_eq_const_107_0;
    int64_t int64_eq_const_108_0;
    int64_t int64_eq_const_109_0;
    int64_t int64_eq_const_110_0;
    int64_t int64_eq_const_111_0;
    int64_t int64_eq_const_112_0;
    int64_t int64_eq_const_113_0;
    int64_t int64_eq_const_114_0;
    int64_t int64_eq_const_115_0;
    int64_t int64_eq_const_116_0;
    int64_t int64_eq_const_117_0;
    int64_t int64_eq_const_118_0;
    int64_t int64_eq_const_119_0;
    int64_t int64_eq_const_120_0;
    int64_t int64_eq_const_121_0;
    int64_t int64_eq_const_122_0;
    int64_t int64_eq_const_123_0;
    int64_t int64_eq_const_124_0;
    int64_t int64_eq_const_125_0;
    int64_t int64_eq_const_126_0;
    int64_t int64_eq_const_127_0;

    if (size < 1024)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_31_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_34_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_38_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_45_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_49_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_52_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_55_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_60_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_63_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_64_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_65_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_66_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_67_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_68_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_69_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_70_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_71_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_73_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_74_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_75_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_76_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_77_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_78_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_79_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_80_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_81_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_82_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_83_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_84_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_86_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_87_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_88_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_89_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_91_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_92_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_93_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_94_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_95_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_96_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_97_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_98_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_99_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_100_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_101_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_102_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_103_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_104_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_105_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_106_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_107_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_108_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_109_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_110_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_111_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_112_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_113_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_114_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_115_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_116_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_117_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_118_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_119_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_120_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_121_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_122_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_123_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_124_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_125_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_126_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_127_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == -4797894819624942127)
    if (int64_eq_const_1_0 == -4453337707423673050)
    if (int64_eq_const_2_0 == -3525416427694683333)
    if (int64_eq_const_3_0 == -3277360909857724265)
    if (int64_eq_const_4_0 == 3936747731642799049)
    if (int64_eq_const_5_0 == 6745724767472395924)
    if (int64_eq_const_6_0 == 3644583864302109664)
    if (int64_eq_const_7_0 == -2765052342408873865)
    if (int64_eq_const_8_0 == 7858529409537264595)
    if (int64_eq_const_9_0 == -9138018350362535019)
    if (int64_eq_const_10_0 == 6316249970412352338)
    if (int64_eq_const_11_0 == -3569622955720795177)
    if (int64_eq_const_12_0 == -8691061803690285024)
    if (int64_eq_const_13_0 == 8225277073744929673)
    if (int64_eq_const_14_0 == 1147793831973913608)
    if (int64_eq_const_15_0 == -5297301226685041551)
    if (int64_eq_const_16_0 == 1875718906817216017)
    if (int64_eq_const_17_0 == 5049462344507039267)
    if (int64_eq_const_18_0 == 1577641434629880560)
    if (int64_eq_const_19_0 == 951782719774049683)
    if (int64_eq_const_20_0 == 3389167489355575485)
    if (int64_eq_const_21_0 == -789896727967657493)
    if (int64_eq_const_22_0 == -8631265530580610582)
    if (int64_eq_const_23_0 == 35669745969730207)
    if (int64_eq_const_24_0 == 4872287935551976304)
    if (int64_eq_const_25_0 == 8465705197482701501)
    if (int64_eq_const_26_0 == 4155122922984366666)
    if (int64_eq_const_27_0 == 4032539923540675977)
    if (int64_eq_const_28_0 == 5218025223227694118)
    if (int64_eq_const_29_0 == -995876995467331511)
    if (int64_eq_const_30_0 == 7051592165429731162)
    if (int64_eq_const_31_0 == -7206335802752871076)
    if (int64_eq_const_32_0 == -9097687498696948204)
    if (int64_eq_const_33_0 == 1501362012121466001)
    if (int64_eq_const_34_0 == -3507374680683454251)
    if (int64_eq_const_35_0 == -2371208182985816907)
    if (int64_eq_const_36_0 == -4795233749189573600)
    if (int64_eq_const_37_0 == 5933605664176183917)
    if (int64_eq_const_38_0 == -7532076158475518610)
    if (int64_eq_const_39_0 == 7107955109098852422)
    if (int64_eq_const_40_0 == -5463266197831031964)
    if (int64_eq_const_41_0 == 2285481792875602954)
    if (int64_eq_const_42_0 == 7315422521084867911)
    if (int64_eq_const_43_0 == 7944399753838490965)
    if (int64_eq_const_44_0 == -7774218019198304849)
    if (int64_eq_const_45_0 == -495869269755836057)
    if (int64_eq_const_46_0 == -754006534235165574)
    if (int64_eq_const_47_0 == -7547480068565354438)
    if (int64_eq_const_48_0 == -6665234089475613693)
    if (int64_eq_const_49_0 == 3361181346293716694)
    if (int64_eq_const_50_0 == -216888484587375212)
    if (int64_eq_const_51_0 == -6620043738101894428)
    if (int64_eq_const_52_0 == -6801401591375484648)
    if (int64_eq_const_53_0 == 8986768547842372481)
    if (int64_eq_const_54_0 == -4712016761549476844)
    if (int64_eq_const_55_0 == 3296267993844331349)
    if (int64_eq_const_56_0 == 922762361457898456)
    if (int64_eq_const_57_0 == -8055738590396815389)
    if (int64_eq_const_58_0 == -3791200339240411407)
    if (int64_eq_const_59_0 == -4694000162249184735)
    if (int64_eq_const_60_0 == -4833438880502545951)
    if (int64_eq_const_61_0 == -5137192007070583733)
    if (int64_eq_const_62_0 == -70912232557425903)
    if (int64_eq_const_63_0 == 4049906418595997939)
    if (int64_eq_const_64_0 == 5852943004972216838)
    if (int64_eq_const_65_0 == 3860866649081722717)
    if (int64_eq_const_66_0 == -7340526436195998253)
    if (int64_eq_const_67_0 == -3599382612657213175)
    if (int64_eq_const_68_0 == -3926387257435967794)
    if (int64_eq_const_69_0 == -4855681354158562160)
    if (int64_eq_const_70_0 == 8725588223098386310)
    if (int64_eq_const_71_0 == 732070530378322355)
    if (int64_eq_const_72_0 == 4768622909451972852)
    if (int64_eq_const_73_0 == 1404533320535182000)
    if (int64_eq_const_74_0 == -3872538630044334609)
    if (int64_eq_const_75_0 == -2632281468958140712)
    if (int64_eq_const_76_0 == 3700718869753958885)
    if (int64_eq_const_77_0 == -2924659311236634019)
    if (int64_eq_const_78_0 == 5974173275977912008)
    if (int64_eq_const_79_0 == -2094078181563545744)
    if (int64_eq_const_80_0 == -4367354269876294075)
    if (int64_eq_const_81_0 == -2846047098765370229)
    if (int64_eq_const_82_0 == 5065752056870965819)
    if (int64_eq_const_83_0 == -2639531448137780213)
    if (int64_eq_const_84_0 == -5386536050616362902)
    if (int64_eq_const_85_0 == -4545637896808888063)
    if (int64_eq_const_86_0 == -1258422362491163285)
    if (int64_eq_const_87_0 == 3472121405219493192)
    if (int64_eq_const_88_0 == 4301594584675359455)
    if (int64_eq_const_89_0 == 1854238567103016154)
    if (int64_eq_const_90_0 == -1500705749178661653)
    if (int64_eq_const_91_0 == -7678833412051355041)
    if (int64_eq_const_92_0 == -9057046212437538077)
    if (int64_eq_const_93_0 == 2454153777283674374)
    if (int64_eq_const_94_0 == -7651448575143231676)
    if (int64_eq_const_95_0 == -5078876129054636136)
    if (int64_eq_const_96_0 == 979110733448194792)
    if (int64_eq_const_97_0 == 6265465961812250826)
    if (int64_eq_const_98_0 == 3536083311426228084)
    if (int64_eq_const_99_0 == -619922846856969006)
    if (int64_eq_const_100_0 == 3158733404199476500)
    if (int64_eq_const_101_0 == -212351915735494596)
    if (int64_eq_const_102_0 == -2115444085168877718)
    if (int64_eq_const_103_0 == 5067095012106091517)
    if (int64_eq_const_104_0 == -8031549919270181437)
    if (int64_eq_const_105_0 == 8579760895967707848)
    if (int64_eq_const_106_0 == 2118882012016765579)
    if (int64_eq_const_107_0 == -9059799353995352160)
    if (int64_eq_const_108_0 == -2567515243929731581)
    if (int64_eq_const_109_0 == -5299070845556252242)
    if (int64_eq_const_110_0 == 920570874060527664)
    if (int64_eq_const_111_0 == -8164646566662508204)
    if (int64_eq_const_112_0 == 4907027175167604246)
    if (int64_eq_const_113_0 == -7060571799609068927)
    if (int64_eq_const_114_0 == -4127571579071306202)
    if (int64_eq_const_115_0 == -4378464097436532666)
    if (int64_eq_const_116_0 == -4537277379403405324)
    if (int64_eq_const_117_0 == -4602048266007790167)
    if (int64_eq_const_118_0 == -8780218939319233748)
    if (int64_eq_const_119_0 == -8609595032009926727)
    if (int64_eq_const_120_0 == 3872031694245034438)
    if (int64_eq_const_121_0 == 9007974879402038498)
    if (int64_eq_const_122_0 == -889651576992532104)
    if (int64_eq_const_123_0 == 660775550440850818)
    if (int64_eq_const_124_0 == -5032720814841778068)
    if (int64_eq_const_125_0 == 2814452592907774395)
    if (int64_eq_const_126_0 == -8163100833278998221)
    if (int64_eq_const_127_0 == 7038912843873853578)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
