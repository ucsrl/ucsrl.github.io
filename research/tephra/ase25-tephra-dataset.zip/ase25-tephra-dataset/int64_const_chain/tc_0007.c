#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;

    if (size < 56)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == -7311705425871396768)
    if (int64_eq_const_1_0 == 4003523455848753229)
    if (int64_eq_const_2_0 == -4648613072695889342)
    if (int64_eq_const_3_0 == -6336226546723047105)
    if (int64_eq_const_4_0 == 3631450190571857778)
    if (int64_eq_const_5_0 == 116207599314501477)
    if (int64_eq_const_6_0 == 3491134168477641832)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
