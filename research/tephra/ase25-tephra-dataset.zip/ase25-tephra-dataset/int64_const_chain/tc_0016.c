#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int64_t int64_eq_const_14_0;
    int64_t int64_eq_const_15_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_15_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == 8864398633056828611)
    if (int64_eq_const_1_0 == 6160410525076973580)
    if (int64_eq_const_2_0 == -3535710941434084165)
    if (int64_eq_const_3_0 == -3938184040696817154)
    if (int64_eq_const_4_0 == 5354235840052943847)
    if (int64_eq_const_5_0 == -8720443012467292891)
    if (int64_eq_const_6_0 == 7785270106433664006)
    if (int64_eq_const_7_0 == -676310601651400508)
    if (int64_eq_const_8_0 == -1028197829495716251)
    if (int64_eq_const_9_0 == -3157894548591416132)
    if (int64_eq_const_10_0 == -3304023712296486580)
    if (int64_eq_const_11_0 == -2296815073102973411)
    if (int64_eq_const_12_0 == 6359538542484596923)
    if (int64_eq_const_13_0 == -2550498105516502785)
    if (int64_eq_const_14_0 == 7759710651367425622)
    if (int64_eq_const_15_0 == -7362712524364313709)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
