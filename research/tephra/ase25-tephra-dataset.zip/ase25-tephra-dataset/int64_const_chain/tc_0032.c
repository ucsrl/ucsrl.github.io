#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int64_t int64_eq_const_14_0;
    int64_t int64_eq_const_15_0;
    int64_t int64_eq_const_16_0;
    int64_t int64_eq_const_17_0;
    int64_t int64_eq_const_18_0;
    int64_t int64_eq_const_19_0;
    int64_t int64_eq_const_20_0;
    int64_t int64_eq_const_21_0;
    int64_t int64_eq_const_22_0;
    int64_t int64_eq_const_23_0;
    int64_t int64_eq_const_24_0;
    int64_t int64_eq_const_25_0;
    int64_t int64_eq_const_26_0;
    int64_t int64_eq_const_27_0;
    int64_t int64_eq_const_28_0;
    int64_t int64_eq_const_29_0;
    int64_t int64_eq_const_30_0;
    int64_t int64_eq_const_31_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_31_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == -3262796829975487552)
    if (int64_eq_const_1_0 == -5291286539011391969)
    if (int64_eq_const_2_0 == -938296532141283569)
    if (int64_eq_const_3_0 == 479460637779489754)
    if (int64_eq_const_4_0 == 9218863350641848279)
    if (int64_eq_const_5_0 == -4775230764096107727)
    if (int64_eq_const_6_0 == 7036818109472965504)
    if (int64_eq_const_7_0 == -7155467419301533665)
    if (int64_eq_const_8_0 == -6473195227283798111)
    if (int64_eq_const_9_0 == -5632320586033215264)
    if (int64_eq_const_10_0 == -3410156167797438098)
    if (int64_eq_const_11_0 == 7202613045196186750)
    if (int64_eq_const_12_0 == -1501843754440404881)
    if (int64_eq_const_13_0 == 7101267524959919786)
    if (int64_eq_const_14_0 == 5111700023705331827)
    if (int64_eq_const_15_0 == -6575263183689685809)
    if (int64_eq_const_16_0 == -2662935524815235389)
    if (int64_eq_const_17_0 == 1138294766267123812)
    if (int64_eq_const_18_0 == 3255131464396336793)
    if (int64_eq_const_19_0 == -5193438576624227711)
    if (int64_eq_const_20_0 == 2605222688830552274)
    if (int64_eq_const_21_0 == -4144306846627640139)
    if (int64_eq_const_22_0 == -4249200844752084253)
    if (int64_eq_const_23_0 == -7215457215763735786)
    if (int64_eq_const_24_0 == -1241633457641903863)
    if (int64_eq_const_25_0 == -7080835312109730920)
    if (int64_eq_const_26_0 == -5754838854464213052)
    if (int64_eq_const_27_0 == -8618870807900262750)
    if (int64_eq_const_28_0 == -2890515620763991931)
    if (int64_eq_const_29_0 == -1227354469685531426)
    if (int64_eq_const_30_0 == 3262986122606386597)
    if (int64_eq_const_31_0 == -6910844278444626352)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
