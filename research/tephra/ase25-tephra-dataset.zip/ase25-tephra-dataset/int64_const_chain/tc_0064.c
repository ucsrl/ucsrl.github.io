#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int64_t int64_eq_const_14_0;
    int64_t int64_eq_const_15_0;
    int64_t int64_eq_const_16_0;
    int64_t int64_eq_const_17_0;
    int64_t int64_eq_const_18_0;
    int64_t int64_eq_const_19_0;
    int64_t int64_eq_const_20_0;
    int64_t int64_eq_const_21_0;
    int64_t int64_eq_const_22_0;
    int64_t int64_eq_const_23_0;
    int64_t int64_eq_const_24_0;
    int64_t int64_eq_const_25_0;
    int64_t int64_eq_const_26_0;
    int64_t int64_eq_const_27_0;
    int64_t int64_eq_const_28_0;
    int64_t int64_eq_const_29_0;
    int64_t int64_eq_const_30_0;
    int64_t int64_eq_const_31_0;
    int64_t int64_eq_const_32_0;
    int64_t int64_eq_const_33_0;
    int64_t int64_eq_const_34_0;
    int64_t int64_eq_const_35_0;
    int64_t int64_eq_const_36_0;
    int64_t int64_eq_const_37_0;
    int64_t int64_eq_const_38_0;
    int64_t int64_eq_const_39_0;
    int64_t int64_eq_const_40_0;
    int64_t int64_eq_const_41_0;
    int64_t int64_eq_const_42_0;
    int64_t int64_eq_const_43_0;
    int64_t int64_eq_const_44_0;
    int64_t int64_eq_const_45_0;
    int64_t int64_eq_const_46_0;
    int64_t int64_eq_const_47_0;
    int64_t int64_eq_const_48_0;
    int64_t int64_eq_const_49_0;
    int64_t int64_eq_const_50_0;
    int64_t int64_eq_const_51_0;
    int64_t int64_eq_const_52_0;
    int64_t int64_eq_const_53_0;
    int64_t int64_eq_const_54_0;
    int64_t int64_eq_const_55_0;
    int64_t int64_eq_const_56_0;
    int64_t int64_eq_const_57_0;
    int64_t int64_eq_const_58_0;
    int64_t int64_eq_const_59_0;
    int64_t int64_eq_const_60_0;
    int64_t int64_eq_const_61_0;
    int64_t int64_eq_const_62_0;
    int64_t int64_eq_const_63_0;

    if (size < 512)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_31_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_34_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_38_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_45_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_49_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_52_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_55_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_60_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_63_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == -808238831768852412)
    if (int64_eq_const_1_0 == 7336586390652092162)
    if (int64_eq_const_2_0 == 7478119949172040552)
    if (int64_eq_const_3_0 == 6324354074606068561)
    if (int64_eq_const_4_0 == -5395552748538625027)
    if (int64_eq_const_5_0 == -6085931830980637962)
    if (int64_eq_const_6_0 == -1483695510584289854)
    if (int64_eq_const_7_0 == -2873771856618540446)
    if (int64_eq_const_8_0 == 1921773567773003232)
    if (int64_eq_const_9_0 == 9210245196337955715)
    if (int64_eq_const_10_0 == 8038863280145559135)
    if (int64_eq_const_11_0 == -4400514335468738471)
    if (int64_eq_const_12_0 == -287287395596735269)
    if (int64_eq_const_13_0 == 1975903414373102280)
    if (int64_eq_const_14_0 == 2017223402162638966)
    if (int64_eq_const_15_0 == 3766699016654400944)
    if (int64_eq_const_16_0 == -1900119731784484080)
    if (int64_eq_const_17_0 == -1860400963802436806)
    if (int64_eq_const_18_0 == 3755891124981486005)
    if (int64_eq_const_19_0 == 7621904525734634613)
    if (int64_eq_const_20_0 == 6142475624057632855)
    if (int64_eq_const_21_0 == -598204894699012576)
    if (int64_eq_const_22_0 == 3292188551925404860)
    if (int64_eq_const_23_0 == 7990824590106445513)
    if (int64_eq_const_24_0 == 5308386386544676025)
    if (int64_eq_const_25_0 == 5448181129131278870)
    if (int64_eq_const_26_0 == 643551760708727712)
    if (int64_eq_const_27_0 == -4887984644759906974)
    if (int64_eq_const_28_0 == 3476021381941336822)
    if (int64_eq_const_29_0 == 1571283763905636747)
    if (int64_eq_const_30_0 == 3637170138917730921)
    if (int64_eq_const_31_0 == 6479033795684701705)
    if (int64_eq_const_32_0 == -8565363979416706304)
    if (int64_eq_const_33_0 == 953268919882541379)
    if (int64_eq_const_34_0 == 5430097876197978516)
    if (int64_eq_const_35_0 == -1929516926550138339)
    if (int64_eq_const_36_0 == -5465804964964043650)
    if (int64_eq_const_37_0 == -712257156710191403)
    if (int64_eq_const_38_0 == -8077974422546925423)
    if (int64_eq_const_39_0 == 3179525481515025679)
    if (int64_eq_const_40_0 == 4019618429485625674)
    if (int64_eq_const_41_0 == 3375305719538624301)
    if (int64_eq_const_42_0 == 4204871645126766662)
    if (int64_eq_const_43_0 == -841903748575450396)
    if (int64_eq_const_44_0 == 8983060521600229363)
    if (int64_eq_const_45_0 == -8881536240204507892)
    if (int64_eq_const_46_0 == 3069054551267603850)
    if (int64_eq_const_47_0 == -1883159040712794442)
    if (int64_eq_const_48_0 == 7468199481045274172)
    if (int64_eq_const_49_0 == 2344861419884099459)
    if (int64_eq_const_50_0 == 5774335209128831915)
    if (int64_eq_const_51_0 == -9100938735483889357)
    if (int64_eq_const_52_0 == 8440962938489635739)
    if (int64_eq_const_53_0 == -1422847757445693316)
    if (int64_eq_const_54_0 == -3431161131475691799)
    if (int64_eq_const_55_0 == -9089681211576033508)
    if (int64_eq_const_56_0 == -534358498779216965)
    if (int64_eq_const_57_0 == 7979682155318975281)
    if (int64_eq_const_58_0 == -6421859793535285512)
    if (int64_eq_const_59_0 == -15867640639606840)
    if (int64_eq_const_60_0 == -1517916284648120070)
    if (int64_eq_const_61_0 == -4954396657646386509)
    if (int64_eq_const_62_0 == -8513785800251764350)
    if (int64_eq_const_63_0 == 4839097002102457246)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
