#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;

    if (size < 48)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == 8864398633056828611)
    if (int64_eq_const_1_0 == 6160410525076973580)
    if (int64_eq_const_2_0 == -3535710941434084165)
    if (int64_eq_const_3_0 == -3938184040696817154)
    if (int64_eq_const_4_0 == 5354235840052943847)
    if (int64_eq_const_5_0 == -8720443012467292891)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
