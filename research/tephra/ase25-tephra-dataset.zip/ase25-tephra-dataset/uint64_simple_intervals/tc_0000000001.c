#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    uint64_t value;
    uint64_t eps = 10;
    uint64_t bound = 5428997594112070375;

    if (size < sizeof(uint64_t))
        return TEPHRA_EXIT_FAILURE;

    memcpy(&value, data, sizeof(uint64_t));

    if (value <= (bound + eps))
        if ((bound - eps) <= value)
            BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
