#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int16_t int16_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;
    int16_t int16_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    int16_t int16_eq_const_14_0;

    if (size < 30)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_14_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == 2450)
    if (int16_eq_const_1_0 == -28419)
    if (int16_eq_const_2_0 == 14765)
    if (int16_eq_const_3_0 == 11503)
    if (int16_eq_const_4_0 == 22273)
    if (int16_eq_const_5_0 == -1276)
    if (int16_eq_const_6_0 == -10882)
    if (int16_eq_const_7_0 == 20206)
    if (int16_eq_const_8_0 == 18776)
    if (int16_eq_const_9_0 == -13746)
    if (int16_eq_const_10_0 == 1786)
    if (int16_eq_const_11_0 == -5110)
    if (int16_eq_const_12_0 == 30365)
    if (int16_eq_const_13_0 == 29115)
    if (int16_eq_const_14_0 == 21548)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
