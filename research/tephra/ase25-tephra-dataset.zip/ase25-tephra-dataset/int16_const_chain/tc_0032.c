#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int16_t int16_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;
    int16_t int16_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    int16_t int16_eq_const_14_0;
    int16_t int16_eq_const_15_0;
    int16_t int16_eq_const_16_0;
    int16_t int16_eq_const_17_0;
    int16_t int16_eq_const_18_0;
    int16_t int16_eq_const_19_0;
    int16_t int16_eq_const_20_0;
    int16_t int16_eq_const_21_0;
    int16_t int16_eq_const_22_0;
    int16_t int16_eq_const_23_0;
    int16_t int16_eq_const_24_0;
    int16_t int16_eq_const_25_0;
    int16_t int16_eq_const_26_0;
    int16_t int16_eq_const_27_0;
    int16_t int16_eq_const_28_0;
    int16_t int16_eq_const_29_0;
    int16_t int16_eq_const_30_0;
    int16_t int16_eq_const_31_0;

    if (size < 64)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_31_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == -26025)
    if (int16_eq_const_1_0 == -25962)
    if (int16_eq_const_2_0 == -21416)
    if (int16_eq_const_3_0 == 26059)
    if (int16_eq_const_4_0 == -5318)
    if (int16_eq_const_5_0 == 22771)
    if (int16_eq_const_6_0 == -10715)
    if (int16_eq_const_7_0 == -5034)
    if (int16_eq_const_8_0 == -29334)
    if (int16_eq_const_9_0 == 6743)
    if (int16_eq_const_10_0 == -21879)
    if (int16_eq_const_11_0 == -1165)
    if (int16_eq_const_12_0 == 4767)
    if (int16_eq_const_13_0 == 1133)
    if (int16_eq_const_14_0 == 13839)
    if (int16_eq_const_15_0 == 11559)
    if (int16_eq_const_16_0 == 23010)
    if (int16_eq_const_17_0 == 18633)
    if (int16_eq_const_18_0 == -13770)
    if (int16_eq_const_19_0 == -8554)
    if (int16_eq_const_20_0 == 350)
    if (int16_eq_const_21_0 == -14129)
    if (int16_eq_const_22_0 == 31130)
    if (int16_eq_const_23_0 == 4712)
    if (int16_eq_const_24_0 == -24738)
    if (int16_eq_const_25_0 == -4286)
    if (int16_eq_const_26_0 == 3222)
    if (int16_eq_const_27_0 == 5028)
    if (int16_eq_const_28_0 == 14911)
    if (int16_eq_const_29_0 == 6295)
    if (int16_eq_const_30_0 == 20844)
    if (int16_eq_const_31_0 == 25150)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
