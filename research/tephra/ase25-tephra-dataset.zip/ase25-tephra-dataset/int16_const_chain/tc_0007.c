#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int16_t int16_eq_const_6_0;

    if (size < 14)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == 20289)
    if (int16_eq_const_1_0 == 1408)
    if (int16_eq_const_2_0 == 21964)
    if (int16_eq_const_3_0 == 5469)
    if (int16_eq_const_4_0 == 12336)
    if (int16_eq_const_5_0 == 3695)
    if (int16_eq_const_6_0 == -25183)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
