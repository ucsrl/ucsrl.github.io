#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int16_t int16_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;
    int16_t int16_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    int16_t int16_eq_const_14_0;
    int16_t int16_eq_const_15_0;
    int16_t int16_eq_const_16_0;
    int16_t int16_eq_const_17_0;
    int16_t int16_eq_const_18_0;
    int16_t int16_eq_const_19_0;
    int16_t int16_eq_const_20_0;
    int16_t int16_eq_const_21_0;
    int16_t int16_eq_const_22_0;
    int16_t int16_eq_const_23_0;
    int16_t int16_eq_const_24_0;
    int16_t int16_eq_const_25_0;
    int16_t int16_eq_const_26_0;
    int16_t int16_eq_const_27_0;
    int16_t int16_eq_const_28_0;
    int16_t int16_eq_const_29_0;
    int16_t int16_eq_const_30_0;
    int16_t int16_eq_const_31_0;
    int16_t int16_eq_const_32_0;
    int16_t int16_eq_const_33_0;
    int16_t int16_eq_const_34_0;
    int16_t int16_eq_const_35_0;
    int16_t int16_eq_const_36_0;
    int16_t int16_eq_const_37_0;
    int16_t int16_eq_const_38_0;
    int16_t int16_eq_const_39_0;
    int16_t int16_eq_const_40_0;
    int16_t int16_eq_const_41_0;
    int16_t int16_eq_const_42_0;
    int16_t int16_eq_const_43_0;
    int16_t int16_eq_const_44_0;
    int16_t int16_eq_const_45_0;
    int16_t int16_eq_const_46_0;
    int16_t int16_eq_const_47_0;
    int16_t int16_eq_const_48_0;
    int16_t int16_eq_const_49_0;
    int16_t int16_eq_const_50_0;
    int16_t int16_eq_const_51_0;
    int16_t int16_eq_const_52_0;
    int16_t int16_eq_const_53_0;
    int16_t int16_eq_const_54_0;
    int16_t int16_eq_const_55_0;
    int16_t int16_eq_const_56_0;
    int16_t int16_eq_const_57_0;
    int16_t int16_eq_const_58_0;
    int16_t int16_eq_const_59_0;
    int16_t int16_eq_const_60_0;
    int16_t int16_eq_const_61_0;
    int16_t int16_eq_const_62_0;
    int16_t int16_eq_const_63_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_32_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_33_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_35_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_36_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_37_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_39_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_40_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_41_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_42_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_43_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_44_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_46_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_47_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_48_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_49_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_50_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_51_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_52_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_53_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_55_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_56_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_57_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_58_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_59_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_61_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_62_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_63_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == -23310)
    if (int16_eq_const_1_0 == -3058)
    if (int16_eq_const_2_0 == -23076)
    if (int16_eq_const_3_0 == 15574)
    if (int16_eq_const_4_0 == -15169)
    if (int16_eq_const_5_0 == -30506)
    if (int16_eq_const_6_0 == 24876)
    if (int16_eq_const_7_0 == 2063)
    if (int16_eq_const_8_0 == 25781)
    if (int16_eq_const_9_0 == -31222)
    if (int16_eq_const_10_0 == -2810)
    if (int16_eq_const_11_0 == -12492)
    if (int16_eq_const_12_0 == -22580)
    if (int16_eq_const_13_0 == 8328)
    if (int16_eq_const_14_0 == -2512)
    if (int16_eq_const_15_0 == 11844)
    if (int16_eq_const_16_0 == 4753)
    if (int16_eq_const_17_0 == 7550)
    if (int16_eq_const_18_0 == 13645)
    if (int16_eq_const_19_0 == 13464)
    if (int16_eq_const_20_0 == 1262)
    if (int16_eq_const_21_0 == 12750)
    if (int16_eq_const_22_0 == -16487)
    if (int16_eq_const_23_0 == -19546)
    if (int16_eq_const_24_0 == 5860)
    if (int16_eq_const_25_0 == 8031)
    if (int16_eq_const_26_0 == 24825)
    if (int16_eq_const_27_0 == 2959)
    if (int16_eq_const_28_0 == 31252)
    if (int16_eq_const_29_0 == -23672)
    if (int16_eq_const_30_0 == -11171)
    if (int16_eq_const_31_0 == 22689)
    if (int16_eq_const_32_0 == 10784)
    if (int16_eq_const_33_0 == -13319)
    if (int16_eq_const_34_0 == -17514)
    if (int16_eq_const_35_0 == 19304)
    if (int16_eq_const_36_0 == 9785)
    if (int16_eq_const_37_0 == -11847)
    if (int16_eq_const_38_0 == -21472)
    if (int16_eq_const_39_0 == -7430)
    if (int16_eq_const_40_0 == 9834)
    if (int16_eq_const_41_0 == 11301)
    if (int16_eq_const_42_0 == 6791)
    if (int16_eq_const_43_0 == -18545)
    if (int16_eq_const_44_0 == 16252)
    if (int16_eq_const_45_0 == 10257)
    if (int16_eq_const_46_0 == -19867)
    if (int16_eq_const_47_0 == -32356)
    if (int16_eq_const_48_0 == -20365)
    if (int16_eq_const_49_0 == -3743)
    if (int16_eq_const_50_0 == -19173)
    if (int16_eq_const_51_0 == 4098)
    if (int16_eq_const_52_0 == -23293)
    if (int16_eq_const_53_0 == -22572)
    if (int16_eq_const_54_0 == 19914)
    if (int16_eq_const_55_0 == -4612)
    if (int16_eq_const_56_0 == 4246)
    if (int16_eq_const_57_0 == -13882)
    if (int16_eq_const_58_0 == 25896)
    if (int16_eq_const_59_0 == -28691)
    if (int16_eq_const_60_0 == -6758)
    if (int16_eq_const_61_0 == -1497)
    if (int16_eq_const_62_0 == 25663)
    if (int16_eq_const_63_0 == -982)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
