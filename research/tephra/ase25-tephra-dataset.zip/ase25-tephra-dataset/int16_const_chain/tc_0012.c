#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int16_t int16_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;
    int16_t int16_eq_const_11_0;

    if (size < 24)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == -8454)
    if (int16_eq_const_1_0 == 24367)
    if (int16_eq_const_2_0 == 20036)
    if (int16_eq_const_3_0 == 7616)
    if (int16_eq_const_4_0 == -8234)
    if (int16_eq_const_5_0 == 12926)
    if (int16_eq_const_6_0 == 26778)
    if (int16_eq_const_7_0 == -19914)
    if (int16_eq_const_8_0 == 20258)
    if (int16_eq_const_9_0 == 8384)
    if (int16_eq_const_10_0 == -2399)
    if (int16_eq_const_11_0 == -12742)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
