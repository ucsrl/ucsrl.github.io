#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int16_t int16_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;
    int16_t int16_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    int16_t int16_eq_const_14_0;
    int16_t int16_eq_const_15_0;
    int16_t int16_eq_const_16_0;
    int16_t int16_eq_const_17_0;
    int16_t int16_eq_const_18_0;
    int16_t int16_eq_const_19_0;
    int16_t int16_eq_const_20_0;
    int16_t int16_eq_const_21_0;
    int16_t int16_eq_const_22_0;
    int16_t int16_eq_const_23_0;
    int16_t int16_eq_const_24_0;
    int16_t int16_eq_const_25_0;
    int16_t int16_eq_const_26_0;
    int16_t int16_eq_const_27_0;
    int16_t int16_eq_const_28_0;
    int16_t int16_eq_const_29_0;
    int16_t int16_eq_const_30_0;
    int16_t int16_eq_const_31_0;
    int16_t int16_eq_const_32_0;
    int16_t int16_eq_const_33_0;
    int16_t int16_eq_const_34_0;
    int16_t int16_eq_const_35_0;
    int16_t int16_eq_const_36_0;
    int16_t int16_eq_const_37_0;
    int16_t int16_eq_const_38_0;
    int16_t int16_eq_const_39_0;
    int16_t int16_eq_const_40_0;
    int16_t int16_eq_const_41_0;
    int16_t int16_eq_const_42_0;
    int16_t int16_eq_const_43_0;
    int16_t int16_eq_const_44_0;
    int16_t int16_eq_const_45_0;
    int16_t int16_eq_const_46_0;
    int16_t int16_eq_const_47_0;
    int16_t int16_eq_const_48_0;
    int16_t int16_eq_const_49_0;
    int16_t int16_eq_const_50_0;
    int16_t int16_eq_const_51_0;
    int16_t int16_eq_const_52_0;
    int16_t int16_eq_const_53_0;
    int16_t int16_eq_const_54_0;
    int16_t int16_eq_const_55_0;
    int16_t int16_eq_const_56_0;
    int16_t int16_eq_const_57_0;
    int16_t int16_eq_const_58_0;
    int16_t int16_eq_const_59_0;
    int16_t int16_eq_const_60_0;
    int16_t int16_eq_const_61_0;
    int16_t int16_eq_const_62_0;
    int16_t int16_eq_const_63_0;
    int16_t int16_eq_const_64_0;
    int16_t int16_eq_const_65_0;
    int16_t int16_eq_const_66_0;
    int16_t int16_eq_const_67_0;
    int16_t int16_eq_const_68_0;
    int16_t int16_eq_const_69_0;
    int16_t int16_eq_const_70_0;
    int16_t int16_eq_const_71_0;
    int16_t int16_eq_const_72_0;
    int16_t int16_eq_const_73_0;
    int16_t int16_eq_const_74_0;
    int16_t int16_eq_const_75_0;
    int16_t int16_eq_const_76_0;
    int16_t int16_eq_const_77_0;
    int16_t int16_eq_const_78_0;
    int16_t int16_eq_const_79_0;
    int16_t int16_eq_const_80_0;
    int16_t int16_eq_const_81_0;
    int16_t int16_eq_const_82_0;
    int16_t int16_eq_const_83_0;
    int16_t int16_eq_const_84_0;
    int16_t int16_eq_const_85_0;
    int16_t int16_eq_const_86_0;
    int16_t int16_eq_const_87_0;
    int16_t int16_eq_const_88_0;
    int16_t int16_eq_const_89_0;
    int16_t int16_eq_const_90_0;
    int16_t int16_eq_const_91_0;
    int16_t int16_eq_const_92_0;
    int16_t int16_eq_const_93_0;
    int16_t int16_eq_const_94_0;
    int16_t int16_eq_const_95_0;
    int16_t int16_eq_const_96_0;
    int16_t int16_eq_const_97_0;
    int16_t int16_eq_const_98_0;
    int16_t int16_eq_const_99_0;
    int16_t int16_eq_const_100_0;
    int16_t int16_eq_const_101_0;
    int16_t int16_eq_const_102_0;
    int16_t int16_eq_const_103_0;
    int16_t int16_eq_const_104_0;
    int16_t int16_eq_const_105_0;
    int16_t int16_eq_const_106_0;
    int16_t int16_eq_const_107_0;
    int16_t int16_eq_const_108_0;
    int16_t int16_eq_const_109_0;
    int16_t int16_eq_const_110_0;
    int16_t int16_eq_const_111_0;
    int16_t int16_eq_const_112_0;
    int16_t int16_eq_const_113_0;
    int16_t int16_eq_const_114_0;
    int16_t int16_eq_const_115_0;
    int16_t int16_eq_const_116_0;
    int16_t int16_eq_const_117_0;
    int16_t int16_eq_const_118_0;
    int16_t int16_eq_const_119_0;
    int16_t int16_eq_const_120_0;
    int16_t int16_eq_const_121_0;
    int16_t int16_eq_const_122_0;
    int16_t int16_eq_const_123_0;
    int16_t int16_eq_const_124_0;
    int16_t int16_eq_const_125_0;
    int16_t int16_eq_const_126_0;
    int16_t int16_eq_const_127_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_29_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_32_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_33_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_35_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_36_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_37_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_39_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_40_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_41_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_42_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_43_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_44_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_46_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_47_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_48_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_49_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_50_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_51_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_52_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_53_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_55_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_56_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_57_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_58_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_59_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_61_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_62_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_63_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_64_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_65_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_66_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_67_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_68_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_69_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_70_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_71_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_72_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_73_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_74_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_75_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_76_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_77_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_78_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_79_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_80_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_81_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_82_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_83_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_84_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_85_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_86_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_87_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_88_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_89_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_90_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_91_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_92_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_93_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_94_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_95_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_96_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_97_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_98_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_99_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_100_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_101_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_102_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_103_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_104_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_105_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_106_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_107_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_108_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_109_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_110_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_111_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_112_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_113_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_114_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_115_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_116_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_117_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_118_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_119_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_120_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_121_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_122_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_123_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_124_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_125_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_126_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_127_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == -4637)
    if (int16_eq_const_1_0 == 8455)
    if (int16_eq_const_2_0 == -22197)
    if (int16_eq_const_3_0 == -7222)
    if (int16_eq_const_4_0 == -5724)
    if (int16_eq_const_5_0 == 17346)
    if (int16_eq_const_6_0 == -8081)
    if (int16_eq_const_7_0 == 27094)
    if (int16_eq_const_8_0 == 29390)
    if (int16_eq_const_9_0 == 1288)
    if (int16_eq_const_10_0 == -20359)
    if (int16_eq_const_11_0 == -12025)
    if (int16_eq_const_12_0 == -17918)
    if (int16_eq_const_13_0 == -11205)
    if (int16_eq_const_14_0 == -27110)
    if (int16_eq_const_15_0 == 31270)
    if (int16_eq_const_16_0 == 4335)
    if (int16_eq_const_17_0 == -10067)
    if (int16_eq_const_18_0 == -11948)
    if (int16_eq_const_19_0 == 22871)
    if (int16_eq_const_20_0 == -6791)
    if (int16_eq_const_21_0 == 21877)
    if (int16_eq_const_22_0 == 30957)
    if (int16_eq_const_23_0 == 798)
    if (int16_eq_const_24_0 == -30847)
    if (int16_eq_const_25_0 == 3014)
    if (int16_eq_const_26_0 == -12076)
    if (int16_eq_const_27_0 == -7739)
    if (int16_eq_const_28_0 == 12039)
    if (int16_eq_const_29_0 == 8973)
    if (int16_eq_const_30_0 == -23436)
    if (int16_eq_const_31_0 == 10846)
    if (int16_eq_const_32_0 == -7972)
    if (int16_eq_const_33_0 == 8229)
    if (int16_eq_const_34_0 == -11740)
    if (int16_eq_const_35_0 == 3826)
    if (int16_eq_const_36_0 == -16374)
    if (int16_eq_const_37_0 == 32575)
    if (int16_eq_const_38_0 == -5853)
    if (int16_eq_const_39_0 == 6533)
    if (int16_eq_const_40_0 == 4783)
    if (int16_eq_const_41_0 == -27019)
    if (int16_eq_const_42_0 == -18475)
    if (int16_eq_const_43_0 == -28146)
    if (int16_eq_const_44_0 == -16133)
    if (int16_eq_const_45_0 == -32499)
    if (int16_eq_const_46_0 == -5072)
    if (int16_eq_const_47_0 == 20372)
    if (int16_eq_const_48_0 == 23931)
    if (int16_eq_const_49_0 == -2579)
    if (int16_eq_const_50_0 == 29842)
    if (int16_eq_const_51_0 == 23280)
    if (int16_eq_const_52_0 == -10768)
    if (int16_eq_const_53_0 == 5575)
    if (int16_eq_const_54_0 == 9062)
    if (int16_eq_const_55_0 == 22527)
    if (int16_eq_const_56_0 == -15274)
    if (int16_eq_const_57_0 == 28654)
    if (int16_eq_const_58_0 == 13402)
    if (int16_eq_const_59_0 == -16309)
    if (int16_eq_const_60_0 == -2084)
    if (int16_eq_const_61_0 == -18696)
    if (int16_eq_const_62_0 == -18940)
    if (int16_eq_const_63_0 == -26541)
    if (int16_eq_const_64_0 == 13806)
    if (int16_eq_const_65_0 == -8064)
    if (int16_eq_const_66_0 == -30913)
    if (int16_eq_const_67_0 == 28439)
    if (int16_eq_const_68_0 == 25493)
    if (int16_eq_const_69_0 == -19014)
    if (int16_eq_const_70_0 == -29798)
    if (int16_eq_const_71_0 == 9613)
    if (int16_eq_const_72_0 == 16335)
    if (int16_eq_const_73_0 == 11445)
    if (int16_eq_const_74_0 == -2395)
    if (int16_eq_const_75_0 == 12817)
    if (int16_eq_const_76_0 == -26721)
    if (int16_eq_const_77_0 == 15464)
    if (int16_eq_const_78_0 == 4592)
    if (int16_eq_const_79_0 == -11762)
    if (int16_eq_const_80_0 == 25846)
    if (int16_eq_const_81_0 == 16371)
    if (int16_eq_const_82_0 == -20981)
    if (int16_eq_const_83_0 == -7583)
    if (int16_eq_const_84_0 == -26179)
    if (int16_eq_const_85_0 == 26551)
    if (int16_eq_const_86_0 == -32024)
    if (int16_eq_const_87_0 == -6858)
    if (int16_eq_const_88_0 == 28827)
    if (int16_eq_const_89_0 == 10523)
    if (int16_eq_const_90_0 == 8274)
    if (int16_eq_const_91_0 == 4714)
    if (int16_eq_const_92_0 == -704)
    if (int16_eq_const_93_0 == 6196)
    if (int16_eq_const_94_0 == -19600)
    if (int16_eq_const_95_0 == 11684)
    if (int16_eq_const_96_0 == 24139)
    if (int16_eq_const_97_0 == 6298)
    if (int16_eq_const_98_0 == -11639)
    if (int16_eq_const_99_0 == 17337)
    if (int16_eq_const_100_0 == 25376)
    if (int16_eq_const_101_0 == 23845)
    if (int16_eq_const_102_0 == -19348)
    if (int16_eq_const_103_0 == 24337)
    if (int16_eq_const_104_0 == -20421)
    if (int16_eq_const_105_0 == 16478)
    if (int16_eq_const_106_0 == -19133)
    if (int16_eq_const_107_0 == -18154)
    if (int16_eq_const_108_0 == 27860)
    if (int16_eq_const_109_0 == -26159)
    if (int16_eq_const_110_0 == -12626)
    if (int16_eq_const_111_0 == -4895)
    if (int16_eq_const_112_0 == 19689)
    if (int16_eq_const_113_0 == -10584)
    if (int16_eq_const_114_0 == -19094)
    if (int16_eq_const_115_0 == 13760)
    if (int16_eq_const_116_0 == 23286)
    if (int16_eq_const_117_0 == -14815)
    if (int16_eq_const_118_0 == -23831)
    if (int16_eq_const_119_0 == -11711)
    if (int16_eq_const_120_0 == 15612)
    if (int16_eq_const_121_0 == -17203)
    if (int16_eq_const_122_0 == 28055)
    if (int16_eq_const_123_0 == 15049)
    if (int16_eq_const_124_0 == -12131)
    if (int16_eq_const_125_0 == 27574)
    if (int16_eq_const_126_0 == 30387)
    if (int16_eq_const_127_0 == -1791)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
