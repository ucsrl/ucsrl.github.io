#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int16_t int16_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int16_t int16_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;

    if (size < 22)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_2_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_8_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;


    if (int16_eq_const_0_0 == 14913)
    if (int16_eq_const_1_0 == 12007)
    if (int16_eq_const_2_0 == -12536)
    if (int16_eq_const_3_0 == -14610)
    if (int16_eq_const_4_0 == 10849)
    if (int16_eq_const_5_0 == 26435)
    if (int16_eq_const_6_0 == -8600)
    if (int16_eq_const_7_0 == -14697)
    if (int16_eq_const_8_0 == -2382)
    if (int16_eq_const_9_0 == 18540)
    if (int16_eq_const_10_0 == 27481)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
