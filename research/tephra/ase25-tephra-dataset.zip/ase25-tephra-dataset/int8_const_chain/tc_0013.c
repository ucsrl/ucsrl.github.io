#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int8_t int8_eq_const_0_0;
    int8_t int8_eq_const_1_0;
    int8_t int8_eq_const_2_0;
    int8_t int8_eq_const_3_0;
    int8_t int8_eq_const_4_0;
    int8_t int8_eq_const_5_0;
    int8_t int8_eq_const_6_0;
    int8_t int8_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int8_t int8_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int8_t int8_eq_const_11_0;
    int8_t int8_eq_const_12_0;

    if (size < 13)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_12_0, &data[i], 1);
    i += 1;


    if (int8_eq_const_0_0 == -96)
    if (int8_eq_const_1_0 == -1)
    if (int8_eq_const_2_0 == -122)
    if (int8_eq_const_3_0 == -119)
    if (int8_eq_const_4_0 == -5)
    if (int8_eq_const_5_0 == 39)
    if (int8_eq_const_6_0 == -27)
    if (int8_eq_const_7_0 == 112)
    if (int8_eq_const_8_0 == -30)
    if (int8_eq_const_9_0 == 37)
    if (int8_eq_const_10_0 == 69)
    if (int8_eq_const_11_0 == 100)
    if (int8_eq_const_12_0 == 25)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
