#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int8_t int8_eq_const_0_0;
    int8_t int8_eq_const_1_0;
    int8_t int8_eq_const_2_0;
    int8_t int8_eq_const_3_0;
    int8_t int8_eq_const_4_0;
    int8_t int8_eq_const_5_0;
    int8_t int8_eq_const_6_0;
    int8_t int8_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int8_t int8_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int8_t int8_eq_const_11_0;
    int8_t int8_eq_const_12_0;
    int8_t int8_eq_const_13_0;
    int8_t int8_eq_const_14_0;
    int8_t int8_eq_const_15_0;
    int8_t int8_eq_const_16_0;
    int8_t int8_eq_const_17_0;
    int8_t int8_eq_const_18_0;
    int8_t int8_eq_const_19_0;
    int8_t int8_eq_const_20_0;
    int8_t int8_eq_const_21_0;
    int8_t int8_eq_const_22_0;
    int8_t int8_eq_const_23_0;
    int8_t int8_eq_const_24_0;
    int8_t int8_eq_const_25_0;
    int8_t int8_eq_const_26_0;
    int8_t int8_eq_const_27_0;
    int8_t int8_eq_const_28_0;
    int8_t int8_eq_const_29_0;
    int8_t int8_eq_const_30_0;
    int8_t int8_eq_const_31_0;
    int8_t int8_eq_const_32_0;
    int8_t int8_eq_const_33_0;
    int8_t int8_eq_const_34_0;
    int8_t int8_eq_const_35_0;
    int8_t int8_eq_const_36_0;
    int8_t int8_eq_const_37_0;
    int8_t int8_eq_const_38_0;
    int8_t int8_eq_const_39_0;
    int8_t int8_eq_const_40_0;
    int8_t int8_eq_const_41_0;
    int8_t int8_eq_const_42_0;
    int8_t int8_eq_const_43_0;
    int8_t int8_eq_const_44_0;
    int8_t int8_eq_const_45_0;
    int8_t int8_eq_const_46_0;
    int8_t int8_eq_const_47_0;
    int8_t int8_eq_const_48_0;
    int8_t int8_eq_const_49_0;
    int8_t int8_eq_const_50_0;
    int8_t int8_eq_const_51_0;
    int8_t int8_eq_const_52_0;
    int8_t int8_eq_const_53_0;
    int8_t int8_eq_const_54_0;
    int8_t int8_eq_const_55_0;
    int8_t int8_eq_const_56_0;
    int8_t int8_eq_const_57_0;
    int8_t int8_eq_const_58_0;
    int8_t int8_eq_const_59_0;
    int8_t int8_eq_const_60_0;
    int8_t int8_eq_const_61_0;
    int8_t int8_eq_const_62_0;
    int8_t int8_eq_const_63_0;

    if (size < 64)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_20_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_23_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_32_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_37_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_40_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_51_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_57_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_58_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_62_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_63_0, &data[i], 1);
    i += 1;


    if (int8_eq_const_0_0 == 87)
    if (int8_eq_const_1_0 == -104)
    if (int8_eq_const_2_0 == 105)
    if (int8_eq_const_3_0 == 29)
    if (int8_eq_const_4_0 == 22)
    if (int8_eq_const_5_0 == -87)
    if (int8_eq_const_6_0 == 127)
    if (int8_eq_const_7_0 == 22)
    if (int8_eq_const_8_0 == 71)
    if (int8_eq_const_9_0 == 4)
    if (int8_eq_const_10_0 == -109)
    if (int8_eq_const_11_0 == -2)
    if (int8_eq_const_12_0 == -83)
    if (int8_eq_const_13_0 == -1)
    if (int8_eq_const_14_0 == 48)
    if (int8_eq_const_15_0 == 39)
    if (int8_eq_const_16_0 == -37)
    if (int8_eq_const_17_0 == 13)
    if (int8_eq_const_18_0 == 68)
    if (int8_eq_const_19_0 == 6)
    if (int8_eq_const_20_0 == -83)
    if (int8_eq_const_21_0 == 54)
    if (int8_eq_const_22_0 == 12)
    if (int8_eq_const_23_0 == -11)
    if (int8_eq_const_24_0 == -42)
    if (int8_eq_const_25_0 == -118)
    if (int8_eq_const_26_0 == 76)
    if (int8_eq_const_27_0 == 52)
    if (int8_eq_const_28_0 == -51)
    if (int8_eq_const_29_0 == 35)
    if (int8_eq_const_30_0 == 16)
    if (int8_eq_const_31_0 == 4)
    if (int8_eq_const_32_0 == 9)
    if (int8_eq_const_33_0 == -61)
    if (int8_eq_const_34_0 == -88)
    if (int8_eq_const_35_0 == 50)
    if (int8_eq_const_36_0 == -28)
    if (int8_eq_const_37_0 == -12)
    if (int8_eq_const_38_0 == -60)
    if (int8_eq_const_39_0 == -5)
    if (int8_eq_const_40_0 == -22)
    if (int8_eq_const_41_0 == 22)
    if (int8_eq_const_42_0 == -87)
    if (int8_eq_const_43_0 == -62)
    if (int8_eq_const_44_0 == 2)
    if (int8_eq_const_45_0 == -65)
    if (int8_eq_const_46_0 == 33)
    if (int8_eq_const_47_0 == -42)
    if (int8_eq_const_48_0 == 39)
    if (int8_eq_const_49_0 == 80)
    if (int8_eq_const_50_0 == 124)
    if (int8_eq_const_51_0 == 2)
    if (int8_eq_const_52_0 == 114)
    if (int8_eq_const_53_0 == -60)
    if (int8_eq_const_54_0 == 36)
    if (int8_eq_const_55_0 == 113)
    if (int8_eq_const_56_0 == 23)
    if (int8_eq_const_57_0 == 62)
    if (int8_eq_const_58_0 == -95)
    if (int8_eq_const_59_0 == 49)
    if (int8_eq_const_60_0 == -92)
    if (int8_eq_const_61_0 == 9)
    if (int8_eq_const_62_0 == -112)
    if (int8_eq_const_63_0 == 57)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
