#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int8_t int8_eq_const_0_0;
    int8_t int8_eq_const_1_0;
    int8_t int8_eq_const_2_0;
    int8_t int8_eq_const_3_0;
    int8_t int8_eq_const_4_0;
    int8_t int8_eq_const_5_0;
    int8_t int8_eq_const_6_0;
    int8_t int8_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int8_t int8_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int8_t int8_eq_const_11_0;
    int8_t int8_eq_const_12_0;
    int8_t int8_eq_const_13_0;
    int8_t int8_eq_const_14_0;
    int8_t int8_eq_const_15_0;
    int8_t int8_eq_const_16_0;
    int8_t int8_eq_const_17_0;
    int8_t int8_eq_const_18_0;
    int8_t int8_eq_const_19_0;
    int8_t int8_eq_const_20_0;
    int8_t int8_eq_const_21_0;
    int8_t int8_eq_const_22_0;
    int8_t int8_eq_const_23_0;
    int8_t int8_eq_const_24_0;
    int8_t int8_eq_const_25_0;
    int8_t int8_eq_const_26_0;
    int8_t int8_eq_const_27_0;
    int8_t int8_eq_const_28_0;
    int8_t int8_eq_const_29_0;
    int8_t int8_eq_const_30_0;
    int8_t int8_eq_const_31_0;
    int8_t int8_eq_const_32_0;
    int8_t int8_eq_const_33_0;
    int8_t int8_eq_const_34_0;
    int8_t int8_eq_const_35_0;
    int8_t int8_eq_const_36_0;
    int8_t int8_eq_const_37_0;
    int8_t int8_eq_const_38_0;
    int8_t int8_eq_const_39_0;
    int8_t int8_eq_const_40_0;
    int8_t int8_eq_const_41_0;
    int8_t int8_eq_const_42_0;
    int8_t int8_eq_const_43_0;
    int8_t int8_eq_const_44_0;
    int8_t int8_eq_const_45_0;
    int8_t int8_eq_const_46_0;
    int8_t int8_eq_const_47_0;
    int8_t int8_eq_const_48_0;
    int8_t int8_eq_const_49_0;
    int8_t int8_eq_const_50_0;
    int8_t int8_eq_const_51_0;
    int8_t int8_eq_const_52_0;
    int8_t int8_eq_const_53_0;
    int8_t int8_eq_const_54_0;
    int8_t int8_eq_const_55_0;
    int8_t int8_eq_const_56_0;
    int8_t int8_eq_const_57_0;
    int8_t int8_eq_const_58_0;
    int8_t int8_eq_const_59_0;
    int8_t int8_eq_const_60_0;
    int8_t int8_eq_const_61_0;
    int8_t int8_eq_const_62_0;
    int8_t int8_eq_const_63_0;
    int8_t int8_eq_const_64_0;
    int8_t int8_eq_const_65_0;
    int8_t int8_eq_const_66_0;
    int8_t int8_eq_const_67_0;
    int8_t int8_eq_const_68_0;
    int8_t int8_eq_const_69_0;
    int8_t int8_eq_const_70_0;
    int8_t int8_eq_const_71_0;
    int8_t int8_eq_const_72_0;
    int8_t int8_eq_const_73_0;
    int8_t int8_eq_const_74_0;
    int8_t int8_eq_const_75_0;
    int8_t int8_eq_const_76_0;
    int8_t int8_eq_const_77_0;
    int8_t int8_eq_const_78_0;
    int8_t int8_eq_const_79_0;
    int8_t int8_eq_const_80_0;
    int8_t int8_eq_const_81_0;
    int8_t int8_eq_const_82_0;
    int8_t int8_eq_const_83_0;
    int8_t int8_eq_const_84_0;
    int8_t int8_eq_const_85_0;
    int8_t int8_eq_const_86_0;
    int8_t int8_eq_const_87_0;
    int8_t int8_eq_const_88_0;
    int8_t int8_eq_const_89_0;
    int8_t int8_eq_const_90_0;
    int8_t int8_eq_const_91_0;
    int8_t int8_eq_const_92_0;
    int8_t int8_eq_const_93_0;
    int8_t int8_eq_const_94_0;
    int8_t int8_eq_const_95_0;
    int8_t int8_eq_const_96_0;
    int8_t int8_eq_const_97_0;
    int8_t int8_eq_const_98_0;
    int8_t int8_eq_const_99_0;
    int8_t int8_eq_const_100_0;
    int8_t int8_eq_const_101_0;
    int8_t int8_eq_const_102_0;
    int8_t int8_eq_const_103_0;
    int8_t int8_eq_const_104_0;
    int8_t int8_eq_const_105_0;
    int8_t int8_eq_const_106_0;
    int8_t int8_eq_const_107_0;
    int8_t int8_eq_const_108_0;
    int8_t int8_eq_const_109_0;
    int8_t int8_eq_const_110_0;
    int8_t int8_eq_const_111_0;
    int8_t int8_eq_const_112_0;
    int8_t int8_eq_const_113_0;
    int8_t int8_eq_const_114_0;
    int8_t int8_eq_const_115_0;
    int8_t int8_eq_const_116_0;
    int8_t int8_eq_const_117_0;
    int8_t int8_eq_const_118_0;
    int8_t int8_eq_const_119_0;
    int8_t int8_eq_const_120_0;
    int8_t int8_eq_const_121_0;
    int8_t int8_eq_const_122_0;
    int8_t int8_eq_const_123_0;
    int8_t int8_eq_const_124_0;
    int8_t int8_eq_const_125_0;
    int8_t int8_eq_const_126_0;
    int8_t int8_eq_const_127_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_20_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_23_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_32_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_37_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_40_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_51_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_57_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_58_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_62_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_63_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_64_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_65_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_66_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_67_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_68_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_69_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_71_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_72_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_73_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_74_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_75_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_76_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_77_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_78_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_79_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_81_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_82_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_83_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_85_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_86_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_87_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_88_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_89_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_90_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_91_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_92_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_94_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_95_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_97_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_98_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_99_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_100_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_101_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_103_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_104_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_105_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_106_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_107_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_108_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_109_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_110_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_111_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_112_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_113_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_114_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_115_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_116_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_117_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_118_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_119_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_120_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_121_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_122_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_123_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_125_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_126_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_127_0, &data[i], 1);
    i += 1;


    if (int8_eq_const_0_0 == -127)
    if (int8_eq_const_1_0 == -117)
    if (int8_eq_const_2_0 == 116)
    if (int8_eq_const_3_0 == -17)
    if (int8_eq_const_4_0 == -91)
    if (int8_eq_const_5_0 == -118)
    if (int8_eq_const_6_0 == 23)
    if (int8_eq_const_7_0 == -58)
    if (int8_eq_const_8_0 == -72)
    if (int8_eq_const_9_0 == 61)
    if (int8_eq_const_10_0 == 2)
    if (int8_eq_const_11_0 == -113)
    if (int8_eq_const_12_0 == 35)
    if (int8_eq_const_13_0 == 1)
    if (int8_eq_const_14_0 == 123)
    if (int8_eq_const_15_0 == 84)
    if (int8_eq_const_16_0 == -99)
    if (int8_eq_const_17_0 == 22)
    if (int8_eq_const_18_0 == 61)
    if (int8_eq_const_19_0 == 17)
    if (int8_eq_const_20_0 == 4)
    if (int8_eq_const_21_0 == -40)
    if (int8_eq_const_22_0 == 67)
    if (int8_eq_const_23_0 == 44)
    if (int8_eq_const_24_0 == -67)
    if (int8_eq_const_25_0 == 31)
    if (int8_eq_const_26_0 == 94)
    if (int8_eq_const_27_0 == 113)
    if (int8_eq_const_28_0 == 86)
    if (int8_eq_const_29_0 == -60)
    if (int8_eq_const_30_0 == 18)
    if (int8_eq_const_31_0 == 116)
    if (int8_eq_const_32_0 == -126)
    if (int8_eq_const_33_0 == 57)
    if (int8_eq_const_34_0 == 82)
    if (int8_eq_const_35_0 == 105)
    if (int8_eq_const_36_0 == 72)
    if (int8_eq_const_37_0 == -107)
    if (int8_eq_const_38_0 == 52)
    if (int8_eq_const_39_0 == -126)
    if (int8_eq_const_40_0 == 42)
    if (int8_eq_const_41_0 == 93)
    if (int8_eq_const_42_0 == 107)
    if (int8_eq_const_43_0 == 7)
    if (int8_eq_const_44_0 == 91)
    if (int8_eq_const_45_0 == -28)
    if (int8_eq_const_46_0 == -127)
    if (int8_eq_const_47_0 == 117)
    if (int8_eq_const_48_0 == -97)
    if (int8_eq_const_49_0 == 18)
    if (int8_eq_const_50_0 == -47)
    if (int8_eq_const_51_0 == 45)
    if (int8_eq_const_52_0 == 79)
    if (int8_eq_const_53_0 == -2)
    if (int8_eq_const_54_0 == 67)
    if (int8_eq_const_55_0 == 76)
    if (int8_eq_const_56_0 == -2)
    if (int8_eq_const_57_0 == -57)
    if (int8_eq_const_58_0 == 53)
    if (int8_eq_const_59_0 == -81)
    if (int8_eq_const_60_0 == -48)
    if (int8_eq_const_61_0 == -41)
    if (int8_eq_const_62_0 == -97)
    if (int8_eq_const_63_0 == 58)
    if (int8_eq_const_64_0 == -2)
    if (int8_eq_const_65_0 == -57)
    if (int8_eq_const_66_0 == 118)
    if (int8_eq_const_67_0 == -31)
    if (int8_eq_const_68_0 == 56)
    if (int8_eq_const_69_0 == -46)
    if (int8_eq_const_70_0 == 120)
    if (int8_eq_const_71_0 == 58)
    if (int8_eq_const_72_0 == -89)
    if (int8_eq_const_73_0 == -11)
    if (int8_eq_const_74_0 == 56)
    if (int8_eq_const_75_0 == -71)
    if (int8_eq_const_76_0 == -31)
    if (int8_eq_const_77_0 == -80)
    if (int8_eq_const_78_0 == -59)
    if (int8_eq_const_79_0 == 29)
    if (int8_eq_const_80_0 == -6)
    if (int8_eq_const_81_0 == 127)
    if (int8_eq_const_82_0 == -96)
    if (int8_eq_const_83_0 == -15)
    if (int8_eq_const_84_0 == -36)
    if (int8_eq_const_85_0 == 3)
    if (int8_eq_const_86_0 == -48)
    if (int8_eq_const_87_0 == -100)
    if (int8_eq_const_88_0 == 120)
    if (int8_eq_const_89_0 == 58)
    if (int8_eq_const_90_0 == -78)
    if (int8_eq_const_91_0 == -73)
    if (int8_eq_const_92_0 == 16)
    if (int8_eq_const_93_0 == -40)
    if (int8_eq_const_94_0 == -28)
    if (int8_eq_const_95_0 == 42)
    if (int8_eq_const_96_0 == -88)
    if (int8_eq_const_97_0 == 100)
    if (int8_eq_const_98_0 == 7)
    if (int8_eq_const_99_0 == -35)
    if (int8_eq_const_100_0 == 9)
    if (int8_eq_const_101_0 == -109)
    if (int8_eq_const_102_0 == 77)
    if (int8_eq_const_103_0 == -122)
    if (int8_eq_const_104_0 == 20)
    if (int8_eq_const_105_0 == -37)
    if (int8_eq_const_106_0 == -36)
    if (int8_eq_const_107_0 == -93)
    if (int8_eq_const_108_0 == 6)
    if (int8_eq_const_109_0 == 38)
    if (int8_eq_const_110_0 == -69)
    if (int8_eq_const_111_0 == 84)
    if (int8_eq_const_112_0 == 84)
    if (int8_eq_const_113_0 == 48)
    if (int8_eq_const_114_0 == -93)
    if (int8_eq_const_115_0 == 123)
    if (int8_eq_const_116_0 == 5)
    if (int8_eq_const_117_0 == 17)
    if (int8_eq_const_118_0 == 101)
    if (int8_eq_const_119_0 == 51)
    if (int8_eq_const_120_0 == 39)
    if (int8_eq_const_121_0 == 10)
    if (int8_eq_const_122_0 == -96)
    if (int8_eq_const_123_0 == 103)
    if (int8_eq_const_124_0 == -32)
    if (int8_eq_const_125_0 == -24)
    if (int8_eq_const_126_0 == -114)
    if (int8_eq_const_127_0 == 31)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
