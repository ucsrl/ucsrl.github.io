#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int8_t int8_eq_const_0_0;
    int8_t int8_eq_const_1_0;
    int8_t int8_eq_const_2_0;
    int8_t int8_eq_const_3_0;
    int8_t int8_eq_const_4_0;
    int8_t int8_eq_const_5_0;
    int8_t int8_eq_const_6_0;
    int8_t int8_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int8_t int8_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int8_t int8_eq_const_11_0;
    int8_t int8_eq_const_12_0;
    int8_t int8_eq_const_13_0;
    int8_t int8_eq_const_14_0;
    int8_t int8_eq_const_15_0;
    int8_t int8_eq_const_16_0;
    int8_t int8_eq_const_17_0;
    int8_t int8_eq_const_18_0;
    int8_t int8_eq_const_19_0;
    int8_t int8_eq_const_20_0;
    int8_t int8_eq_const_21_0;
    int8_t int8_eq_const_22_0;
    int8_t int8_eq_const_23_0;
    int8_t int8_eq_const_24_0;
    int8_t int8_eq_const_25_0;
    int8_t int8_eq_const_26_0;
    int8_t int8_eq_const_27_0;
    int8_t int8_eq_const_28_0;
    int8_t int8_eq_const_29_0;
    int8_t int8_eq_const_30_0;
    int8_t int8_eq_const_31_0;
    int8_t int8_eq_const_32_0;
    int8_t int8_eq_const_33_0;
    int8_t int8_eq_const_34_0;
    int8_t int8_eq_const_35_0;
    int8_t int8_eq_const_36_0;
    int8_t int8_eq_const_37_0;
    int8_t int8_eq_const_38_0;
    int8_t int8_eq_const_39_0;
    int8_t int8_eq_const_40_0;
    int8_t int8_eq_const_41_0;
    int8_t int8_eq_const_42_0;
    int8_t int8_eq_const_43_0;
    int8_t int8_eq_const_44_0;
    int8_t int8_eq_const_45_0;
    int8_t int8_eq_const_46_0;
    int8_t int8_eq_const_47_0;
    int8_t int8_eq_const_48_0;
    int8_t int8_eq_const_49_0;
    int8_t int8_eq_const_50_0;
    int8_t int8_eq_const_51_0;
    int8_t int8_eq_const_52_0;
    int8_t int8_eq_const_53_0;
    int8_t int8_eq_const_54_0;
    int8_t int8_eq_const_55_0;
    int8_t int8_eq_const_56_0;
    int8_t int8_eq_const_57_0;
    int8_t int8_eq_const_58_0;
    int8_t int8_eq_const_59_0;
    int8_t int8_eq_const_60_0;
    int8_t int8_eq_const_61_0;
    int8_t int8_eq_const_62_0;
    int8_t int8_eq_const_63_0;
    int8_t int8_eq_const_64_0;
    int8_t int8_eq_const_65_0;
    int8_t int8_eq_const_66_0;
    int8_t int8_eq_const_67_0;
    int8_t int8_eq_const_68_0;
    int8_t int8_eq_const_69_0;
    int8_t int8_eq_const_70_0;
    int8_t int8_eq_const_71_0;
    int8_t int8_eq_const_72_0;
    int8_t int8_eq_const_73_0;
    int8_t int8_eq_const_74_0;
    int8_t int8_eq_const_75_0;
    int8_t int8_eq_const_76_0;
    int8_t int8_eq_const_77_0;
    int8_t int8_eq_const_78_0;
    int8_t int8_eq_const_79_0;
    int8_t int8_eq_const_80_0;
    int8_t int8_eq_const_81_0;
    int8_t int8_eq_const_82_0;
    int8_t int8_eq_const_83_0;
    int8_t int8_eq_const_84_0;
    int8_t int8_eq_const_85_0;
    int8_t int8_eq_const_86_0;
    int8_t int8_eq_const_87_0;
    int8_t int8_eq_const_88_0;
    int8_t int8_eq_const_89_0;
    int8_t int8_eq_const_90_0;
    int8_t int8_eq_const_91_0;
    int8_t int8_eq_const_92_0;
    int8_t int8_eq_const_93_0;
    int8_t int8_eq_const_94_0;
    int8_t int8_eq_const_95_0;
    int8_t int8_eq_const_96_0;
    int8_t int8_eq_const_97_0;
    int8_t int8_eq_const_98_0;
    int8_t int8_eq_const_99_0;
    int8_t int8_eq_const_100_0;
    int8_t int8_eq_const_101_0;
    int8_t int8_eq_const_102_0;
    int8_t int8_eq_const_103_0;
    int8_t int8_eq_const_104_0;
    int8_t int8_eq_const_105_0;
    int8_t int8_eq_const_106_0;
    int8_t int8_eq_const_107_0;
    int8_t int8_eq_const_108_0;
    int8_t int8_eq_const_109_0;
    int8_t int8_eq_const_110_0;
    int8_t int8_eq_const_111_0;
    int8_t int8_eq_const_112_0;
    int8_t int8_eq_const_113_0;
    int8_t int8_eq_const_114_0;
    int8_t int8_eq_const_115_0;
    int8_t int8_eq_const_116_0;
    int8_t int8_eq_const_117_0;
    int8_t int8_eq_const_118_0;
    int8_t int8_eq_const_119_0;
    int8_t int8_eq_const_120_0;
    int8_t int8_eq_const_121_0;
    int8_t int8_eq_const_122_0;
    int8_t int8_eq_const_123_0;
    int8_t int8_eq_const_124_0;
    int8_t int8_eq_const_125_0;
    int8_t int8_eq_const_126_0;
    int8_t int8_eq_const_127_0;
    int8_t int8_eq_const_128_0;
    int8_t int8_eq_const_129_0;
    int8_t int8_eq_const_130_0;
    int8_t int8_eq_const_131_0;
    int8_t int8_eq_const_132_0;
    int8_t int8_eq_const_133_0;
    int8_t int8_eq_const_134_0;
    int8_t int8_eq_const_135_0;
    int8_t int8_eq_const_136_0;
    int8_t int8_eq_const_137_0;
    int8_t int8_eq_const_138_0;
    int8_t int8_eq_const_139_0;
    int8_t int8_eq_const_140_0;
    int8_t int8_eq_const_141_0;
    int8_t int8_eq_const_142_0;
    int8_t int8_eq_const_143_0;
    int8_t int8_eq_const_144_0;
    int8_t int8_eq_const_145_0;
    int8_t int8_eq_const_146_0;
    int8_t int8_eq_const_147_0;
    int8_t int8_eq_const_148_0;
    int8_t int8_eq_const_149_0;
    int8_t int8_eq_const_150_0;
    int8_t int8_eq_const_151_0;
    int8_t int8_eq_const_152_0;
    int8_t int8_eq_const_153_0;
    int8_t int8_eq_const_154_0;
    int8_t int8_eq_const_155_0;
    int8_t int8_eq_const_156_0;
    int8_t int8_eq_const_157_0;
    int8_t int8_eq_const_158_0;
    int8_t int8_eq_const_159_0;
    int8_t int8_eq_const_160_0;
    int8_t int8_eq_const_161_0;
    int8_t int8_eq_const_162_0;
    int8_t int8_eq_const_163_0;
    int8_t int8_eq_const_164_0;
    int8_t int8_eq_const_165_0;
    int8_t int8_eq_const_166_0;
    int8_t int8_eq_const_167_0;
    int8_t int8_eq_const_168_0;
    int8_t int8_eq_const_169_0;
    int8_t int8_eq_const_170_0;
    int8_t int8_eq_const_171_0;
    int8_t int8_eq_const_172_0;
    int8_t int8_eq_const_173_0;
    int8_t int8_eq_const_174_0;
    int8_t int8_eq_const_175_0;
    int8_t int8_eq_const_176_0;
    int8_t int8_eq_const_177_0;
    int8_t int8_eq_const_178_0;
    int8_t int8_eq_const_179_0;
    int8_t int8_eq_const_180_0;
    int8_t int8_eq_const_181_0;
    int8_t int8_eq_const_182_0;
    int8_t int8_eq_const_183_0;
    int8_t int8_eq_const_184_0;
    int8_t int8_eq_const_185_0;
    int8_t int8_eq_const_186_0;
    int8_t int8_eq_const_187_0;
    int8_t int8_eq_const_188_0;
    int8_t int8_eq_const_189_0;
    int8_t int8_eq_const_190_0;
    int8_t int8_eq_const_191_0;
    int8_t int8_eq_const_192_0;
    int8_t int8_eq_const_193_0;
    int8_t int8_eq_const_194_0;
    int8_t int8_eq_const_195_0;
    int8_t int8_eq_const_196_0;
    int8_t int8_eq_const_197_0;
    int8_t int8_eq_const_198_0;
    int8_t int8_eq_const_199_0;
    int8_t int8_eq_const_200_0;
    int8_t int8_eq_const_201_0;
    int8_t int8_eq_const_202_0;
    int8_t int8_eq_const_203_0;
    int8_t int8_eq_const_204_0;
    int8_t int8_eq_const_205_0;
    int8_t int8_eq_const_206_0;
    int8_t int8_eq_const_207_0;
    int8_t int8_eq_const_208_0;
    int8_t int8_eq_const_209_0;
    int8_t int8_eq_const_210_0;
    int8_t int8_eq_const_211_0;
    int8_t int8_eq_const_212_0;
    int8_t int8_eq_const_213_0;
    int8_t int8_eq_const_214_0;
    int8_t int8_eq_const_215_0;
    int8_t int8_eq_const_216_0;
    int8_t int8_eq_const_217_0;
    int8_t int8_eq_const_218_0;
    int8_t int8_eq_const_219_0;
    int8_t int8_eq_const_220_0;
    int8_t int8_eq_const_221_0;
    int8_t int8_eq_const_222_0;
    int8_t int8_eq_const_223_0;
    int8_t int8_eq_const_224_0;
    int8_t int8_eq_const_225_0;
    int8_t int8_eq_const_226_0;
    int8_t int8_eq_const_227_0;
    int8_t int8_eq_const_228_0;
    int8_t int8_eq_const_229_0;
    int8_t int8_eq_const_230_0;
    int8_t int8_eq_const_231_0;
    int8_t int8_eq_const_232_0;
    int8_t int8_eq_const_233_0;
    int8_t int8_eq_const_234_0;
    int8_t int8_eq_const_235_0;
    int8_t int8_eq_const_236_0;
    int8_t int8_eq_const_237_0;
    int8_t int8_eq_const_238_0;
    int8_t int8_eq_const_239_0;
    int8_t int8_eq_const_240_0;
    int8_t int8_eq_const_241_0;
    int8_t int8_eq_const_242_0;
    int8_t int8_eq_const_243_0;
    int8_t int8_eq_const_244_0;
    int8_t int8_eq_const_245_0;
    int8_t int8_eq_const_246_0;
    int8_t int8_eq_const_247_0;
    int8_t int8_eq_const_248_0;
    int8_t int8_eq_const_249_0;
    int8_t int8_eq_const_250_0;
    int8_t int8_eq_const_251_0;
    int8_t int8_eq_const_252_0;
    int8_t int8_eq_const_253_0;
    int8_t int8_eq_const_254_0;
    int8_t int8_eq_const_255_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_20_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_23_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_32_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_37_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_40_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_51_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_57_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_58_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_62_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_63_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_64_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_65_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_66_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_67_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_68_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_69_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_71_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_72_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_73_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_74_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_75_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_76_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_77_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_78_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_79_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_81_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_82_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_83_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_85_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_86_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_87_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_88_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_89_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_90_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_91_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_92_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_94_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_95_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_97_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_98_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_99_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_100_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_101_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_103_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_104_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_105_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_106_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_107_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_108_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_109_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_110_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_111_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_112_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_113_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_114_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_115_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_116_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_117_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_118_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_119_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_120_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_121_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_122_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_123_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_125_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_126_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_127_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_128_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_129_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_130_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_131_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_132_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_133_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_134_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_135_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_136_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_137_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_138_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_139_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_140_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_141_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_142_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_143_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_144_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_145_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_146_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_147_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_148_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_149_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_150_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_151_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_152_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_153_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_154_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_155_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_156_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_157_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_158_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_159_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_160_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_161_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_162_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_163_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_164_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_165_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_166_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_167_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_168_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_169_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_170_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_171_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_172_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_173_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_174_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_175_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_176_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_177_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_178_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_179_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_180_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_181_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_182_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_183_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_184_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_185_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_186_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_187_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_188_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_189_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_190_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_191_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_192_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_193_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_194_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_195_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_196_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_197_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_198_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_199_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_200_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_201_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_202_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_203_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_204_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_205_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_206_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_207_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_208_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_209_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_210_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_211_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_212_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_213_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_214_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_215_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_216_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_217_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_218_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_219_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_220_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_221_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_222_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_223_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_224_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_225_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_226_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_227_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_228_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_229_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_230_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_231_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_232_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_233_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_234_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_235_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_236_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_237_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_238_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_239_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_240_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_241_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_242_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_243_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_244_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_245_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_246_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_247_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_248_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_249_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_250_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_251_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_252_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_253_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_254_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_255_0, &data[i], 1);
    i += 1;


    if (int8_eq_const_0_0 == 32)
    if (int8_eq_const_1_0 == -109)
    if (int8_eq_const_2_0 == 116)
    if (int8_eq_const_3_0 == 64)
    if (int8_eq_const_4_0 == -9)
    if (int8_eq_const_5_0 == 47)
    if (int8_eq_const_6_0 == -127)
    if (int8_eq_const_7_0 == 0)
    if (int8_eq_const_8_0 == 104)
    if (int8_eq_const_9_0 == 66)
    if (int8_eq_const_10_0 == 105)
    if (int8_eq_const_11_0 == 126)
    if (int8_eq_const_12_0 == -4)
    if (int8_eq_const_13_0 == -30)
    if (int8_eq_const_14_0 == 55)
    if (int8_eq_const_15_0 == 31)
    if (int8_eq_const_16_0 == 60)
    if (int8_eq_const_17_0 == 30)
    if (int8_eq_const_18_0 == -45)
    if (int8_eq_const_19_0 == 94)
    if (int8_eq_const_20_0 == 17)
    if (int8_eq_const_21_0 == -1)
    if (int8_eq_const_22_0 == -81)
    if (int8_eq_const_23_0 == 105)
    if (int8_eq_const_24_0 == 64)
    if (int8_eq_const_25_0 == -77)
    if (int8_eq_const_26_0 == -18)
    if (int8_eq_const_27_0 == 78)
    if (int8_eq_const_28_0 == -49)
    if (int8_eq_const_29_0 == -56)
    if (int8_eq_const_30_0 == 60)
    if (int8_eq_const_31_0 == 9)
    if (int8_eq_const_32_0 == -128)
    if (int8_eq_const_33_0 == 52)
    if (int8_eq_const_34_0 == 87)
    if (int8_eq_const_35_0 == -53)
    if (int8_eq_const_36_0 == 86)
    if (int8_eq_const_37_0 == 107)
    if (int8_eq_const_38_0 == 36)
    if (int8_eq_const_39_0 == -23)
    if (int8_eq_const_40_0 == 0)
    if (int8_eq_const_41_0 == -107)
    if (int8_eq_const_42_0 == -96)
    if (int8_eq_const_43_0 == -2)
    if (int8_eq_const_44_0 == 95)
    if (int8_eq_const_45_0 == -85)
    if (int8_eq_const_46_0 == 60)
    if (int8_eq_const_47_0 == -21)
    if (int8_eq_const_48_0 == -51)
    if (int8_eq_const_49_0 == 17)
    if (int8_eq_const_50_0 == 81)
    if (int8_eq_const_51_0 == 127)
    if (int8_eq_const_52_0 == -60)
    if (int8_eq_const_53_0 == -10)
    if (int8_eq_const_54_0 == 43)
    if (int8_eq_const_55_0 == -37)
    if (int8_eq_const_56_0 == 120)
    if (int8_eq_const_57_0 == -58)
    if (int8_eq_const_58_0 == -50)
    if (int8_eq_const_59_0 == -47)
    if (int8_eq_const_60_0 == 122)
    if (int8_eq_const_61_0 == -89)
    if (int8_eq_const_62_0 == -15)
    if (int8_eq_const_63_0 == -69)
    if (int8_eq_const_64_0 == 31)
    if (int8_eq_const_65_0 == 21)
    if (int8_eq_const_66_0 == -11)
    if (int8_eq_const_67_0 == -105)
    if (int8_eq_const_68_0 == 69)
    if (int8_eq_const_69_0 == 92)
    if (int8_eq_const_70_0 == -124)
    if (int8_eq_const_71_0 == -110)
    if (int8_eq_const_72_0 == 117)
    if (int8_eq_const_73_0 == -5)
    if (int8_eq_const_74_0 == 70)
    if (int8_eq_const_75_0 == 120)
    if (int8_eq_const_76_0 == -72)
    if (int8_eq_const_77_0 == -104)
    if (int8_eq_const_78_0 == -90)
    if (int8_eq_const_79_0 == -39)
    if (int8_eq_const_80_0 == 105)
    if (int8_eq_const_81_0 == -104)
    if (int8_eq_const_82_0 == -13)
    if (int8_eq_const_83_0 == 63)
    if (int8_eq_const_84_0 == 66)
    if (int8_eq_const_85_0 == 26)
    if (int8_eq_const_86_0 == 65)
    if (int8_eq_const_87_0 == 31)
    if (int8_eq_const_88_0 == 90)
    if (int8_eq_const_89_0 == -124)
    if (int8_eq_const_90_0 == 59)
    if (int8_eq_const_91_0 == -72)
    if (int8_eq_const_92_0 == 86)
    if (int8_eq_const_93_0 == -92)
    if (int8_eq_const_94_0 == -19)
    if (int8_eq_const_95_0 == -96)
    if (int8_eq_const_96_0 == 9)
    if (int8_eq_const_97_0 == -61)
    if (int8_eq_const_98_0 == -57)
    if (int8_eq_const_99_0 == 55)
    if (int8_eq_const_100_0 == -11)
    if (int8_eq_const_101_0 == 27)
    if (int8_eq_const_102_0 == 116)
    if (int8_eq_const_103_0 == -53)
    if (int8_eq_const_104_0 == -104)
    if (int8_eq_const_105_0 == 92)
    if (int8_eq_const_106_0 == 28)
    if (int8_eq_const_107_0 == -17)
    if (int8_eq_const_108_0 == 33)
    if (int8_eq_const_109_0 == 50)
    if (int8_eq_const_110_0 == 104)
    if (int8_eq_const_111_0 == -8)
    if (int8_eq_const_112_0 == 101)
    if (int8_eq_const_113_0 == -9)
    if (int8_eq_const_114_0 == 52)
    if (int8_eq_const_115_0 == 112)
    if (int8_eq_const_116_0 == 5)
    if (int8_eq_const_117_0 == 23)
    if (int8_eq_const_118_0 == 49)
    if (int8_eq_const_119_0 == -40)
    if (int8_eq_const_120_0 == -123)
    if (int8_eq_const_121_0 == 1)
    if (int8_eq_const_122_0 == -36)
    if (int8_eq_const_123_0 == -17)
    if (int8_eq_const_124_0 == -38)
    if (int8_eq_const_125_0 == -55)
    if (int8_eq_const_126_0 == 28)
    if (int8_eq_const_127_0 == 84)
    if (int8_eq_const_128_0 == 36)
    if (int8_eq_const_129_0 == 53)
    if (int8_eq_const_130_0 == 118)
    if (int8_eq_const_131_0 == 68)
    if (int8_eq_const_132_0 == -43)
    if (int8_eq_const_133_0 == 20)
    if (int8_eq_const_134_0 == 88)
    if (int8_eq_const_135_0 == -23)
    if (int8_eq_const_136_0 == 30)
    if (int8_eq_const_137_0 == -109)
    if (int8_eq_const_138_0 == 40)
    if (int8_eq_const_139_0 == -83)
    if (int8_eq_const_140_0 == -98)
    if (int8_eq_const_141_0 == 88)
    if (int8_eq_const_142_0 == -35)
    if (int8_eq_const_143_0 == -77)
    if (int8_eq_const_144_0 == -118)
    if (int8_eq_const_145_0 == 24)
    if (int8_eq_const_146_0 == -92)
    if (int8_eq_const_147_0 == -59)
    if (int8_eq_const_148_0 == 35)
    if (int8_eq_const_149_0 == -109)
    if (int8_eq_const_150_0 == -69)
    if (int8_eq_const_151_0 == -76)
    if (int8_eq_const_152_0 == 26)
    if (int8_eq_const_153_0 == -59)
    if (int8_eq_const_154_0 == 16)
    if (int8_eq_const_155_0 == 79)
    if (int8_eq_const_156_0 == -52)
    if (int8_eq_const_157_0 == 100)
    if (int8_eq_const_158_0 == 69)
    if (int8_eq_const_159_0 == 21)
    if (int8_eq_const_160_0 == 116)
    if (int8_eq_const_161_0 == -47)
    if (int8_eq_const_162_0 == -67)
    if (int8_eq_const_163_0 == -87)
    if (int8_eq_const_164_0 == 91)
    if (int8_eq_const_165_0 == -29)
    if (int8_eq_const_166_0 == 14)
    if (int8_eq_const_167_0 == 94)
    if (int8_eq_const_168_0 == -16)
    if (int8_eq_const_169_0 == 8)
    if (int8_eq_const_170_0 == -92)
    if (int8_eq_const_171_0 == 23)
    if (int8_eq_const_172_0 == -12)
    if (int8_eq_const_173_0 == -93)
    if (int8_eq_const_174_0 == -65)
    if (int8_eq_const_175_0 == -20)
    if (int8_eq_const_176_0 == 115)
    if (int8_eq_const_177_0 == -79)
    if (int8_eq_const_178_0 == -16)
    if (int8_eq_const_179_0 == 69)
    if (int8_eq_const_180_0 == 51)
    if (int8_eq_const_181_0 == 33)
    if (int8_eq_const_182_0 == 40)
    if (int8_eq_const_183_0 == 30)
    if (int8_eq_const_184_0 == 47)
    if (int8_eq_const_185_0 == -116)
    if (int8_eq_const_186_0 == -5)
    if (int8_eq_const_187_0 == -106)
    if (int8_eq_const_188_0 == 57)
    if (int8_eq_const_189_0 == 127)
    if (int8_eq_const_190_0 == 35)
    if (int8_eq_const_191_0 == 5)
    if (int8_eq_const_192_0 == -111)
    if (int8_eq_const_193_0 == -73)
    if (int8_eq_const_194_0 == -117)
    if (int8_eq_const_195_0 == 47)
    if (int8_eq_const_196_0 == 9)
    if (int8_eq_const_197_0 == 92)
    if (int8_eq_const_198_0 == 27)
    if (int8_eq_const_199_0 == -116)
    if (int8_eq_const_200_0 == -68)
    if (int8_eq_const_201_0 == -122)
    if (int8_eq_const_202_0 == 50)
    if (int8_eq_const_203_0 == -48)
    if (int8_eq_const_204_0 == -61)
    if (int8_eq_const_205_0 == 2)
    if (int8_eq_const_206_0 == 96)
    if (int8_eq_const_207_0 == 102)
    if (int8_eq_const_208_0 == 42)
    if (int8_eq_const_209_0 == -84)
    if (int8_eq_const_210_0 == 34)
    if (int8_eq_const_211_0 == -17)
    if (int8_eq_const_212_0 == 119)
    if (int8_eq_const_213_0 == 105)
    if (int8_eq_const_214_0 == -109)
    if (int8_eq_const_215_0 == 52)
    if (int8_eq_const_216_0 == 120)
    if (int8_eq_const_217_0 == 58)
    if (int8_eq_const_218_0 == -40)
    if (int8_eq_const_219_0 == -94)
    if (int8_eq_const_220_0 == -89)
    if (int8_eq_const_221_0 == -88)
    if (int8_eq_const_222_0 == -65)
    if (int8_eq_const_223_0 == -80)
    if (int8_eq_const_224_0 == 110)
    if (int8_eq_const_225_0 == 70)
    if (int8_eq_const_226_0 == 101)
    if (int8_eq_const_227_0 == 74)
    if (int8_eq_const_228_0 == -74)
    if (int8_eq_const_229_0 == -37)
    if (int8_eq_const_230_0 == 17)
    if (int8_eq_const_231_0 == -38)
    if (int8_eq_const_232_0 == -69)
    if (int8_eq_const_233_0 == 87)
    if (int8_eq_const_234_0 == 76)
    if (int8_eq_const_235_0 == 18)
    if (int8_eq_const_236_0 == -41)
    if (int8_eq_const_237_0 == -96)
    if (int8_eq_const_238_0 == 41)
    if (int8_eq_const_239_0 == 105)
    if (int8_eq_const_240_0 == 5)
    if (int8_eq_const_241_0 == -45)
    if (int8_eq_const_242_0 == 37)
    if (int8_eq_const_243_0 == -83)
    if (int8_eq_const_244_0 == 59)
    if (int8_eq_const_245_0 == -93)
    if (int8_eq_const_246_0 == 113)
    if (int8_eq_const_247_0 == -5)
    if (int8_eq_const_248_0 == 59)
    if (int8_eq_const_249_0 == 20)
    if (int8_eq_const_250_0 == -115)
    if (int8_eq_const_251_0 == -17)
    if (int8_eq_const_252_0 == -113)
    if (int8_eq_const_253_0 == -19)
    if (int8_eq_const_254_0 == 14)
    if (int8_eq_const_255_0 == -47)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
