#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;

    if (size < 96)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 6877418189800339820u)
    if (uint64_eq_const_1_0 == 11923100048074072956u)
    if (uint64_eq_const_2_0 == 15496947798480398857u)
    if (uint64_eq_const_3_0 == 1786721879601088065u)
    if (uint64_eq_const_4_0 == 16847678822009855474u)
    if (uint64_eq_const_5_0 == 11315647988588554559u)
    if (uint64_eq_const_6_0 == 10815595164458144259u)
    if (uint64_eq_const_7_0 == 2971056645043808722u)
    if (uint64_eq_const_8_0 == 18441124401149947645u)
    if (uint64_eq_const_9_0 == 10873885223616480779u)
    if (uint64_eq_const_10_0 == 14373752775464328312u)
    if (uint64_eq_const_11_0 == 9545811490842520261u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
