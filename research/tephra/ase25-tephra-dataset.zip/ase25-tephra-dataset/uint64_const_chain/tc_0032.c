#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;
    uint64_t uint64_eq_const_14_0;
    uint64_t uint64_eq_const_15_0;
    uint64_t uint64_eq_const_16_0;
    uint64_t uint64_eq_const_17_0;
    uint64_t uint64_eq_const_18_0;
    uint64_t uint64_eq_const_19_0;
    uint64_t uint64_eq_const_20_0;
    uint64_t uint64_eq_const_21_0;
    uint64_t uint64_eq_const_22_0;
    uint64_t uint64_eq_const_23_0;
    uint64_t uint64_eq_const_24_0;
    uint64_t uint64_eq_const_25_0;
    uint64_t uint64_eq_const_26_0;
    uint64_t uint64_eq_const_27_0;
    uint64_t uint64_eq_const_28_0;
    uint64_t uint64_eq_const_29_0;
    uint64_t uint64_eq_const_30_0;
    uint64_t uint64_eq_const_31_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_31_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 15183947243734064064u)
    if (uint64_eq_const_1_0 == 13155457534698159647u)
    if (uint64_eq_const_2_0 == 17508447541568268047u)
    if (uint64_eq_const_3_0 == 479460637779489754u)
    if (uint64_eq_const_4_0 == 9218863350641848279u)
    if (uint64_eq_const_5_0 == 13671513309613443889u)
    if (uint64_eq_const_6_0 == 7036818109472965504u)
    if (uint64_eq_const_7_0 == 11291276654408017951u)
    if (uint64_eq_const_8_0 == 11973548846425753505u)
    if (uint64_eq_const_9_0 == 12814423487676336352u)
    if (uint64_eq_const_10_0 == 15036587905912113518u)
    if (uint64_eq_const_11_0 == 7202613045196186750u)
    if (uint64_eq_const_12_0 == 16944900319269146735u)
    if (uint64_eq_const_13_0 == 7101267524959919786u)
    if (uint64_eq_const_14_0 == 5111700023705331827u)
    if (uint64_eq_const_15_0 == 11871480890019865807u)
    if (uint64_eq_const_16_0 == 15783808548894316227u)
    if (uint64_eq_const_17_0 == 1138294766267123812u)
    if (uint64_eq_const_18_0 == 3255131464396336793u)
    if (uint64_eq_const_19_0 == 13253305497085323905u)
    if (uint64_eq_const_20_0 == 2605222688830552274u)
    if (uint64_eq_const_21_0 == 14302437227081911477u)
    if (uint64_eq_const_22_0 == 14197543228957467363u)
    if (uint64_eq_const_23_0 == 11231286857945815830u)
    if (uint64_eq_const_24_0 == 17205110616067647753u)
    if (uint64_eq_const_25_0 == 11365908761599820696u)
    if (uint64_eq_const_26_0 == 12691905219245338564u)
    if (uint64_eq_const_27_0 == 9827873265809288866u)
    if (uint64_eq_const_28_0 == 15556228452945559685u)
    if (uint64_eq_const_29_0 == 17219389604024020190u)
    if (uint64_eq_const_30_0 == 3262986122606386597u)
    if (uint64_eq_const_31_0 == 11535899795264925264u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
