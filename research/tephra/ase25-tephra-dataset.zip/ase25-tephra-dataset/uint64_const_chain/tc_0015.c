#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;
    uint64_t uint64_eq_const_14_0;

    if (size < 120)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_14_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 11113824363876932241u)
    if (uint64_eq_const_1_0 == 13910705920706962179u)
    if (uint64_eq_const_2_0 == 11463402600278423777u)
    if (uint64_eq_const_3_0 == 15773676472365371990u)
    if (uint64_eq_const_4_0 == 350557125579769306u)
    if (uint64_eq_const_5_0 == 13475470574796254948u)
    if (uint64_eq_const_6_0 == 4039219840176353340u)
    if (uint64_eq_const_7_0 == 15464471916974276011u)
    if (uint64_eq_const_8_0 == 2610497026406850589u)
    if (uint64_eq_const_9_0 == 7898681562881700474u)
    if (uint64_eq_const_10_0 == 2359676772999738037u)
    if (uint64_eq_const_11_0 == 9875455035261223400u)
    if (uint64_eq_const_12_0 == 4877360414496464758u)
    if (uint64_eq_const_13_0 == 5167840787859070600u)
    if (uint64_eq_const_14_0 == 13207157740010674784u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
