#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;
    uint64_t uint64_eq_const_14_0;
    uint64_t uint64_eq_const_15_0;
    uint64_t uint64_eq_const_16_0;
    uint64_t uint64_eq_const_17_0;
    uint64_t uint64_eq_const_18_0;
    uint64_t uint64_eq_const_19_0;
    uint64_t uint64_eq_const_20_0;
    uint64_t uint64_eq_const_21_0;
    uint64_t uint64_eq_const_22_0;
    uint64_t uint64_eq_const_23_0;
    uint64_t uint64_eq_const_24_0;
    uint64_t uint64_eq_const_25_0;
    uint64_t uint64_eq_const_26_0;
    uint64_t uint64_eq_const_27_0;
    uint64_t uint64_eq_const_28_0;
    uint64_t uint64_eq_const_29_0;
    uint64_t uint64_eq_const_30_0;
    uint64_t uint64_eq_const_31_0;
    uint64_t uint64_eq_const_32_0;
    uint64_t uint64_eq_const_33_0;
    uint64_t uint64_eq_const_34_0;
    uint64_t uint64_eq_const_35_0;
    uint64_t uint64_eq_const_36_0;
    uint64_t uint64_eq_const_37_0;
    uint64_t uint64_eq_const_38_0;
    uint64_t uint64_eq_const_39_0;
    uint64_t uint64_eq_const_40_0;
    uint64_t uint64_eq_const_41_0;
    uint64_t uint64_eq_const_42_0;
    uint64_t uint64_eq_const_43_0;
    uint64_t uint64_eq_const_44_0;
    uint64_t uint64_eq_const_45_0;
    uint64_t uint64_eq_const_46_0;
    uint64_t uint64_eq_const_47_0;
    uint64_t uint64_eq_const_48_0;
    uint64_t uint64_eq_const_49_0;
    uint64_t uint64_eq_const_50_0;
    uint64_t uint64_eq_const_51_0;
    uint64_t uint64_eq_const_52_0;
    uint64_t uint64_eq_const_53_0;
    uint64_t uint64_eq_const_54_0;
    uint64_t uint64_eq_const_55_0;
    uint64_t uint64_eq_const_56_0;
    uint64_t uint64_eq_const_57_0;
    uint64_t uint64_eq_const_58_0;
    uint64_t uint64_eq_const_59_0;
    uint64_t uint64_eq_const_60_0;
    uint64_t uint64_eq_const_61_0;
    uint64_t uint64_eq_const_62_0;
    uint64_t uint64_eq_const_63_0;
    uint64_t uint64_eq_const_64_0;
    uint64_t uint64_eq_const_65_0;
    uint64_t uint64_eq_const_66_0;
    uint64_t uint64_eq_const_67_0;
    uint64_t uint64_eq_const_68_0;
    uint64_t uint64_eq_const_69_0;
    uint64_t uint64_eq_const_70_0;
    uint64_t uint64_eq_const_71_0;
    uint64_t uint64_eq_const_72_0;
    uint64_t uint64_eq_const_73_0;
    uint64_t uint64_eq_const_74_0;
    uint64_t uint64_eq_const_75_0;
    uint64_t uint64_eq_const_76_0;
    uint64_t uint64_eq_const_77_0;
    uint64_t uint64_eq_const_78_0;
    uint64_t uint64_eq_const_79_0;
    uint64_t uint64_eq_const_80_0;
    uint64_t uint64_eq_const_81_0;
    uint64_t uint64_eq_const_82_0;
    uint64_t uint64_eq_const_83_0;
    uint64_t uint64_eq_const_84_0;
    uint64_t uint64_eq_const_85_0;
    uint64_t uint64_eq_const_86_0;
    uint64_t uint64_eq_const_87_0;
    uint64_t uint64_eq_const_88_0;
    uint64_t uint64_eq_const_89_0;
    uint64_t uint64_eq_const_90_0;
    uint64_t uint64_eq_const_91_0;
    uint64_t uint64_eq_const_92_0;
    uint64_t uint64_eq_const_93_0;
    uint64_t uint64_eq_const_94_0;
    uint64_t uint64_eq_const_95_0;
    uint64_t uint64_eq_const_96_0;
    uint64_t uint64_eq_const_97_0;
    uint64_t uint64_eq_const_98_0;
    uint64_t uint64_eq_const_99_0;
    uint64_t uint64_eq_const_100_0;
    uint64_t uint64_eq_const_101_0;
    uint64_t uint64_eq_const_102_0;
    uint64_t uint64_eq_const_103_0;
    uint64_t uint64_eq_const_104_0;
    uint64_t uint64_eq_const_105_0;
    uint64_t uint64_eq_const_106_0;
    uint64_t uint64_eq_const_107_0;
    uint64_t uint64_eq_const_108_0;
    uint64_t uint64_eq_const_109_0;
    uint64_t uint64_eq_const_110_0;
    uint64_t uint64_eq_const_111_0;
    uint64_t uint64_eq_const_112_0;
    uint64_t uint64_eq_const_113_0;
    uint64_t uint64_eq_const_114_0;
    uint64_t uint64_eq_const_115_0;
    uint64_t uint64_eq_const_116_0;
    uint64_t uint64_eq_const_117_0;
    uint64_t uint64_eq_const_118_0;
    uint64_t uint64_eq_const_119_0;
    uint64_t uint64_eq_const_120_0;
    uint64_t uint64_eq_const_121_0;
    uint64_t uint64_eq_const_122_0;
    uint64_t uint64_eq_const_123_0;
    uint64_t uint64_eq_const_124_0;
    uint64_t uint64_eq_const_125_0;
    uint64_t uint64_eq_const_126_0;
    uint64_t uint64_eq_const_127_0;

    if (size < 1024)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_31_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_34_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_38_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_45_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_49_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_52_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_55_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_60_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_63_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_64_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_65_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_66_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_67_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_68_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_69_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_70_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_71_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_73_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_74_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_75_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_76_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_77_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_78_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_79_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_80_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_81_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_82_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_83_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_84_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_86_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_87_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_88_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_89_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_91_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_92_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_93_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_94_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_95_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_96_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_97_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_98_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_99_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_100_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_101_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_102_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_103_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_104_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_105_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_106_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_107_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_108_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_109_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_110_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_111_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_112_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_113_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_114_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_115_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_116_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_117_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_118_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_119_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_120_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_121_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_122_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_123_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_124_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_125_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_126_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_127_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 13648849254084609489u)
    if (uint64_eq_const_1_0 == 13993406366285878566u)
    if (uint64_eq_const_2_0 == 14921327646014868283u)
    if (uint64_eq_const_3_0 == 15169383163851827351u)
    if (uint64_eq_const_4_0 == 3936747731642799049u)
    if (uint64_eq_const_5_0 == 6745724767472395924u)
    if (uint64_eq_const_6_0 == 3644583864302109664u)
    if (uint64_eq_const_7_0 == 15681691731300677751u)
    if (uint64_eq_const_8_0 == 7858529409537264595u)
    if (uint64_eq_const_9_0 == 9308725723347016597u)
    if (uint64_eq_const_10_0 == 6316249970412352338u)
    if (uint64_eq_const_11_0 == 14877121117988756439u)
    if (uint64_eq_const_12_0 == 9755682270019266592u)
    if (uint64_eq_const_13_0 == 8225277073744929673u)
    if (uint64_eq_const_14_0 == 1147793831973913608u)
    if (uint64_eq_const_15_0 == 13149442847024510065u)
    if (uint64_eq_const_16_0 == 1875718906817216017u)
    if (uint64_eq_const_17_0 == 5049462344507039267u)
    if (uint64_eq_const_18_0 == 1577641434629880560u)
    if (uint64_eq_const_19_0 == 951782719774049683u)
    if (uint64_eq_const_20_0 == 3389167489355575485u)
    if (uint64_eq_const_21_0 == 17656847345741894123u)
    if (uint64_eq_const_22_0 == 9815478543128941034u)
    if (uint64_eq_const_23_0 == 35669745969730207u)
    if (uint64_eq_const_24_0 == 4872287935551976304u)
    if (uint64_eq_const_25_0 == 8465705197482701501u)
    if (uint64_eq_const_26_0 == 4155122922984366666u)
    if (uint64_eq_const_27_0 == 4032539923540675977u)
    if (uint64_eq_const_28_0 == 5218025223227694118u)
    if (uint64_eq_const_29_0 == 17450867078242220105u)
    if (uint64_eq_const_30_0 == 7051592165429731162u)
    if (uint64_eq_const_31_0 == 11240408270956680540u)
    if (uint64_eq_const_32_0 == 9349056575012603412u)
    if (uint64_eq_const_33_0 == 1501362012121466001u)
    if (uint64_eq_const_34_0 == 14939369393026097365u)
    if (uint64_eq_const_35_0 == 16075535890723734709u)
    if (uint64_eq_const_36_0 == 13651510324519978016u)
    if (uint64_eq_const_37_0 == 5933605664176183917u)
    if (uint64_eq_const_38_0 == 10914667915234033006u)
    if (uint64_eq_const_39_0 == 7107955109098852422u)
    if (uint64_eq_const_40_0 == 12983477875878519652u)
    if (uint64_eq_const_41_0 == 2285481792875602954u)
    if (uint64_eq_const_42_0 == 7315422521084867911u)
    if (uint64_eq_const_43_0 == 7944399753838490965u)
    if (uint64_eq_const_44_0 == 10672526054511246767u)
    if (uint64_eq_const_45_0 == 17950874803953715559u)
    if (uint64_eq_const_46_0 == 17692737539474386042u)
    if (uint64_eq_const_47_0 == 10899264005144197178u)
    if (uint64_eq_const_48_0 == 11781509984233937923u)
    if (uint64_eq_const_49_0 == 3361181346293716694u)
    if (uint64_eq_const_50_0 == 18229855589122176404u)
    if (uint64_eq_const_51_0 == 11826700335607657188u)
    if (uint64_eq_const_52_0 == 11645342482334066968u)
    if (uint64_eq_const_53_0 == 8986768547842372481u)
    if (uint64_eq_const_54_0 == 13734727312160074772u)
    if (uint64_eq_const_55_0 == 3296267993844331349u)
    if (uint64_eq_const_56_0 == 922762361457898456u)
    if (uint64_eq_const_57_0 == 10391005483312736227u)
    if (uint64_eq_const_58_0 == 14655543734469140209u)
    if (uint64_eq_const_59_0 == 13752743911460366881u)
    if (uint64_eq_const_60_0 == 13613305193207005665u)
    if (uint64_eq_const_61_0 == 13309552066638967883u)
    if (uint64_eq_const_62_0 == 18375831841152125713u)
    if (uint64_eq_const_63_0 == 4049906418595997939u)
    if (uint64_eq_const_64_0 == 5852943004972216838u)
    if (uint64_eq_const_65_0 == 3860866649081722717u)
    if (uint64_eq_const_66_0 == 11106217637513553363u)
    if (uint64_eq_const_67_0 == 14847361461052338441u)
    if (uint64_eq_const_68_0 == 14520356816273583822u)
    if (uint64_eq_const_69_0 == 13591062719550989456u)
    if (uint64_eq_const_70_0 == 8725588223098386310u)
    if (uint64_eq_const_71_0 == 732070530378322355u)
    if (uint64_eq_const_72_0 == 4768622909451972852u)
    if (uint64_eq_const_73_0 == 1404533320535182000u)
    if (uint64_eq_const_74_0 == 14574205443665217007u)
    if (uint64_eq_const_75_0 == 15814462604751410904u)
    if (uint64_eq_const_76_0 == 3700718869753958885u)
    if (uint64_eq_const_77_0 == 15522084762472917597u)
    if (uint64_eq_const_78_0 == 5974173275977912008u)
    if (uint64_eq_const_79_0 == 16352665892146005872u)
    if (uint64_eq_const_80_0 == 14079389803833257541u)
    if (uint64_eq_const_81_0 == 15600696974944181387u)
    if (uint64_eq_const_82_0 == 5065752056870965819u)
    if (uint64_eq_const_83_0 == 15807212625571771403u)
    if (uint64_eq_const_84_0 == 13060208023093188714u)
    if (uint64_eq_const_85_0 == 13901106176900663553u)
    if (uint64_eq_const_86_0 == 17188321711218388331u)
    if (uint64_eq_const_87_0 == 3472121405219493192u)
    if (uint64_eq_const_88_0 == 4301594584675359455u)
    if (uint64_eq_const_89_0 == 1854238567103016154u)
    if (uint64_eq_const_90_0 == 16946038324530889963u)
    if (uint64_eq_const_91_0 == 10767910661658196575u)
    if (uint64_eq_const_92_0 == 9389697861272013539u)
    if (uint64_eq_const_93_0 == 2454153777283674374u)
    if (uint64_eq_const_94_0 == 10795295498566319940u)
    if (uint64_eq_const_95_0 == 13367867944654915480u)
    if (uint64_eq_const_96_0 == 979110733448194792u)
    if (uint64_eq_const_97_0 == 6265465961812250826u)
    if (uint64_eq_const_98_0 == 3536083311426228084u)
    if (uint64_eq_const_99_0 == 17826821226852582610u)
    if (uint64_eq_const_100_0 == 3158733404199476500u)
    if (uint64_eq_const_101_0 == 18234392157974057020u)
    if (uint64_eq_const_102_0 == 16331299988540673898u)
    if (uint64_eq_const_103_0 == 5067095012106091517u)
    if (uint64_eq_const_104_0 == 10415194154439370179u)
    if (uint64_eq_const_105_0 == 8579760895967707848u)
    if (uint64_eq_const_106_0 == 2118882012016765579u)
    if (uint64_eq_const_107_0 == 9386944719714199456u)
    if (uint64_eq_const_108_0 == 15879228829779820035u)
    if (uint64_eq_const_109_0 == 13147673228153299374u)
    if (uint64_eq_const_110_0 == 920570874060527664u)
    if (uint64_eq_const_111_0 == 10282097507047043412u)
    if (uint64_eq_const_112_0 == 4907027175167604246u)
    if (uint64_eq_const_113_0 == 11386172274100482689u)
    if (uint64_eq_const_114_0 == 14319172494638245414u)
    if (uint64_eq_const_115_0 == 14068279976273018950u)
    if (uint64_eq_const_116_0 == 13909466694306146292u)
    if (uint64_eq_const_117_0 == 13844695807701761449u)
    if (uint64_eq_const_118_0 == 9666525134390317868u)
    if (uint64_eq_const_119_0 == 9837149041699624889u)
    if (uint64_eq_const_120_0 == 3872031694245034438u)
    if (uint64_eq_const_121_0 == 9007974879402038498u)
    if (uint64_eq_const_122_0 == 17557092496717019512u)
    if (uint64_eq_const_123_0 == 660775550440850818u)
    if (uint64_eq_const_124_0 == 13414023258867773548u)
    if (uint64_eq_const_125_0 == 2814452592907774395u)
    if (uint64_eq_const_126_0 == 10283643240430553395u)
    if (uint64_eq_const_127_0 == 7038912843873853578u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
