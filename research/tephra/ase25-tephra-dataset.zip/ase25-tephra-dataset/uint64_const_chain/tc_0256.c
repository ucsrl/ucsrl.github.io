#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;
    uint64_t uint64_eq_const_14_0;
    uint64_t uint64_eq_const_15_0;
    uint64_t uint64_eq_const_16_0;
    uint64_t uint64_eq_const_17_0;
    uint64_t uint64_eq_const_18_0;
    uint64_t uint64_eq_const_19_0;
    uint64_t uint64_eq_const_20_0;
    uint64_t uint64_eq_const_21_0;
    uint64_t uint64_eq_const_22_0;
    uint64_t uint64_eq_const_23_0;
    uint64_t uint64_eq_const_24_0;
    uint64_t uint64_eq_const_25_0;
    uint64_t uint64_eq_const_26_0;
    uint64_t uint64_eq_const_27_0;
    uint64_t uint64_eq_const_28_0;
    uint64_t uint64_eq_const_29_0;
    uint64_t uint64_eq_const_30_0;
    uint64_t uint64_eq_const_31_0;
    uint64_t uint64_eq_const_32_0;
    uint64_t uint64_eq_const_33_0;
    uint64_t uint64_eq_const_34_0;
    uint64_t uint64_eq_const_35_0;
    uint64_t uint64_eq_const_36_0;
    uint64_t uint64_eq_const_37_0;
    uint64_t uint64_eq_const_38_0;
    uint64_t uint64_eq_const_39_0;
    uint64_t uint64_eq_const_40_0;
    uint64_t uint64_eq_const_41_0;
    uint64_t uint64_eq_const_42_0;
    uint64_t uint64_eq_const_43_0;
    uint64_t uint64_eq_const_44_0;
    uint64_t uint64_eq_const_45_0;
    uint64_t uint64_eq_const_46_0;
    uint64_t uint64_eq_const_47_0;
    uint64_t uint64_eq_const_48_0;
    uint64_t uint64_eq_const_49_0;
    uint64_t uint64_eq_const_50_0;
    uint64_t uint64_eq_const_51_0;
    uint64_t uint64_eq_const_52_0;
    uint64_t uint64_eq_const_53_0;
    uint64_t uint64_eq_const_54_0;
    uint64_t uint64_eq_const_55_0;
    uint64_t uint64_eq_const_56_0;
    uint64_t uint64_eq_const_57_0;
    uint64_t uint64_eq_const_58_0;
    uint64_t uint64_eq_const_59_0;
    uint64_t uint64_eq_const_60_0;
    uint64_t uint64_eq_const_61_0;
    uint64_t uint64_eq_const_62_0;
    uint64_t uint64_eq_const_63_0;
    uint64_t uint64_eq_const_64_0;
    uint64_t uint64_eq_const_65_0;
    uint64_t uint64_eq_const_66_0;
    uint64_t uint64_eq_const_67_0;
    uint64_t uint64_eq_const_68_0;
    uint64_t uint64_eq_const_69_0;
    uint64_t uint64_eq_const_70_0;
    uint64_t uint64_eq_const_71_0;
    uint64_t uint64_eq_const_72_0;
    uint64_t uint64_eq_const_73_0;
    uint64_t uint64_eq_const_74_0;
    uint64_t uint64_eq_const_75_0;
    uint64_t uint64_eq_const_76_0;
    uint64_t uint64_eq_const_77_0;
    uint64_t uint64_eq_const_78_0;
    uint64_t uint64_eq_const_79_0;
    uint64_t uint64_eq_const_80_0;
    uint64_t uint64_eq_const_81_0;
    uint64_t uint64_eq_const_82_0;
    uint64_t uint64_eq_const_83_0;
    uint64_t uint64_eq_const_84_0;
    uint64_t uint64_eq_const_85_0;
    uint64_t uint64_eq_const_86_0;
    uint64_t uint64_eq_const_87_0;
    uint64_t uint64_eq_const_88_0;
    uint64_t uint64_eq_const_89_0;
    uint64_t uint64_eq_const_90_0;
    uint64_t uint64_eq_const_91_0;
    uint64_t uint64_eq_const_92_0;
    uint64_t uint64_eq_const_93_0;
    uint64_t uint64_eq_const_94_0;
    uint64_t uint64_eq_const_95_0;
    uint64_t uint64_eq_const_96_0;
    uint64_t uint64_eq_const_97_0;
    uint64_t uint64_eq_const_98_0;
    uint64_t uint64_eq_const_99_0;
    uint64_t uint64_eq_const_100_0;
    uint64_t uint64_eq_const_101_0;
    uint64_t uint64_eq_const_102_0;
    uint64_t uint64_eq_const_103_0;
    uint64_t uint64_eq_const_104_0;
    uint64_t uint64_eq_const_105_0;
    uint64_t uint64_eq_const_106_0;
    uint64_t uint64_eq_const_107_0;
    uint64_t uint64_eq_const_108_0;
    uint64_t uint64_eq_const_109_0;
    uint64_t uint64_eq_const_110_0;
    uint64_t uint64_eq_const_111_0;
    uint64_t uint64_eq_const_112_0;
    uint64_t uint64_eq_const_113_0;
    uint64_t uint64_eq_const_114_0;
    uint64_t uint64_eq_const_115_0;
    uint64_t uint64_eq_const_116_0;
    uint64_t uint64_eq_const_117_0;
    uint64_t uint64_eq_const_118_0;
    uint64_t uint64_eq_const_119_0;
    uint64_t uint64_eq_const_120_0;
    uint64_t uint64_eq_const_121_0;
    uint64_t uint64_eq_const_122_0;
    uint64_t uint64_eq_const_123_0;
    uint64_t uint64_eq_const_124_0;
    uint64_t uint64_eq_const_125_0;
    uint64_t uint64_eq_const_126_0;
    uint64_t uint64_eq_const_127_0;
    uint64_t uint64_eq_const_128_0;
    uint64_t uint64_eq_const_129_0;
    uint64_t uint64_eq_const_130_0;
    uint64_t uint64_eq_const_131_0;
    uint64_t uint64_eq_const_132_0;
    uint64_t uint64_eq_const_133_0;
    uint64_t uint64_eq_const_134_0;
    uint64_t uint64_eq_const_135_0;
    uint64_t uint64_eq_const_136_0;
    uint64_t uint64_eq_const_137_0;
    uint64_t uint64_eq_const_138_0;
    uint64_t uint64_eq_const_139_0;
    uint64_t uint64_eq_const_140_0;
    uint64_t uint64_eq_const_141_0;
    uint64_t uint64_eq_const_142_0;
    uint64_t uint64_eq_const_143_0;
    uint64_t uint64_eq_const_144_0;
    uint64_t uint64_eq_const_145_0;
    uint64_t uint64_eq_const_146_0;
    uint64_t uint64_eq_const_147_0;
    uint64_t uint64_eq_const_148_0;
    uint64_t uint64_eq_const_149_0;
    uint64_t uint64_eq_const_150_0;
    uint64_t uint64_eq_const_151_0;
    uint64_t uint64_eq_const_152_0;
    uint64_t uint64_eq_const_153_0;
    uint64_t uint64_eq_const_154_0;
    uint64_t uint64_eq_const_155_0;
    uint64_t uint64_eq_const_156_0;
    uint64_t uint64_eq_const_157_0;
    uint64_t uint64_eq_const_158_0;
    uint64_t uint64_eq_const_159_0;
    uint64_t uint64_eq_const_160_0;
    uint64_t uint64_eq_const_161_0;
    uint64_t uint64_eq_const_162_0;
    uint64_t uint64_eq_const_163_0;
    uint64_t uint64_eq_const_164_0;
    uint64_t uint64_eq_const_165_0;
    uint64_t uint64_eq_const_166_0;
    uint64_t uint64_eq_const_167_0;
    uint64_t uint64_eq_const_168_0;
    uint64_t uint64_eq_const_169_0;
    uint64_t uint64_eq_const_170_0;
    uint64_t uint64_eq_const_171_0;
    uint64_t uint64_eq_const_172_0;
    uint64_t uint64_eq_const_173_0;
    uint64_t uint64_eq_const_174_0;
    uint64_t uint64_eq_const_175_0;
    uint64_t uint64_eq_const_176_0;
    uint64_t uint64_eq_const_177_0;
    uint64_t uint64_eq_const_178_0;
    uint64_t uint64_eq_const_179_0;
    uint64_t uint64_eq_const_180_0;
    uint64_t uint64_eq_const_181_0;
    uint64_t uint64_eq_const_182_0;
    uint64_t uint64_eq_const_183_0;
    uint64_t uint64_eq_const_184_0;
    uint64_t uint64_eq_const_185_0;
    uint64_t uint64_eq_const_186_0;
    uint64_t uint64_eq_const_187_0;
    uint64_t uint64_eq_const_188_0;
    uint64_t uint64_eq_const_189_0;
    uint64_t uint64_eq_const_190_0;
    uint64_t uint64_eq_const_191_0;
    uint64_t uint64_eq_const_192_0;
    uint64_t uint64_eq_const_193_0;
    uint64_t uint64_eq_const_194_0;
    uint64_t uint64_eq_const_195_0;
    uint64_t uint64_eq_const_196_0;
    uint64_t uint64_eq_const_197_0;
    uint64_t uint64_eq_const_198_0;
    uint64_t uint64_eq_const_199_0;
    uint64_t uint64_eq_const_200_0;
    uint64_t uint64_eq_const_201_0;
    uint64_t uint64_eq_const_202_0;
    uint64_t uint64_eq_const_203_0;
    uint64_t uint64_eq_const_204_0;
    uint64_t uint64_eq_const_205_0;
    uint64_t uint64_eq_const_206_0;
    uint64_t uint64_eq_const_207_0;
    uint64_t uint64_eq_const_208_0;
    uint64_t uint64_eq_const_209_0;
    uint64_t uint64_eq_const_210_0;
    uint64_t uint64_eq_const_211_0;
    uint64_t uint64_eq_const_212_0;
    uint64_t uint64_eq_const_213_0;
    uint64_t uint64_eq_const_214_0;
    uint64_t uint64_eq_const_215_0;
    uint64_t uint64_eq_const_216_0;
    uint64_t uint64_eq_const_217_0;
    uint64_t uint64_eq_const_218_0;
    uint64_t uint64_eq_const_219_0;
    uint64_t uint64_eq_const_220_0;
    uint64_t uint64_eq_const_221_0;
    uint64_t uint64_eq_const_222_0;
    uint64_t uint64_eq_const_223_0;
    uint64_t uint64_eq_const_224_0;
    uint64_t uint64_eq_const_225_0;
    uint64_t uint64_eq_const_226_0;
    uint64_t uint64_eq_const_227_0;
    uint64_t uint64_eq_const_228_0;
    uint64_t uint64_eq_const_229_0;
    uint64_t uint64_eq_const_230_0;
    uint64_t uint64_eq_const_231_0;
    uint64_t uint64_eq_const_232_0;
    uint64_t uint64_eq_const_233_0;
    uint64_t uint64_eq_const_234_0;
    uint64_t uint64_eq_const_235_0;
    uint64_t uint64_eq_const_236_0;
    uint64_t uint64_eq_const_237_0;
    uint64_t uint64_eq_const_238_0;
    uint64_t uint64_eq_const_239_0;
    uint64_t uint64_eq_const_240_0;
    uint64_t uint64_eq_const_241_0;
    uint64_t uint64_eq_const_242_0;
    uint64_t uint64_eq_const_243_0;
    uint64_t uint64_eq_const_244_0;
    uint64_t uint64_eq_const_245_0;
    uint64_t uint64_eq_const_246_0;
    uint64_t uint64_eq_const_247_0;
    uint64_t uint64_eq_const_248_0;
    uint64_t uint64_eq_const_249_0;
    uint64_t uint64_eq_const_250_0;
    uint64_t uint64_eq_const_251_0;
    uint64_t uint64_eq_const_252_0;
    uint64_t uint64_eq_const_253_0;
    uint64_t uint64_eq_const_254_0;
    uint64_t uint64_eq_const_255_0;

    if (size < 2048)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_31_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_34_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_38_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_45_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_49_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_52_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_55_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_60_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_63_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_64_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_65_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_66_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_67_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_68_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_69_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_70_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_71_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_73_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_74_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_75_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_76_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_77_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_78_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_79_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_80_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_81_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_82_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_83_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_84_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_86_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_87_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_88_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_89_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_91_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_92_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_93_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_94_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_95_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_96_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_97_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_98_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_99_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_100_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_101_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_102_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_103_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_104_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_105_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_106_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_107_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_108_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_109_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_110_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_111_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_112_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_113_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_114_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_115_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_116_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_117_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_118_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_119_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_120_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_121_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_122_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_123_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_124_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_125_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_126_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_127_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_128_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_129_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_130_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_131_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_132_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_133_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_134_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_135_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_136_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_137_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_138_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_139_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_140_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_141_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_142_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_143_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_144_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_145_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_146_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_147_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_148_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_149_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_150_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_151_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_152_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_153_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_154_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_155_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_156_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_157_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_158_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_159_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_160_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_161_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_162_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_163_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_164_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_165_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_166_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_167_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_168_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_169_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_170_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_171_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_172_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_173_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_174_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_175_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_176_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_177_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_178_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_179_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_180_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_181_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_182_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_183_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_184_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_185_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_186_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_187_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_188_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_189_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_190_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_191_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_192_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_193_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_194_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_195_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_196_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_197_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_198_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_199_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_200_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_201_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_202_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_203_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_204_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_205_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_206_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_207_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_208_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_209_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_210_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_211_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_212_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_213_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_214_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_215_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_216_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_217_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_218_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_219_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_220_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_221_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_222_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_223_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_224_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_225_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_226_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_227_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_228_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_229_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_230_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_231_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_232_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_233_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_234_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_235_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_236_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_237_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_238_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_239_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_240_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_241_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_242_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_243_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_244_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_245_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_246_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_247_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_248_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_249_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_250_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_251_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_252_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_253_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_254_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_255_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 229108740804658691u)
    if (uint64_eq_const_1_0 == 9484284758769696220u)
    if (uint64_eq_const_2_0 == 5429535350377724520u)
    if (uint64_eq_const_3_0 == 17444031565585639297u)
    if (uint64_eq_const_4_0 == 1410336233247827030u)
    if (uint64_eq_const_5_0 == 10522813902156585247u)
    if (uint64_eq_const_6_0 == 5063244654720747907u)
    if (uint64_eq_const_7_0 == 11980342520503567839u)
    if (uint64_eq_const_8_0 == 18036332288659177616u)
    if (uint64_eq_const_9_0 == 10695654728772289000u)
    if (uint64_eq_const_10_0 == 16292607864815930494u)
    if (uint64_eq_const_11_0 == 9700200194402241778u)
    if (uint64_eq_const_12_0 == 6021213678741470049u)
    if (uint64_eq_const_13_0 == 1838078094470672921u)
    if (uint64_eq_const_14_0 == 4059298655495109714u)
    if (uint64_eq_const_15_0 == 12863041193089257715u)
    if (uint64_eq_const_16_0 == 17011383818482835625u)
    if (uint64_eq_const_17_0 == 13942838434865472484u)
    if (uint64_eq_const_18_0 == 4317146854130203756u)
    if (uint64_eq_const_19_0 == 11673515430500833200u)
    if (uint64_eq_const_20_0 == 10967086985574029825u)
    if (uint64_eq_const_21_0 == 11046239574069446737u)
    if (uint64_eq_const_22_0 == 10653512571152971051u)
    if (uint64_eq_const_23_0 == 593674083644061450u)
    if (uint64_eq_const_24_0 == 200186894141993267u)
    if (uint64_eq_const_25_0 == 16973298843353583035u)
    if (uint64_eq_const_26_0 == 3504212306406129253u)
    if (uint64_eq_const_27_0 == 3543169728241091447u)
    if (uint64_eq_const_28_0 == 9877611712773694142u)
    if (uint64_eq_const_29_0 == 16142060338338690643u)
    if (uint64_eq_const_30_0 == 12736758177949161954u)
    if (uint64_eq_const_31_0 == 1667051595881090688u)
    if (uint64_eq_const_32_0 == 641943988258914387u)
    if (uint64_eq_const_33_0 == 3163339065842122396u)
    if (uint64_eq_const_34_0 == 4378745352313994720u)
    if (uint64_eq_const_35_0 == 13477383061010593092u)
    if (uint64_eq_const_36_0 == 2205123011584533338u)
    if (uint64_eq_const_37_0 == 579063433168049133u)
    if (uint64_eq_const_38_0 == 6881462224130322318u)
    if (uint64_eq_const_39_0 == 2317437615941353204u)
    if (uint64_eq_const_40_0 == 12730495832917929838u)
    if (uint64_eq_const_41_0 == 11242004956810337010u)
    if (uint64_eq_const_42_0 == 9477170233065041297u)
    if (uint64_eq_const_43_0 == 12311676647377832789u)
    if (uint64_eq_const_44_0 == 14928766464593323229u)
    if (uint64_eq_const_45_0 == 1129022313790326315u)
    if (uint64_eq_const_46_0 == 3092217934064429697u)
    if (uint64_eq_const_47_0 == 9772025649854501185u)
    if (uint64_eq_const_48_0 == 15936627840613991209u)
    if (uint64_eq_const_49_0 == 9118537003884035180u)
    if (uint64_eq_const_50_0 == 12310957288917145453u)
    if (uint64_eq_const_51_0 == 3333215660752825638u)
    if (uint64_eq_const_52_0 == 12876728861892049801u)
    if (uint64_eq_const_53_0 == 1962663212927864668u)
    if (uint64_eq_const_54_0 == 3508702183373766227u)
    if (uint64_eq_const_55_0 == 816470935371366277u)
    if (uint64_eq_const_56_0 == 16599944112359027561u)
    if (uint64_eq_const_57_0 == 16913129934847214070u)
    if (uint64_eq_const_58_0 == 1911757768644521129u)
    if (uint64_eq_const_59_0 == 15554137854768700276u)
    if (uint64_eq_const_60_0 == 13062657926565631717u)
    if (uint64_eq_const_61_0 == 11676717497040412426u)
    if (uint64_eq_const_62_0 == 4132119876125765079u)
    if (uint64_eq_const_63_0 == 3316816712935949597u)
    if (uint64_eq_const_64_0 == 1217127503547923282u)
    if (uint64_eq_const_65_0 == 6565240687785467837u)
    if (uint64_eq_const_66_0 == 7441686752425612730u)
    if (uint64_eq_const_67_0 == 8616376140962365501u)
    if (uint64_eq_const_68_0 == 3621027395731116470u)
    if (uint64_eq_const_69_0 == 521360271526814213u)
    if (uint64_eq_const_70_0 == 17917850797674076963u)
    if (uint64_eq_const_71_0 == 7551516464095522469u)
    if (uint64_eq_const_72_0 == 12859739366195390795u)
    if (uint64_eq_const_73_0 == 13895831103627685678u)
    if (uint64_eq_const_74_0 == 17496575990642229846u)
    if (uint64_eq_const_75_0 == 15676818642644205245u)
    if (uint64_eq_const_76_0 == 10407652504820285952u)
    if (uint64_eq_const_77_0 == 6883056090078220887u)
    if (uint64_eq_const_78_0 == 11508195995849480076u)
    if (uint64_eq_const_79_0 == 17561494437693368828u)
    if (uint64_eq_const_80_0 == 13564076527513579256u)
    if (uint64_eq_const_81_0 == 18167902147435462390u)
    if (uint64_eq_const_82_0 == 723329891045734769u)
    if (uint64_eq_const_83_0 == 6683108111420539761u)
    if (uint64_eq_const_84_0 == 13307204667407108360u)
    if (uint64_eq_const_85_0 == 7266499720964491088u)
    if (uint64_eq_const_86_0 == 2978943871125091238u)
    if (uint64_eq_const_87_0 == 3935550639647921725u)
    if (uint64_eq_const_88_0 == 11804028190082707773u)
    if (uint64_eq_const_89_0 == 15798334000179307266u)
    if (uint64_eq_const_90_0 == 729786762644351296u)
    if (uint64_eq_const_91_0 == 10526481101540971543u)
    if (uint64_eq_const_92_0 == 9197070280570086228u)
    if (uint64_eq_const_93_0 == 15627997454130152827u)
    if (uint64_eq_const_94_0 == 736096161468305223u)
    if (uint64_eq_const_95_0 == 3675448393776550854u)
    if (uint64_eq_const_96_0 == 16432357974754023489u)
    if (uint64_eq_const_97_0 == 62713387310269567u)
    if (uint64_eq_const_98_0 == 6176012673530967864u)
    if (uint64_eq_const_99_0 == 6152064888361263019u)
    if (uint64_eq_const_100_0 == 6619750700327024809u)
    if (uint64_eq_const_101_0 == 15527348936588889765u)
    if (uint64_eq_const_102_0 == 3266357937036749188u)
    if (uint64_eq_const_103_0 == 8654154030769230900u)
    if (uint64_eq_const_104_0 == 10276820543812624231u)
    if (uint64_eq_const_105_0 == 5968373432109953498u)
    if (uint64_eq_const_106_0 == 2523915679428104207u)
    if (uint64_eq_const_107_0 == 1209196031949393514u)
    if (uint64_eq_const_108_0 == 82103392920284170u)
    if (uint64_eq_const_109_0 == 15706506278949990877u)
    if (uint64_eq_const_110_0 == 7355520848481759409u)
    if (uint64_eq_const_111_0 == 8215403371339328100u)
    if (uint64_eq_const_112_0 == 12062000063289533781u)
    if (uint64_eq_const_113_0 == 15147675806982450880u)
    if (uint64_eq_const_114_0 == 7791200149064726456u)
    if (uint64_eq_const_115_0 == 2012991373993021905u)
    if (uint64_eq_const_116_0 == 13404898486190418879u)
    if (uint64_eq_const_117_0 == 7806139178788526957u)
    if (uint64_eq_const_118_0 == 13894042846269592164u)
    if (uint64_eq_const_119_0 == 2672133310289599091u)
    if (uint64_eq_const_120_0 == 4791538423072095217u)
    if (uint64_eq_const_121_0 == 18297340926856037407u)
    if (uint64_eq_const_122_0 == 9947831090790193514u)
    if (uint64_eq_const_123_0 == 7475202211505566878u)
    if (uint64_eq_const_124_0 == 11009945742474740042u)
    if (uint64_eq_const_125_0 == 15371290374667838693u)
    if (uint64_eq_const_126_0 == 6554069637301373810u)
    if (uint64_eq_const_127_0 == 11987187677192399293u)
    if (uint64_eq_const_128_0 == 11399197147415738462u)
    if (uint64_eq_const_129_0 == 2345739862326218786u)
    if (uint64_eq_const_130_0 == 4906025660298876825u)
    if (uint64_eq_const_131_0 == 16700115588724599502u)
    if (uint64_eq_const_132_0 == 15599311127250493811u)
    if (uint64_eq_const_133_0 == 3633878146113774863u)
    if (uint64_eq_const_134_0 == 12361037702055622640u)
    if (uint64_eq_const_135_0 == 16297672234696208097u)
    if (uint64_eq_const_136_0 == 12793072657975132930u)
    if (uint64_eq_const_137_0 == 3076629186813548088u)
    if (uint64_eq_const_138_0 == 6625081670528588795u)
    if (uint64_eq_const_139_0 == 7659464731131666844u)
    if (uint64_eq_const_140_0 == 529577165931592764u)
    if (uint64_eq_const_141_0 == 14467298849967685627u)
    if (uint64_eq_const_142_0 == 7306547181352837938u)
    if (uint64_eq_const_143_0 == 9363692687555617210u)
    if (uint64_eq_const_144_0 == 16771524947554494339u)
    if (uint64_eq_const_145_0 == 18061358410640658188u)
    if (uint64_eq_const_146_0 == 16144503442388969347u)
    if (uint64_eq_const_147_0 == 14992693100776492935u)
    if (uint64_eq_const_148_0 == 15239502701348490476u)
    if (uint64_eq_const_149_0 == 10076353059477108468u)
    if (uint64_eq_const_150_0 == 6609945435317442510u)
    if (uint64_eq_const_151_0 == 145758014112951142u)
    if (uint64_eq_const_152_0 == 605255413637063876u)
    if (uint64_eq_const_153_0 == 3638379623156840589u)
    if (uint64_eq_const_154_0 == 14757547477516624488u)
    if (uint64_eq_const_155_0 == 15315489181212623947u)
    if (uint64_eq_const_156_0 == 10576943755165739528u)
    if (uint64_eq_const_157_0 == 1955305245142726792u)
    if (uint64_eq_const_158_0 == 1318217176086556569u)
    if (uint64_eq_const_159_0 == 5241002489899152962u)
    if (uint64_eq_const_160_0 == 8093977822951521515u)
    if (uint64_eq_const_161_0 == 18269878096815367655u)
    if (uint64_eq_const_162_0 == 14255508594098646046u)
    if (uint64_eq_const_163_0 == 15560725486328871142u)
    if (uint64_eq_const_164_0 == 16074203997828715860u)
    if (uint64_eq_const_165_0 == 13240904677782564995u)
    if (uint64_eq_const_166_0 == 16288017695235138471u)
    if (uint64_eq_const_167_0 == 5733089360245538282u)
    if (uint64_eq_const_168_0 == 3988281588976436573u)
    if (uint64_eq_const_169_0 == 7367962444693000071u)
    if (uint64_eq_const_170_0 == 17317312139974110042u)
    if (uint64_eq_const_171_0 == 6617858637652844436u)
    if (uint64_eq_const_172_0 == 16113840036149578709u)
    if (uint64_eq_const_173_0 == 17494691818639595507u)
    if (uint64_eq_const_174_0 == 15803049356187819086u)
    if (uint64_eq_const_175_0 == 12643041805980081981u)
    if (uint64_eq_const_176_0 == 15616176485485770431u)
    if (uint64_eq_const_177_0 == 2119880041286214426u)
    if (uint64_eq_const_178_0 == 3985081171996302865u)
    if (uint64_eq_const_179_0 == 2550855460936496082u)
    if (uint64_eq_const_180_0 == 1790021230541411793u)
    if (uint64_eq_const_181_0 == 1560600347716076836u)
    if (uint64_eq_const_182_0 == 14880966197837496611u)
    if (uint64_eq_const_183_0 == 2398307373717022806u)
    if (uint64_eq_const_184_0 == 7807593267753483510u)
    if (uint64_eq_const_185_0 == 15267139422496461709u)
    if (uint64_eq_const_186_0 == 9437801164456847737u)
    if (uint64_eq_const_187_0 == 2904770550203943518u)
    if (uint64_eq_const_188_0 == 15799443222945978060u)
    if (uint64_eq_const_189_0 == 9607645804486376356u)
    if (uint64_eq_const_190_0 == 2619170389921057019u)
    if (uint64_eq_const_191_0 == 4857882108437276819u)
    if (uint64_eq_const_192_0 == 11732957156668983079u)
    if (uint64_eq_const_193_0 == 9763007736196540685u)
    if (uint64_eq_const_194_0 == 12398753527176800773u)
    if (uint64_eq_const_195_0 == 15370691942000828724u)
    if (uint64_eq_const_196_0 == 12307480268627467660u)
    if (uint64_eq_const_197_0 == 11632433932730301503u)
    if (uint64_eq_const_198_0 == 7963569187761129962u)
    if (uint64_eq_const_199_0 == 3853708032059342993u)
    if (uint64_eq_const_200_0 == 18312713162325514167u)
    if (uint64_eq_const_201_0 == 7249888137043497223u)
    if (uint64_eq_const_202_0 == 3760117637111563116u)
    if (uint64_eq_const_203_0 == 3989296430672523153u)
    if (uint64_eq_const_204_0 == 3982990090109858838u)
    if (uint64_eq_const_205_0 == 16156973837963384068u)
    if (uint64_eq_const_206_0 == 15706748586013870406u)
    if (uint64_eq_const_207_0 == 15796518672682644013u)
    if (uint64_eq_const_208_0 == 16595474870309963u)
    if (uint64_eq_const_209_0 == 2081398369849814568u)
    if (uint64_eq_const_210_0 == 877272962165190818u)
    if (uint64_eq_const_211_0 == 1619823613615158770u)
    if (uint64_eq_const_212_0 == 13776179188204728237u)
    if (uint64_eq_const_213_0 == 2918739978270159165u)
    if (uint64_eq_const_214_0 == 16982772145495215011u)
    if (uint64_eq_const_215_0 == 15529718262780735619u)
    if (uint64_eq_const_216_0 == 5208005500356564424u)
    if (uint64_eq_const_217_0 == 15308444471754549342u)
    if (uint64_eq_const_218_0 == 17404691459972830173u)
    if (uint64_eq_const_219_0 == 2823665191510429205u)
    if (uint64_eq_const_220_0 == 17708409218121335000u)
    if (uint64_eq_const_221_0 == 12278119892025436537u)
    if (uint64_eq_const_222_0 == 3522153583095751896u)
    if (uint64_eq_const_223_0 == 10415865033715544050u)
    if (uint64_eq_const_224_0 == 15546132274408421458u)
    if (uint64_eq_const_225_0 == 470971019632573652u)
    if (uint64_eq_const_226_0 == 3156996844753159824u)
    if (uint64_eq_const_227_0 == 14239959137392491255u)
    if (uint64_eq_const_228_0 == 14214278789778637660u)
    if (uint64_eq_const_229_0 == 13257051732292014981u)
    if (uint64_eq_const_230_0 == 14690142870698625016u)
    if (uint64_eq_const_231_0 == 14849692571575432725u)
    if (uint64_eq_const_232_0 == 17886641774699850576u)
    if (uint64_eq_const_233_0 == 178286164654099961u)
    if (uint64_eq_const_234_0 == 12898125958050572658u)
    if (uint64_eq_const_235_0 == 16952965874656573651u)
    if (uint64_eq_const_236_0 == 9699863670458551869u)
    if (uint64_eq_const_237_0 == 6837825044179014254u)
    if (uint64_eq_const_238_0 == 455014285343954776u)
    if (uint64_eq_const_239_0 == 14044682850555636170u)
    if (uint64_eq_const_240_0 == 8863684921935839590u)
    if (uint64_eq_const_241_0 == 16288597814486741880u)
    if (uint64_eq_const_242_0 == 576242270562235511u)
    if (uint64_eq_const_243_0 == 5791059129266048296u)
    if (uint64_eq_const_244_0 == 9740589656988025793u)
    if (uint64_eq_const_245_0 == 14105964929006380672u)
    if (uint64_eq_const_246_0 == 5914493747752006799u)
    if (uint64_eq_const_247_0 == 10551890253183214382u)
    if (uint64_eq_const_248_0 == 5435797397402566776u)
    if (uint64_eq_const_249_0 == 1894031287004219968u)
    if (uint64_eq_const_250_0 == 5192798831569520340u)
    if (uint64_eq_const_251_0 == 16854433349500294834u)
    if (uint64_eq_const_252_0 == 17720177915331797356u)
    if (uint64_eq_const_253_0 == 9261175564915981640u)
    if (uint64_eq_const_254_0 == 7028528109882003568u)
    if (uint64_eq_const_255_0 == 11773729184188840862u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
