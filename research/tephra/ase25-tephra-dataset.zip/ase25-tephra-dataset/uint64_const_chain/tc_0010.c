#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;

    if (size < 80)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 11598440009914277709u)
    if (uint64_eq_const_1_0 == 1410330241734637417u)
    if (uint64_eq_const_2_0 == 17621874723135636448u)
    if (uint64_eq_const_3_0 == 13859065321425056551u)
    if (uint64_eq_const_4_0 == 8609971353067216977u)
    if (uint64_eq_const_5_0 == 12680737254603769684u)
    if (uint64_eq_const_6_0 == 130183879945327178u)
    if (uint64_eq_const_7_0 == 9289405454541731114u)
    if (uint64_eq_const_8_0 == 16761446137457351883u)
    if (uint64_eq_const_9_0 == 14011661348267980589u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
