#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;
    uint64_t uint64_eq_const_14_0;
    uint64_t uint64_eq_const_15_0;
    uint64_t uint64_eq_const_16_0;
    uint64_t uint64_eq_const_17_0;
    uint64_t uint64_eq_const_18_0;
    uint64_t uint64_eq_const_19_0;
    uint64_t uint64_eq_const_20_0;
    uint64_t uint64_eq_const_21_0;
    uint64_t uint64_eq_const_22_0;
    uint64_t uint64_eq_const_23_0;
    uint64_t uint64_eq_const_24_0;
    uint64_t uint64_eq_const_25_0;
    uint64_t uint64_eq_const_26_0;
    uint64_t uint64_eq_const_27_0;
    uint64_t uint64_eq_const_28_0;
    uint64_t uint64_eq_const_29_0;
    uint64_t uint64_eq_const_30_0;
    uint64_t uint64_eq_const_31_0;
    uint64_t uint64_eq_const_32_0;
    uint64_t uint64_eq_const_33_0;
    uint64_t uint64_eq_const_34_0;
    uint64_t uint64_eq_const_35_0;
    uint64_t uint64_eq_const_36_0;
    uint64_t uint64_eq_const_37_0;
    uint64_t uint64_eq_const_38_0;
    uint64_t uint64_eq_const_39_0;
    uint64_t uint64_eq_const_40_0;
    uint64_t uint64_eq_const_41_0;
    uint64_t uint64_eq_const_42_0;
    uint64_t uint64_eq_const_43_0;
    uint64_t uint64_eq_const_44_0;
    uint64_t uint64_eq_const_45_0;
    uint64_t uint64_eq_const_46_0;
    uint64_t uint64_eq_const_47_0;
    uint64_t uint64_eq_const_48_0;
    uint64_t uint64_eq_const_49_0;
    uint64_t uint64_eq_const_50_0;
    uint64_t uint64_eq_const_51_0;
    uint64_t uint64_eq_const_52_0;
    uint64_t uint64_eq_const_53_0;
    uint64_t uint64_eq_const_54_0;
    uint64_t uint64_eq_const_55_0;
    uint64_t uint64_eq_const_56_0;
    uint64_t uint64_eq_const_57_0;
    uint64_t uint64_eq_const_58_0;
    uint64_t uint64_eq_const_59_0;
    uint64_t uint64_eq_const_60_0;
    uint64_t uint64_eq_const_61_0;
    uint64_t uint64_eq_const_62_0;
    uint64_t uint64_eq_const_63_0;

    if (size < 512)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_17_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_18_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_24_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_26_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_29_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_31_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_34_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_38_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_41_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_45_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_49_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_50_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_52_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_53_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_55_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_58_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_60_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_61_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_63_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 17638505241940699204u)
    if (uint64_eq_const_1_0 == 7336586390652092162u)
    if (uint64_eq_const_2_0 == 7478119949172040552u)
    if (uint64_eq_const_3_0 == 6324354074606068561u)
    if (uint64_eq_const_4_0 == 13051191325170926589u)
    if (uint64_eq_const_5_0 == 12360812242728913654u)
    if (uint64_eq_const_6_0 == 16963048563125261762u)
    if (uint64_eq_const_7_0 == 15572972217091011170u)
    if (uint64_eq_const_8_0 == 1921773567773003232u)
    if (uint64_eq_const_9_0 == 9210245196337955715u)
    if (uint64_eq_const_10_0 == 8038863280145559135u)
    if (uint64_eq_const_11_0 == 14046229738240813145u)
    if (uint64_eq_const_12_0 == 18159456678112816347u)
    if (uint64_eq_const_13_0 == 1975903414373102280u)
    if (uint64_eq_const_14_0 == 2017223402162638966u)
    if (uint64_eq_const_15_0 == 3766699016654400944u)
    if (uint64_eq_const_16_0 == 16546624341925067536u)
    if (uint64_eq_const_17_0 == 16586343109907114810u)
    if (uint64_eq_const_18_0 == 3755891124981486005u)
    if (uint64_eq_const_19_0 == 7621904525734634613u)
    if (uint64_eq_const_20_0 == 6142475624057632855u)
    if (uint64_eq_const_21_0 == 17848539179010539040u)
    if (uint64_eq_const_22_0 == 3292188551925404860u)
    if (uint64_eq_const_23_0 == 7990824590106445513u)
    if (uint64_eq_const_24_0 == 5308386386544676025u)
    if (uint64_eq_const_25_0 == 5448181129131278870u)
    if (uint64_eq_const_26_0 == 643551760708727712u)
    if (uint64_eq_const_27_0 == 13558759428949644642u)
    if (uint64_eq_const_28_0 == 3476021381941336822u)
    if (uint64_eq_const_29_0 == 1571283763905636747u)
    if (uint64_eq_const_30_0 == 3637170138917730921u)
    if (uint64_eq_const_31_0 == 6479033795684701705u)
    if (uint64_eq_const_32_0 == 9881380094292845312u)
    if (uint64_eq_const_33_0 == 953268919882541379u)
    if (uint64_eq_const_34_0 == 5430097876197978516u)
    if (uint64_eq_const_35_0 == 16517227147159413277u)
    if (uint64_eq_const_36_0 == 12980939108745507966u)
    if (uint64_eq_const_37_0 == 17734486916999360213u)
    if (uint64_eq_const_38_0 == 10368769651162626193u)
    if (uint64_eq_const_39_0 == 3179525481515025679u)
    if (uint64_eq_const_40_0 == 4019618429485625674u)
    if (uint64_eq_const_41_0 == 3375305719538624301u)
    if (uint64_eq_const_42_0 == 4204871645126766662u)
    if (uint64_eq_const_43_0 == 17604840325134101220u)
    if (uint64_eq_const_44_0 == 8983060521600229363u)
    if (uint64_eq_const_45_0 == 9565207833505043724u)
    if (uint64_eq_const_46_0 == 3069054551267603850u)
    if (uint64_eq_const_47_0 == 16563585032996757174u)
    if (uint64_eq_const_48_0 == 7468199481045274172u)
    if (uint64_eq_const_49_0 == 2344861419884099459u)
    if (uint64_eq_const_50_0 == 5774335209128831915u)
    if (uint64_eq_const_51_0 == 9345805338225662259u)
    if (uint64_eq_const_52_0 == 8440962938489635739u)
    if (uint64_eq_const_53_0 == 17023896316263858300u)
    if (uint64_eq_const_54_0 == 15015582942233859817u)
    if (uint64_eq_const_55_0 == 9357062862133518108u)
    if (uint64_eq_const_56_0 == 17912385574930334651u)
    if (uint64_eq_const_57_0 == 7979682155318975281u)
    if (uint64_eq_const_58_0 == 12024884280174266104u)
    if (uint64_eq_const_59_0 == 18430876433069944776u)
    if (uint64_eq_const_60_0 == 16928827789061431546u)
    if (uint64_eq_const_61_0 == 13492347416063165107u)
    if (uint64_eq_const_62_0 == 9932958273457787266u)
    if (uint64_eq_const_63_0 == 4839097002102457246u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
