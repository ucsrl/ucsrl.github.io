#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;
    uint64_t uint64_eq_const_13_0;
    uint64_t uint64_eq_const_14_0;
    uint64_t uint64_eq_const_15_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_14_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_15_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 8864398633056828611u)
    if (uint64_eq_const_1_0 == 6160410525076973580u)
    if (uint64_eq_const_2_0 == 14911033132275467451u)
    if (uint64_eq_const_3_0 == 14508560033012734462u)
    if (uint64_eq_const_4_0 == 5354235840052943847u)
    if (uint64_eq_const_5_0 == 9726301061242258725u)
    if (uint64_eq_const_6_0 == 7785270106433664006u)
    if (uint64_eq_const_7_0 == 17770433472058151108u)
    if (uint64_eq_const_8_0 == 17418546244213835365u)
    if (uint64_eq_const_9_0 == 15288849525118135484u)
    if (uint64_eq_const_10_0 == 15142720361413065036u)
    if (uint64_eq_const_11_0 == 16149929000606578205u)
    if (uint64_eq_const_12_0 == 6359538542484596923u)
    if (uint64_eq_const_13_0 == 15896245968193048831u)
    if (uint64_eq_const_14_0 == 7759710651367425622u)
    if (uint64_eq_const_15_0 == 11084031549345237907u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
