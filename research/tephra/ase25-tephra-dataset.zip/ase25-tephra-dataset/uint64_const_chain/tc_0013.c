#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;
    uint64_t uint64_eq_const_1_0;
    uint64_t uint64_eq_const_2_0;
    uint64_t uint64_eq_const_3_0;
    uint64_t uint64_eq_const_4_0;
    uint64_t uint64_eq_const_5_0;
    uint64_t uint64_eq_const_6_0;
    uint64_t uint64_eq_const_7_0;
    uint64_t uint64_eq_const_8_0;
    uint64_t uint64_eq_const_9_0;
    uint64_t uint64_eq_const_10_0;
    uint64_t uint64_eq_const_11_0;
    uint64_t uint64_eq_const_12_0;

    if (size < 104)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&uint64_eq_const_12_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 9407609171453229941u)
    if (uint64_eq_const_1_0 == 1081045072133600526u)
    if (uint64_eq_const_2_0 == 11764510702321399503u)
    if (uint64_eq_const_3_0 == 9366744540341955698u)
    if (uint64_eq_const_4_0 == 18126404545337860485u)
    if (uint64_eq_const_5_0 == 15331704920022130868u)
    if (uint64_eq_const_6_0 == 2113869030415377804u)
    if (uint64_eq_const_7_0 == 10858505113040214228u)
    if (uint64_eq_const_8_0 == 13633821607308944052u)
    if (uint64_eq_const_9_0 == 10476683707484701503u)
    if (uint64_eq_const_10_0 == 9559420632434436381u)
    if (uint64_eq_const_11_0 == 6357594341017581412u)
    if (uint64_eq_const_12_0 == 14096110075301979881u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
