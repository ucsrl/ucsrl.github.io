#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint64_t uint64_eq_const_0_0;

    if (size < 8)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint64_eq_const_0_0, &data[i], 8);
    i += 8;


    if (uint64_eq_const_0_0 == 13421181215734401783u)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
