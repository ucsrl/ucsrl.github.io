#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t bool_uint8_0_0;
    uint8_t bool_uint8_1_0;
    uint8_t bool_uint8_2_0;
    uint8_t bool_uint8_3_0;
    uint8_t bool_uint8_4_0;
    uint8_t bool_uint8_5_0;
    uint8_t bool_uint8_6_0;
    uint8_t bool_uint8_7_0;
    uint8_t bool_uint8_8_0;
    uint8_t bool_uint8_9_0;
    uint8_t bool_uint8_10_0;
    uint8_t bool_uint8_11_0;

    if (size < 12)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&bool_uint8_0_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_1_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_2_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_3_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_4_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_5_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_6_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_7_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_8_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_9_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_10_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_11_0, &data[i], 1);
    i += 1;


    if (bool_uint8_0_0)
    if (!bool_uint8_1_0)
    if (!bool_uint8_2_0)
    if (!bool_uint8_3_0)
    if (!bool_uint8_4_0)
    if (bool_uint8_5_0)
    if (bool_uint8_6_0)
    if (!bool_uint8_7_0)
    if (bool_uint8_8_0)
    if (bool_uint8_9_0)
    if (bool_uint8_10_0)
    if (!bool_uint8_11_0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
