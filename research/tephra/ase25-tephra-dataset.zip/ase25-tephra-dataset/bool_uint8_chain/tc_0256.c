#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t bool_uint8_0_0;
    uint8_t bool_uint8_1_0;
    uint8_t bool_uint8_2_0;
    uint8_t bool_uint8_3_0;
    uint8_t bool_uint8_4_0;
    uint8_t bool_uint8_5_0;
    uint8_t bool_uint8_6_0;
    uint8_t bool_uint8_7_0;
    uint8_t bool_uint8_8_0;
    uint8_t bool_uint8_9_0;
    uint8_t bool_uint8_10_0;
    uint8_t bool_uint8_11_0;
    uint8_t bool_uint8_12_0;
    uint8_t bool_uint8_13_0;
    uint8_t bool_uint8_14_0;
    uint8_t bool_uint8_15_0;
    uint8_t bool_uint8_16_0;
    uint8_t bool_uint8_17_0;
    uint8_t bool_uint8_18_0;
    uint8_t bool_uint8_19_0;
    uint8_t bool_uint8_20_0;
    uint8_t bool_uint8_21_0;
    uint8_t bool_uint8_22_0;
    uint8_t bool_uint8_23_0;
    uint8_t bool_uint8_24_0;
    uint8_t bool_uint8_25_0;
    uint8_t bool_uint8_26_0;
    uint8_t bool_uint8_27_0;
    uint8_t bool_uint8_28_0;
    uint8_t bool_uint8_29_0;
    uint8_t bool_uint8_30_0;
    uint8_t bool_uint8_31_0;
    uint8_t bool_uint8_32_0;
    uint8_t bool_uint8_33_0;
    uint8_t bool_uint8_34_0;
    uint8_t bool_uint8_35_0;
    uint8_t bool_uint8_36_0;
    uint8_t bool_uint8_37_0;
    uint8_t bool_uint8_38_0;
    uint8_t bool_uint8_39_0;
    uint8_t bool_uint8_40_0;
    uint8_t bool_uint8_41_0;
    uint8_t bool_uint8_42_0;
    uint8_t bool_uint8_43_0;
    uint8_t bool_uint8_44_0;
    uint8_t bool_uint8_45_0;
    uint8_t bool_uint8_46_0;
    uint8_t bool_uint8_47_0;
    uint8_t bool_uint8_48_0;
    uint8_t bool_uint8_49_0;
    uint8_t bool_uint8_50_0;
    uint8_t bool_uint8_51_0;
    uint8_t bool_uint8_52_0;
    uint8_t bool_uint8_53_0;
    uint8_t bool_uint8_54_0;
    uint8_t bool_uint8_55_0;
    uint8_t bool_uint8_56_0;
    uint8_t bool_uint8_57_0;
    uint8_t bool_uint8_58_0;
    uint8_t bool_uint8_59_0;
    uint8_t bool_uint8_60_0;
    uint8_t bool_uint8_61_0;
    uint8_t bool_uint8_62_0;
    uint8_t bool_uint8_63_0;
    uint8_t bool_uint8_64_0;
    uint8_t bool_uint8_65_0;
    uint8_t bool_uint8_66_0;
    uint8_t bool_uint8_67_0;
    uint8_t bool_uint8_68_0;
    uint8_t bool_uint8_69_0;
    uint8_t bool_uint8_70_0;
    uint8_t bool_uint8_71_0;
    uint8_t bool_uint8_72_0;
    uint8_t bool_uint8_73_0;
    uint8_t bool_uint8_74_0;
    uint8_t bool_uint8_75_0;
    uint8_t bool_uint8_76_0;
    uint8_t bool_uint8_77_0;
    uint8_t bool_uint8_78_0;
    uint8_t bool_uint8_79_0;
    uint8_t bool_uint8_80_0;
    uint8_t bool_uint8_81_0;
    uint8_t bool_uint8_82_0;
    uint8_t bool_uint8_83_0;
    uint8_t bool_uint8_84_0;
    uint8_t bool_uint8_85_0;
    uint8_t bool_uint8_86_0;
    uint8_t bool_uint8_87_0;
    uint8_t bool_uint8_88_0;
    uint8_t bool_uint8_89_0;
    uint8_t bool_uint8_90_0;
    uint8_t bool_uint8_91_0;
    uint8_t bool_uint8_92_0;
    uint8_t bool_uint8_93_0;
    uint8_t bool_uint8_94_0;
    uint8_t bool_uint8_95_0;
    uint8_t bool_uint8_96_0;
    uint8_t bool_uint8_97_0;
    uint8_t bool_uint8_98_0;
    uint8_t bool_uint8_99_0;
    uint8_t bool_uint8_100_0;
    uint8_t bool_uint8_101_0;
    uint8_t bool_uint8_102_0;
    uint8_t bool_uint8_103_0;
    uint8_t bool_uint8_104_0;
    uint8_t bool_uint8_105_0;
    uint8_t bool_uint8_106_0;
    uint8_t bool_uint8_107_0;
    uint8_t bool_uint8_108_0;
    uint8_t bool_uint8_109_0;
    uint8_t bool_uint8_110_0;
    uint8_t bool_uint8_111_0;
    uint8_t bool_uint8_112_0;
    uint8_t bool_uint8_113_0;
    uint8_t bool_uint8_114_0;
    uint8_t bool_uint8_115_0;
    uint8_t bool_uint8_116_0;
    uint8_t bool_uint8_117_0;
    uint8_t bool_uint8_118_0;
    uint8_t bool_uint8_119_0;
    uint8_t bool_uint8_120_0;
    uint8_t bool_uint8_121_0;
    uint8_t bool_uint8_122_0;
    uint8_t bool_uint8_123_0;
    uint8_t bool_uint8_124_0;
    uint8_t bool_uint8_125_0;
    uint8_t bool_uint8_126_0;
    uint8_t bool_uint8_127_0;
    uint8_t bool_uint8_128_0;
    uint8_t bool_uint8_129_0;
    uint8_t bool_uint8_130_0;
    uint8_t bool_uint8_131_0;
    uint8_t bool_uint8_132_0;
    uint8_t bool_uint8_133_0;
    uint8_t bool_uint8_134_0;
    uint8_t bool_uint8_135_0;
    uint8_t bool_uint8_136_0;
    uint8_t bool_uint8_137_0;
    uint8_t bool_uint8_138_0;
    uint8_t bool_uint8_139_0;
    uint8_t bool_uint8_140_0;
    uint8_t bool_uint8_141_0;
    uint8_t bool_uint8_142_0;
    uint8_t bool_uint8_143_0;
    uint8_t bool_uint8_144_0;
    uint8_t bool_uint8_145_0;
    uint8_t bool_uint8_146_0;
    uint8_t bool_uint8_147_0;
    uint8_t bool_uint8_148_0;
    uint8_t bool_uint8_149_0;
    uint8_t bool_uint8_150_0;
    uint8_t bool_uint8_151_0;
    uint8_t bool_uint8_152_0;
    uint8_t bool_uint8_153_0;
    uint8_t bool_uint8_154_0;
    uint8_t bool_uint8_155_0;
    uint8_t bool_uint8_156_0;
    uint8_t bool_uint8_157_0;
    uint8_t bool_uint8_158_0;
    uint8_t bool_uint8_159_0;
    uint8_t bool_uint8_160_0;
    uint8_t bool_uint8_161_0;
    uint8_t bool_uint8_162_0;
    uint8_t bool_uint8_163_0;
    uint8_t bool_uint8_164_0;
    uint8_t bool_uint8_165_0;
    uint8_t bool_uint8_166_0;
    uint8_t bool_uint8_167_0;
    uint8_t bool_uint8_168_0;
    uint8_t bool_uint8_169_0;
    uint8_t bool_uint8_170_0;
    uint8_t bool_uint8_171_0;
    uint8_t bool_uint8_172_0;
    uint8_t bool_uint8_173_0;
    uint8_t bool_uint8_174_0;
    uint8_t bool_uint8_175_0;
    uint8_t bool_uint8_176_0;
    uint8_t bool_uint8_177_0;
    uint8_t bool_uint8_178_0;
    uint8_t bool_uint8_179_0;
    uint8_t bool_uint8_180_0;
    uint8_t bool_uint8_181_0;
    uint8_t bool_uint8_182_0;
    uint8_t bool_uint8_183_0;
    uint8_t bool_uint8_184_0;
    uint8_t bool_uint8_185_0;
    uint8_t bool_uint8_186_0;
    uint8_t bool_uint8_187_0;
    uint8_t bool_uint8_188_0;
    uint8_t bool_uint8_189_0;
    uint8_t bool_uint8_190_0;
    uint8_t bool_uint8_191_0;
    uint8_t bool_uint8_192_0;
    uint8_t bool_uint8_193_0;
    uint8_t bool_uint8_194_0;
    uint8_t bool_uint8_195_0;
    uint8_t bool_uint8_196_0;
    uint8_t bool_uint8_197_0;
    uint8_t bool_uint8_198_0;
    uint8_t bool_uint8_199_0;
    uint8_t bool_uint8_200_0;
    uint8_t bool_uint8_201_0;
    uint8_t bool_uint8_202_0;
    uint8_t bool_uint8_203_0;
    uint8_t bool_uint8_204_0;
    uint8_t bool_uint8_205_0;
    uint8_t bool_uint8_206_0;
    uint8_t bool_uint8_207_0;
    uint8_t bool_uint8_208_0;
    uint8_t bool_uint8_209_0;
    uint8_t bool_uint8_210_0;
    uint8_t bool_uint8_211_0;
    uint8_t bool_uint8_212_0;
    uint8_t bool_uint8_213_0;
    uint8_t bool_uint8_214_0;
    uint8_t bool_uint8_215_0;
    uint8_t bool_uint8_216_0;
    uint8_t bool_uint8_217_0;
    uint8_t bool_uint8_218_0;
    uint8_t bool_uint8_219_0;
    uint8_t bool_uint8_220_0;
    uint8_t bool_uint8_221_0;
    uint8_t bool_uint8_222_0;
    uint8_t bool_uint8_223_0;
    uint8_t bool_uint8_224_0;
    uint8_t bool_uint8_225_0;
    uint8_t bool_uint8_226_0;
    uint8_t bool_uint8_227_0;
    uint8_t bool_uint8_228_0;
    uint8_t bool_uint8_229_0;
    uint8_t bool_uint8_230_0;
    uint8_t bool_uint8_231_0;
    uint8_t bool_uint8_232_0;
    uint8_t bool_uint8_233_0;
    uint8_t bool_uint8_234_0;
    uint8_t bool_uint8_235_0;
    uint8_t bool_uint8_236_0;
    uint8_t bool_uint8_237_0;
    uint8_t bool_uint8_238_0;
    uint8_t bool_uint8_239_0;
    uint8_t bool_uint8_240_0;
    uint8_t bool_uint8_241_0;
    uint8_t bool_uint8_242_0;
    uint8_t bool_uint8_243_0;
    uint8_t bool_uint8_244_0;
    uint8_t bool_uint8_245_0;
    uint8_t bool_uint8_246_0;
    uint8_t bool_uint8_247_0;
    uint8_t bool_uint8_248_0;
    uint8_t bool_uint8_249_0;
    uint8_t bool_uint8_250_0;
    uint8_t bool_uint8_251_0;
    uint8_t bool_uint8_252_0;
    uint8_t bool_uint8_253_0;
    uint8_t bool_uint8_254_0;
    uint8_t bool_uint8_255_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&bool_uint8_0_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_1_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_2_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_3_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_4_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_5_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_6_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_7_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_8_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_9_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_10_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_11_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_12_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_13_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_14_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_15_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_16_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_17_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_18_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_19_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_20_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_21_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_22_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_23_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_24_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_25_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_26_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_27_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_28_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_29_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_30_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_31_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_32_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_33_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_34_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_35_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_36_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_37_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_38_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_39_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_40_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_41_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_42_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_43_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_44_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_45_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_46_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_47_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_48_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_49_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_50_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_51_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_52_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_53_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_54_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_55_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_56_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_57_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_58_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_59_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_60_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_61_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_62_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_63_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_64_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_65_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_66_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_67_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_68_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_69_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_70_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_71_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_72_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_73_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_74_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_75_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_76_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_77_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_78_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_79_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_80_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_81_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_82_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_83_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_84_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_85_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_86_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_87_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_88_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_89_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_90_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_91_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_92_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_93_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_94_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_95_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_96_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_97_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_98_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_99_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_100_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_101_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_102_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_103_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_104_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_105_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_106_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_107_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_108_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_109_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_110_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_111_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_112_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_113_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_114_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_115_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_116_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_117_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_118_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_119_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_120_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_121_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_122_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_123_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_124_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_125_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_126_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_127_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_128_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_129_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_130_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_131_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_132_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_133_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_134_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_135_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_136_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_137_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_138_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_139_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_140_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_141_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_142_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_143_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_144_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_145_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_146_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_147_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_148_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_149_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_150_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_151_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_152_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_153_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_154_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_155_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_156_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_157_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_158_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_159_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_160_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_161_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_162_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_163_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_164_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_165_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_166_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_167_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_168_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_169_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_170_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_171_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_172_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_173_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_174_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_175_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_176_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_177_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_178_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_179_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_180_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_181_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_182_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_183_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_184_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_185_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_186_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_187_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_188_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_189_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_190_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_191_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_192_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_193_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_194_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_195_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_196_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_197_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_198_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_199_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_200_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_201_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_202_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_203_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_204_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_205_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_206_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_207_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_208_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_209_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_210_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_211_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_212_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_213_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_214_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_215_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_216_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_217_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_218_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_219_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_220_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_221_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_222_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_223_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_224_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_225_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_226_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_227_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_228_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_229_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_230_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_231_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_232_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_233_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_234_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_235_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_236_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_237_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_238_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_239_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_240_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_241_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_242_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_243_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_244_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_245_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_246_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_247_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_248_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_249_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_250_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_251_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_252_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_253_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_254_0, &data[i], 1);
    i += 1;
    memcpy(&bool_uint8_255_0, &data[i], 1);
    i += 1;


    if (bool_uint8_0_0)
    if (!bool_uint8_1_0)
    if (bool_uint8_2_0)
    if (bool_uint8_3_0)
    if (!bool_uint8_4_0)
    if (bool_uint8_5_0)
    if (!bool_uint8_6_0)
    if (bool_uint8_7_0)
    if (bool_uint8_8_0)
    if (bool_uint8_9_0)
    if (bool_uint8_10_0)
    if (bool_uint8_11_0)
    if (!bool_uint8_12_0)
    if (!bool_uint8_13_0)
    if (bool_uint8_14_0)
    if (bool_uint8_15_0)
    if (bool_uint8_16_0)
    if (bool_uint8_17_0)
    if (!bool_uint8_18_0)
    if (bool_uint8_19_0)
    if (bool_uint8_20_0)
    if (!bool_uint8_21_0)
    if (!bool_uint8_22_0)
    if (bool_uint8_23_0)
    if (bool_uint8_24_0)
    if (!bool_uint8_25_0)
    if (!bool_uint8_26_0)
    if (bool_uint8_27_0)
    if (!bool_uint8_28_0)
    if (!bool_uint8_29_0)
    if (bool_uint8_30_0)
    if (bool_uint8_31_0)
    if (!bool_uint8_32_0)
    if (bool_uint8_33_0)
    if (bool_uint8_34_0)
    if (!bool_uint8_35_0)
    if (bool_uint8_36_0)
    if (bool_uint8_37_0)
    if (bool_uint8_38_0)
    if (!bool_uint8_39_0)
    if (bool_uint8_40_0)
    if (!bool_uint8_41_0)
    if (!bool_uint8_42_0)
    if (!bool_uint8_43_0)
    if (bool_uint8_44_0)
    if (!bool_uint8_45_0)
    if (bool_uint8_46_0)
    if (!bool_uint8_47_0)
    if (!bool_uint8_48_0)
    if (bool_uint8_49_0)
    if (bool_uint8_50_0)
    if (bool_uint8_51_0)
    if (!bool_uint8_52_0)
    if (!bool_uint8_53_0)
    if (bool_uint8_54_0)
    if (!bool_uint8_55_0)
    if (bool_uint8_56_0)
    if (!bool_uint8_57_0)
    if (!bool_uint8_58_0)
    if (!bool_uint8_59_0)
    if (bool_uint8_60_0)
    if (!bool_uint8_61_0)
    if (!bool_uint8_62_0)
    if (!bool_uint8_63_0)
    if (bool_uint8_64_0)
    if (bool_uint8_65_0)
    if (!bool_uint8_66_0)
    if (!bool_uint8_67_0)
    if (bool_uint8_68_0)
    if (bool_uint8_69_0)
    if (!bool_uint8_70_0)
    if (!bool_uint8_71_0)
    if (bool_uint8_72_0)
    if (!bool_uint8_73_0)
    if (bool_uint8_74_0)
    if (bool_uint8_75_0)
    if (!bool_uint8_76_0)
    if (!bool_uint8_77_0)
    if (!bool_uint8_78_0)
    if (!bool_uint8_79_0)
    if (bool_uint8_80_0)
    if (!bool_uint8_81_0)
    if (!bool_uint8_82_0)
    if (bool_uint8_83_0)
    if (bool_uint8_84_0)
    if (bool_uint8_85_0)
    if (bool_uint8_86_0)
    if (bool_uint8_87_0)
    if (bool_uint8_88_0)
    if (!bool_uint8_89_0)
    if (bool_uint8_90_0)
    if (!bool_uint8_91_0)
    if (bool_uint8_92_0)
    if (!bool_uint8_93_0)
    if (!bool_uint8_94_0)
    if (!bool_uint8_95_0)
    if (bool_uint8_96_0)
    if (!bool_uint8_97_0)
    if (!bool_uint8_98_0)
    if (bool_uint8_99_0)
    if (!bool_uint8_100_0)
    if (bool_uint8_101_0)
    if (bool_uint8_102_0)
    if (!bool_uint8_103_0)
    if (!bool_uint8_104_0)
    if (bool_uint8_105_0)
    if (bool_uint8_106_0)
    if (!bool_uint8_107_0)
    if (bool_uint8_108_0)
    if (bool_uint8_109_0)
    if (bool_uint8_110_0)
    if (!bool_uint8_111_0)
    if (bool_uint8_112_0)
    if (!bool_uint8_113_0)
    if (bool_uint8_114_0)
    if (bool_uint8_115_0)
    if (bool_uint8_116_0)
    if (bool_uint8_117_0)
    if (bool_uint8_118_0)
    if (!bool_uint8_119_0)
    if (!bool_uint8_120_0)
    if (bool_uint8_121_0)
    if (!bool_uint8_122_0)
    if (!bool_uint8_123_0)
    if (!bool_uint8_124_0)
    if (!bool_uint8_125_0)
    if (bool_uint8_126_0)
    if (bool_uint8_127_0)
    if (bool_uint8_128_0)
    if (bool_uint8_129_0)
    if (bool_uint8_130_0)
    if (bool_uint8_131_0)
    if (!bool_uint8_132_0)
    if (bool_uint8_133_0)
    if (bool_uint8_134_0)
    if (!bool_uint8_135_0)
    if (bool_uint8_136_0)
    if (!bool_uint8_137_0)
    if (bool_uint8_138_0)
    if (!bool_uint8_139_0)
    if (!bool_uint8_140_0)
    if (bool_uint8_141_0)
    if (!bool_uint8_142_0)
    if (!bool_uint8_143_0)
    if (!bool_uint8_144_0)
    if (bool_uint8_145_0)
    if (!bool_uint8_146_0)
    if (!bool_uint8_147_0)
    if (bool_uint8_148_0)
    if (!bool_uint8_149_0)
    if (!bool_uint8_150_0)
    if (!bool_uint8_151_0)
    if (bool_uint8_152_0)
    if (!bool_uint8_153_0)
    if (bool_uint8_154_0)
    if (bool_uint8_155_0)
    if (!bool_uint8_156_0)
    if (bool_uint8_157_0)
    if (bool_uint8_158_0)
    if (bool_uint8_159_0)
    if (bool_uint8_160_0)
    if (!bool_uint8_161_0)
    if (!bool_uint8_162_0)
    if (!bool_uint8_163_0)
    if (bool_uint8_164_0)
    if (!bool_uint8_165_0)
    if (bool_uint8_166_0)
    if (bool_uint8_167_0)
    if (!bool_uint8_168_0)
    if (bool_uint8_169_0)
    if (!bool_uint8_170_0)
    if (bool_uint8_171_0)
    if (!bool_uint8_172_0)
    if (!bool_uint8_173_0)
    if (!bool_uint8_174_0)
    if (!bool_uint8_175_0)
    if (bool_uint8_176_0)
    if (!bool_uint8_177_0)
    if (!bool_uint8_178_0)
    if (bool_uint8_179_0)
    if (bool_uint8_180_0)
    if (bool_uint8_181_0)
    if (bool_uint8_182_0)
    if (bool_uint8_183_0)
    if (bool_uint8_184_0)
    if (!bool_uint8_185_0)
    if (!bool_uint8_186_0)
    if (!bool_uint8_187_0)
    if (bool_uint8_188_0)
    if (bool_uint8_189_0)
    if (bool_uint8_190_0)
    if (bool_uint8_191_0)
    if (!bool_uint8_192_0)
    if (!bool_uint8_193_0)
    if (!bool_uint8_194_0)
    if (bool_uint8_195_0)
    if (bool_uint8_196_0)
    if (bool_uint8_197_0)
    if (bool_uint8_198_0)
    if (!bool_uint8_199_0)
    if (!bool_uint8_200_0)
    if (!bool_uint8_201_0)
    if (bool_uint8_202_0)
    if (!bool_uint8_203_0)
    if (!bool_uint8_204_0)
    if (bool_uint8_205_0)
    if (bool_uint8_206_0)
    if (bool_uint8_207_0)
    if (bool_uint8_208_0)
    if (!bool_uint8_209_0)
    if (bool_uint8_210_0)
    if (!bool_uint8_211_0)
    if (bool_uint8_212_0)
    if (bool_uint8_213_0)
    if (!bool_uint8_214_0)
    if (bool_uint8_215_0)
    if (bool_uint8_216_0)
    if (bool_uint8_217_0)
    if (!bool_uint8_218_0)
    if (!bool_uint8_219_0)
    if (!bool_uint8_220_0)
    if (!bool_uint8_221_0)
    if (!bool_uint8_222_0)
    if (!bool_uint8_223_0)
    if (bool_uint8_224_0)
    if (bool_uint8_225_0)
    if (bool_uint8_226_0)
    if (bool_uint8_227_0)
    if (!bool_uint8_228_0)
    if (!bool_uint8_229_0)
    if (bool_uint8_230_0)
    if (!bool_uint8_231_0)
    if (!bool_uint8_232_0)
    if (bool_uint8_233_0)
    if (bool_uint8_234_0)
    if (bool_uint8_235_0)
    if (!bool_uint8_236_0)
    if (!bool_uint8_237_0)
    if (bool_uint8_238_0)
    if (bool_uint8_239_0)
    if (bool_uint8_240_0)
    if (!bool_uint8_241_0)
    if (bool_uint8_242_0)
    if (!bool_uint8_243_0)
    if (bool_uint8_244_0)
    if (!bool_uint8_245_0)
    if (bool_uint8_246_0)
    if (!bool_uint8_247_0)
    if (bool_uint8_248_0)
    if (bool_uint8_249_0)
    if (!bool_uint8_250_0)
    if (!bool_uint8_251_0)
    if (!bool_uint8_252_0)
    if (!bool_uint8_253_0)
    if (bool_uint8_254_0)
    if (!bool_uint8_255_0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
