#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t bool_uint8_0_0;

    if (size < 1)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&bool_uint8_0_0, &data[i], 1);
    i += 1;


    if (!bool_uint8_0_0)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
