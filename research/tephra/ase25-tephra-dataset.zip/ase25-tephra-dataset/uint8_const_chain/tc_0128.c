#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t uint8_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint8_t uint8_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint8_t uint8_eq_const_9_0;
    uint8_t uint8_eq_const_10_0;
    uint8_t uint8_eq_const_11_0;
    uint8_t uint8_eq_const_12_0;
    uint8_t uint8_eq_const_13_0;
    uint8_t uint8_eq_const_14_0;
    uint8_t uint8_eq_const_15_0;
    uint8_t uint8_eq_const_16_0;
    uint8_t uint8_eq_const_17_0;
    uint8_t uint8_eq_const_18_0;
    uint8_t uint8_eq_const_19_0;
    uint8_t uint8_eq_const_20_0;
    uint8_t uint8_eq_const_21_0;
    uint8_t uint8_eq_const_22_0;
    uint8_t uint8_eq_const_23_0;
    uint8_t uint8_eq_const_24_0;
    uint8_t uint8_eq_const_25_0;
    uint8_t uint8_eq_const_26_0;
    uint8_t uint8_eq_const_27_0;
    uint8_t uint8_eq_const_28_0;
    uint8_t uint8_eq_const_29_0;
    uint8_t uint8_eq_const_30_0;
    uint8_t uint8_eq_const_31_0;
    uint8_t uint8_eq_const_32_0;
    uint8_t uint8_eq_const_33_0;
    uint8_t uint8_eq_const_34_0;
    uint8_t uint8_eq_const_35_0;
    uint8_t uint8_eq_const_36_0;
    uint8_t uint8_eq_const_37_0;
    uint8_t uint8_eq_const_38_0;
    uint8_t uint8_eq_const_39_0;
    uint8_t uint8_eq_const_40_0;
    uint8_t uint8_eq_const_41_0;
    uint8_t uint8_eq_const_42_0;
    uint8_t uint8_eq_const_43_0;
    uint8_t uint8_eq_const_44_0;
    uint8_t uint8_eq_const_45_0;
    uint8_t uint8_eq_const_46_0;
    uint8_t uint8_eq_const_47_0;
    uint8_t uint8_eq_const_48_0;
    uint8_t uint8_eq_const_49_0;
    uint8_t uint8_eq_const_50_0;
    uint8_t uint8_eq_const_51_0;
    uint8_t uint8_eq_const_52_0;
    uint8_t uint8_eq_const_53_0;
    uint8_t uint8_eq_const_54_0;
    uint8_t uint8_eq_const_55_0;
    uint8_t uint8_eq_const_56_0;
    uint8_t uint8_eq_const_57_0;
    uint8_t uint8_eq_const_58_0;
    uint8_t uint8_eq_const_59_0;
    uint8_t uint8_eq_const_60_0;
    uint8_t uint8_eq_const_61_0;
    uint8_t uint8_eq_const_62_0;
    uint8_t uint8_eq_const_63_0;
    uint8_t uint8_eq_const_64_0;
    uint8_t uint8_eq_const_65_0;
    uint8_t uint8_eq_const_66_0;
    uint8_t uint8_eq_const_67_0;
    uint8_t uint8_eq_const_68_0;
    uint8_t uint8_eq_const_69_0;
    uint8_t uint8_eq_const_70_0;
    uint8_t uint8_eq_const_71_0;
    uint8_t uint8_eq_const_72_0;
    uint8_t uint8_eq_const_73_0;
    uint8_t uint8_eq_const_74_0;
    uint8_t uint8_eq_const_75_0;
    uint8_t uint8_eq_const_76_0;
    uint8_t uint8_eq_const_77_0;
    uint8_t uint8_eq_const_78_0;
    uint8_t uint8_eq_const_79_0;
    uint8_t uint8_eq_const_80_0;
    uint8_t uint8_eq_const_81_0;
    uint8_t uint8_eq_const_82_0;
    uint8_t uint8_eq_const_83_0;
    uint8_t uint8_eq_const_84_0;
    uint8_t uint8_eq_const_85_0;
    uint8_t uint8_eq_const_86_0;
    uint8_t uint8_eq_const_87_0;
    uint8_t uint8_eq_const_88_0;
    uint8_t uint8_eq_const_89_0;
    uint8_t uint8_eq_const_90_0;
    uint8_t uint8_eq_const_91_0;
    uint8_t uint8_eq_const_92_0;
    uint8_t uint8_eq_const_93_0;
    uint8_t uint8_eq_const_94_0;
    uint8_t uint8_eq_const_95_0;
    uint8_t uint8_eq_const_96_0;
    uint8_t uint8_eq_const_97_0;
    uint8_t uint8_eq_const_98_0;
    uint8_t uint8_eq_const_99_0;
    uint8_t uint8_eq_const_100_0;
    uint8_t uint8_eq_const_101_0;
    uint8_t uint8_eq_const_102_0;
    uint8_t uint8_eq_const_103_0;
    uint8_t uint8_eq_const_104_0;
    uint8_t uint8_eq_const_105_0;
    uint8_t uint8_eq_const_106_0;
    uint8_t uint8_eq_const_107_0;
    uint8_t uint8_eq_const_108_0;
    uint8_t uint8_eq_const_109_0;
    uint8_t uint8_eq_const_110_0;
    uint8_t uint8_eq_const_111_0;
    uint8_t uint8_eq_const_112_0;
    uint8_t uint8_eq_const_113_0;
    uint8_t uint8_eq_const_114_0;
    uint8_t uint8_eq_const_115_0;
    uint8_t uint8_eq_const_116_0;
    uint8_t uint8_eq_const_117_0;
    uint8_t uint8_eq_const_118_0;
    uint8_t uint8_eq_const_119_0;
    uint8_t uint8_eq_const_120_0;
    uint8_t uint8_eq_const_121_0;
    uint8_t uint8_eq_const_122_0;
    uint8_t uint8_eq_const_123_0;
    uint8_t uint8_eq_const_124_0;
    uint8_t uint8_eq_const_125_0;
    uint8_t uint8_eq_const_126_0;
    uint8_t uint8_eq_const_127_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_20_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_23_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_32_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_37_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_40_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_51_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_57_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_58_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_62_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_63_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_64_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_65_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_66_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_67_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_68_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_69_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_71_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_72_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_73_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_74_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_75_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_76_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_77_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_78_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_79_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_81_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_82_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_83_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_85_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_86_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_87_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_88_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_89_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_90_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_91_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_92_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_94_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_95_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_97_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_98_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_99_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_100_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_101_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_103_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_104_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_105_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_106_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_107_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_108_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_109_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_110_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_111_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_112_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_113_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_114_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_115_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_116_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_117_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_118_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_119_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_120_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_121_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_122_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_123_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_125_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_126_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_127_0, &data[i], 1);
    i += 1;


    if (uint8_eq_const_0_0 == 1)
    if (uint8_eq_const_1_0 == 11)
    if (uint8_eq_const_2_0 == 244)
    if (uint8_eq_const_3_0 == 111)
    if (uint8_eq_const_4_0 == 37)
    if (uint8_eq_const_5_0 == 10)
    if (uint8_eq_const_6_0 == 151)
    if (uint8_eq_const_7_0 == 70)
    if (uint8_eq_const_8_0 == 56)
    if (uint8_eq_const_9_0 == 189)
    if (uint8_eq_const_10_0 == 130)
    if (uint8_eq_const_11_0 == 15)
    if (uint8_eq_const_12_0 == 163)
    if (uint8_eq_const_13_0 == 129)
    if (uint8_eq_const_14_0 == 251)
    if (uint8_eq_const_15_0 == 212)
    if (uint8_eq_const_16_0 == 29)
    if (uint8_eq_const_17_0 == 150)
    if (uint8_eq_const_18_0 == 189)
    if (uint8_eq_const_19_0 == 145)
    if (uint8_eq_const_20_0 == 132)
    if (uint8_eq_const_21_0 == 88)
    if (uint8_eq_const_22_0 == 195)
    if (uint8_eq_const_23_0 == 172)
    if (uint8_eq_const_24_0 == 61)
    if (uint8_eq_const_25_0 == 159)
    if (uint8_eq_const_26_0 == 222)
    if (uint8_eq_const_27_0 == 241)
    if (uint8_eq_const_28_0 == 214)
    if (uint8_eq_const_29_0 == 68)
    if (uint8_eq_const_30_0 == 146)
    if (uint8_eq_const_31_0 == 244)
    if (uint8_eq_const_32_0 == 2)
    if (uint8_eq_const_33_0 == 185)
    if (uint8_eq_const_34_0 == 210)
    if (uint8_eq_const_35_0 == 233)
    if (uint8_eq_const_36_0 == 200)
    if (uint8_eq_const_37_0 == 21)
    if (uint8_eq_const_38_0 == 180)
    if (uint8_eq_const_39_0 == 2)
    if (uint8_eq_const_40_0 == 170)
    if (uint8_eq_const_41_0 == 221)
    if (uint8_eq_const_42_0 == 235)
    if (uint8_eq_const_43_0 == 135)
    if (uint8_eq_const_44_0 == 219)
    if (uint8_eq_const_45_0 == 100)
    if (uint8_eq_const_46_0 == 1)
    if (uint8_eq_const_47_0 == 245)
    if (uint8_eq_const_48_0 == 31)
    if (uint8_eq_const_49_0 == 146)
    if (uint8_eq_const_50_0 == 81)
    if (uint8_eq_const_51_0 == 173)
    if (uint8_eq_const_52_0 == 207)
    if (uint8_eq_const_53_0 == 126)
    if (uint8_eq_const_54_0 == 195)
    if (uint8_eq_const_55_0 == 204)
    if (uint8_eq_const_56_0 == 126)
    if (uint8_eq_const_57_0 == 71)
    if (uint8_eq_const_58_0 == 181)
    if (uint8_eq_const_59_0 == 47)
    if (uint8_eq_const_60_0 == 80)
    if (uint8_eq_const_61_0 == 87)
    if (uint8_eq_const_62_0 == 31)
    if (uint8_eq_const_63_0 == 186)
    if (uint8_eq_const_64_0 == 126)
    if (uint8_eq_const_65_0 == 71)
    if (uint8_eq_const_66_0 == 246)
    if (uint8_eq_const_67_0 == 97)
    if (uint8_eq_const_68_0 == 184)
    if (uint8_eq_const_69_0 == 82)
    if (uint8_eq_const_70_0 == 248)
    if (uint8_eq_const_71_0 == 186)
    if (uint8_eq_const_72_0 == 39)
    if (uint8_eq_const_73_0 == 117)
    if (uint8_eq_const_74_0 == 184)
    if (uint8_eq_const_75_0 == 57)
    if (uint8_eq_const_76_0 == 97)
    if (uint8_eq_const_77_0 == 48)
    if (uint8_eq_const_78_0 == 69)
    if (uint8_eq_const_79_0 == 157)
    if (uint8_eq_const_80_0 == 122)
    if (uint8_eq_const_81_0 == 255)
    if (uint8_eq_const_82_0 == 32)
    if (uint8_eq_const_83_0 == 113)
    if (uint8_eq_const_84_0 == 92)
    if (uint8_eq_const_85_0 == 131)
    if (uint8_eq_const_86_0 == 80)
    if (uint8_eq_const_87_0 == 28)
    if (uint8_eq_const_88_0 == 248)
    if (uint8_eq_const_89_0 == 186)
    if (uint8_eq_const_90_0 == 50)
    if (uint8_eq_const_91_0 == 55)
    if (uint8_eq_const_92_0 == 144)
    if (uint8_eq_const_93_0 == 88)
    if (uint8_eq_const_94_0 == 100)
    if (uint8_eq_const_95_0 == 170)
    if (uint8_eq_const_96_0 == 40)
    if (uint8_eq_const_97_0 == 228)
    if (uint8_eq_const_98_0 == 135)
    if (uint8_eq_const_99_0 == 93)
    if (uint8_eq_const_100_0 == 137)
    if (uint8_eq_const_101_0 == 19)
    if (uint8_eq_const_102_0 == 205)
    if (uint8_eq_const_103_0 == 6)
    if (uint8_eq_const_104_0 == 148)
    if (uint8_eq_const_105_0 == 91)
    if (uint8_eq_const_106_0 == 92)
    if (uint8_eq_const_107_0 == 35)
    if (uint8_eq_const_108_0 == 134)
    if (uint8_eq_const_109_0 == 166)
    if (uint8_eq_const_110_0 == 59)
    if (uint8_eq_const_111_0 == 212)
    if (uint8_eq_const_112_0 == 212)
    if (uint8_eq_const_113_0 == 176)
    if (uint8_eq_const_114_0 == 35)
    if (uint8_eq_const_115_0 == 251)
    if (uint8_eq_const_116_0 == 133)
    if (uint8_eq_const_117_0 == 145)
    if (uint8_eq_const_118_0 == 229)
    if (uint8_eq_const_119_0 == 179)
    if (uint8_eq_const_120_0 == 167)
    if (uint8_eq_const_121_0 == 138)
    if (uint8_eq_const_122_0 == 32)
    if (uint8_eq_const_123_0 == 231)
    if (uint8_eq_const_124_0 == 96)
    if (uint8_eq_const_125_0 == 104)
    if (uint8_eq_const_126_0 == 14)
    if (uint8_eq_const_127_0 == 159)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
