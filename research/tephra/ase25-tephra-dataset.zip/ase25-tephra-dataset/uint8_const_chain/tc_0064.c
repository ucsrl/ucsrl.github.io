#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t uint8_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint8_t uint8_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint8_t uint8_eq_const_9_0;
    uint8_t uint8_eq_const_10_0;
    uint8_t uint8_eq_const_11_0;
    uint8_t uint8_eq_const_12_0;
    uint8_t uint8_eq_const_13_0;
    uint8_t uint8_eq_const_14_0;
    uint8_t uint8_eq_const_15_0;
    uint8_t uint8_eq_const_16_0;
    uint8_t uint8_eq_const_17_0;
    uint8_t uint8_eq_const_18_0;
    uint8_t uint8_eq_const_19_0;
    uint8_t uint8_eq_const_20_0;
    uint8_t uint8_eq_const_21_0;
    uint8_t uint8_eq_const_22_0;
    uint8_t uint8_eq_const_23_0;
    uint8_t uint8_eq_const_24_0;
    uint8_t uint8_eq_const_25_0;
    uint8_t uint8_eq_const_26_0;
    uint8_t uint8_eq_const_27_0;
    uint8_t uint8_eq_const_28_0;
    uint8_t uint8_eq_const_29_0;
    uint8_t uint8_eq_const_30_0;
    uint8_t uint8_eq_const_31_0;
    uint8_t uint8_eq_const_32_0;
    uint8_t uint8_eq_const_33_0;
    uint8_t uint8_eq_const_34_0;
    uint8_t uint8_eq_const_35_0;
    uint8_t uint8_eq_const_36_0;
    uint8_t uint8_eq_const_37_0;
    uint8_t uint8_eq_const_38_0;
    uint8_t uint8_eq_const_39_0;
    uint8_t uint8_eq_const_40_0;
    uint8_t uint8_eq_const_41_0;
    uint8_t uint8_eq_const_42_0;
    uint8_t uint8_eq_const_43_0;
    uint8_t uint8_eq_const_44_0;
    uint8_t uint8_eq_const_45_0;
    uint8_t uint8_eq_const_46_0;
    uint8_t uint8_eq_const_47_0;
    uint8_t uint8_eq_const_48_0;
    uint8_t uint8_eq_const_49_0;
    uint8_t uint8_eq_const_50_0;
    uint8_t uint8_eq_const_51_0;
    uint8_t uint8_eq_const_52_0;
    uint8_t uint8_eq_const_53_0;
    uint8_t uint8_eq_const_54_0;
    uint8_t uint8_eq_const_55_0;
    uint8_t uint8_eq_const_56_0;
    uint8_t uint8_eq_const_57_0;
    uint8_t uint8_eq_const_58_0;
    uint8_t uint8_eq_const_59_0;
    uint8_t uint8_eq_const_60_0;
    uint8_t uint8_eq_const_61_0;
    uint8_t uint8_eq_const_62_0;
    uint8_t uint8_eq_const_63_0;

    if (size < 64)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_20_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_23_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_32_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_37_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_40_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_51_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_57_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_58_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_62_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_63_0, &data[i], 1);
    i += 1;


    if (uint8_eq_const_0_0 == 215)
    if (uint8_eq_const_1_0 == 24)
    if (uint8_eq_const_2_0 == 233)
    if (uint8_eq_const_3_0 == 157)
    if (uint8_eq_const_4_0 == 150)
    if (uint8_eq_const_5_0 == 41)
    if (uint8_eq_const_6_0 == 255)
    if (uint8_eq_const_7_0 == 150)
    if (uint8_eq_const_8_0 == 199)
    if (uint8_eq_const_9_0 == 132)
    if (uint8_eq_const_10_0 == 19)
    if (uint8_eq_const_11_0 == 126)
    if (uint8_eq_const_12_0 == 45)
    if (uint8_eq_const_13_0 == 127)
    if (uint8_eq_const_14_0 == 176)
    if (uint8_eq_const_15_0 == 167)
    if (uint8_eq_const_16_0 == 91)
    if (uint8_eq_const_17_0 == 141)
    if (uint8_eq_const_18_0 == 196)
    if (uint8_eq_const_19_0 == 134)
    if (uint8_eq_const_20_0 == 45)
    if (uint8_eq_const_21_0 == 182)
    if (uint8_eq_const_22_0 == 140)
    if (uint8_eq_const_23_0 == 117)
    if (uint8_eq_const_24_0 == 86)
    if (uint8_eq_const_25_0 == 10)
    if (uint8_eq_const_26_0 == 204)
    if (uint8_eq_const_27_0 == 180)
    if (uint8_eq_const_28_0 == 77)
    if (uint8_eq_const_29_0 == 163)
    if (uint8_eq_const_30_0 == 144)
    if (uint8_eq_const_31_0 == 132)
    if (uint8_eq_const_32_0 == 137)
    if (uint8_eq_const_33_0 == 67)
    if (uint8_eq_const_34_0 == 40)
    if (uint8_eq_const_35_0 == 178)
    if (uint8_eq_const_36_0 == 100)
    if (uint8_eq_const_37_0 == 116)
    if (uint8_eq_const_38_0 == 68)
    if (uint8_eq_const_39_0 == 123)
    if (uint8_eq_const_40_0 == 106)
    if (uint8_eq_const_41_0 == 150)
    if (uint8_eq_const_42_0 == 41)
    if (uint8_eq_const_43_0 == 66)
    if (uint8_eq_const_44_0 == 130)
    if (uint8_eq_const_45_0 == 63)
    if (uint8_eq_const_46_0 == 161)
    if (uint8_eq_const_47_0 == 86)
    if (uint8_eq_const_48_0 == 167)
    if (uint8_eq_const_49_0 == 208)
    if (uint8_eq_const_50_0 == 252)
    if (uint8_eq_const_51_0 == 130)
    if (uint8_eq_const_52_0 == 242)
    if (uint8_eq_const_53_0 == 68)
    if (uint8_eq_const_54_0 == 164)
    if (uint8_eq_const_55_0 == 241)
    if (uint8_eq_const_56_0 == 151)
    if (uint8_eq_const_57_0 == 190)
    if (uint8_eq_const_58_0 == 33)
    if (uint8_eq_const_59_0 == 177)
    if (uint8_eq_const_60_0 == 36)
    if (uint8_eq_const_61_0 == 137)
    if (uint8_eq_const_62_0 == 16)
    if (uint8_eq_const_63_0 == 185)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
