#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t uint8_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint8_t uint8_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint8_t uint8_eq_const_9_0;
    uint8_t uint8_eq_const_10_0;
    uint8_t uint8_eq_const_11_0;
    uint8_t uint8_eq_const_12_0;
    uint8_t uint8_eq_const_13_0;
    uint8_t uint8_eq_const_14_0;
    uint8_t uint8_eq_const_15_0;
    uint8_t uint8_eq_const_16_0;
    uint8_t uint8_eq_const_17_0;
    uint8_t uint8_eq_const_18_0;
    uint8_t uint8_eq_const_19_0;
    uint8_t uint8_eq_const_20_0;
    uint8_t uint8_eq_const_21_0;
    uint8_t uint8_eq_const_22_0;
    uint8_t uint8_eq_const_23_0;
    uint8_t uint8_eq_const_24_0;
    uint8_t uint8_eq_const_25_0;
    uint8_t uint8_eq_const_26_0;
    uint8_t uint8_eq_const_27_0;
    uint8_t uint8_eq_const_28_0;
    uint8_t uint8_eq_const_29_0;
    uint8_t uint8_eq_const_30_0;
    uint8_t uint8_eq_const_31_0;
    uint8_t uint8_eq_const_32_0;
    uint8_t uint8_eq_const_33_0;
    uint8_t uint8_eq_const_34_0;
    uint8_t uint8_eq_const_35_0;
    uint8_t uint8_eq_const_36_0;
    uint8_t uint8_eq_const_37_0;
    uint8_t uint8_eq_const_38_0;
    uint8_t uint8_eq_const_39_0;
    uint8_t uint8_eq_const_40_0;
    uint8_t uint8_eq_const_41_0;
    uint8_t uint8_eq_const_42_0;
    uint8_t uint8_eq_const_43_0;
    uint8_t uint8_eq_const_44_0;
    uint8_t uint8_eq_const_45_0;
    uint8_t uint8_eq_const_46_0;
    uint8_t uint8_eq_const_47_0;
    uint8_t uint8_eq_const_48_0;
    uint8_t uint8_eq_const_49_0;
    uint8_t uint8_eq_const_50_0;
    uint8_t uint8_eq_const_51_0;
    uint8_t uint8_eq_const_52_0;
    uint8_t uint8_eq_const_53_0;
    uint8_t uint8_eq_const_54_0;
    uint8_t uint8_eq_const_55_0;
    uint8_t uint8_eq_const_56_0;
    uint8_t uint8_eq_const_57_0;
    uint8_t uint8_eq_const_58_0;
    uint8_t uint8_eq_const_59_0;
    uint8_t uint8_eq_const_60_0;
    uint8_t uint8_eq_const_61_0;
    uint8_t uint8_eq_const_62_0;
    uint8_t uint8_eq_const_63_0;
    uint8_t uint8_eq_const_64_0;
    uint8_t uint8_eq_const_65_0;
    uint8_t uint8_eq_const_66_0;
    uint8_t uint8_eq_const_67_0;
    uint8_t uint8_eq_const_68_0;
    uint8_t uint8_eq_const_69_0;
    uint8_t uint8_eq_const_70_0;
    uint8_t uint8_eq_const_71_0;
    uint8_t uint8_eq_const_72_0;
    uint8_t uint8_eq_const_73_0;
    uint8_t uint8_eq_const_74_0;
    uint8_t uint8_eq_const_75_0;
    uint8_t uint8_eq_const_76_0;
    uint8_t uint8_eq_const_77_0;
    uint8_t uint8_eq_const_78_0;
    uint8_t uint8_eq_const_79_0;
    uint8_t uint8_eq_const_80_0;
    uint8_t uint8_eq_const_81_0;
    uint8_t uint8_eq_const_82_0;
    uint8_t uint8_eq_const_83_0;
    uint8_t uint8_eq_const_84_0;
    uint8_t uint8_eq_const_85_0;
    uint8_t uint8_eq_const_86_0;
    uint8_t uint8_eq_const_87_0;
    uint8_t uint8_eq_const_88_0;
    uint8_t uint8_eq_const_89_0;
    uint8_t uint8_eq_const_90_0;
    uint8_t uint8_eq_const_91_0;
    uint8_t uint8_eq_const_92_0;
    uint8_t uint8_eq_const_93_0;
    uint8_t uint8_eq_const_94_0;
    uint8_t uint8_eq_const_95_0;
    uint8_t uint8_eq_const_96_0;
    uint8_t uint8_eq_const_97_0;
    uint8_t uint8_eq_const_98_0;
    uint8_t uint8_eq_const_99_0;
    uint8_t uint8_eq_const_100_0;
    uint8_t uint8_eq_const_101_0;
    uint8_t uint8_eq_const_102_0;
    uint8_t uint8_eq_const_103_0;
    uint8_t uint8_eq_const_104_0;
    uint8_t uint8_eq_const_105_0;
    uint8_t uint8_eq_const_106_0;
    uint8_t uint8_eq_const_107_0;
    uint8_t uint8_eq_const_108_0;
    uint8_t uint8_eq_const_109_0;
    uint8_t uint8_eq_const_110_0;
    uint8_t uint8_eq_const_111_0;
    uint8_t uint8_eq_const_112_0;
    uint8_t uint8_eq_const_113_0;
    uint8_t uint8_eq_const_114_0;
    uint8_t uint8_eq_const_115_0;
    uint8_t uint8_eq_const_116_0;
    uint8_t uint8_eq_const_117_0;
    uint8_t uint8_eq_const_118_0;
    uint8_t uint8_eq_const_119_0;
    uint8_t uint8_eq_const_120_0;
    uint8_t uint8_eq_const_121_0;
    uint8_t uint8_eq_const_122_0;
    uint8_t uint8_eq_const_123_0;
    uint8_t uint8_eq_const_124_0;
    uint8_t uint8_eq_const_125_0;
    uint8_t uint8_eq_const_126_0;
    uint8_t uint8_eq_const_127_0;
    uint8_t uint8_eq_const_128_0;
    uint8_t uint8_eq_const_129_0;
    uint8_t uint8_eq_const_130_0;
    uint8_t uint8_eq_const_131_0;
    uint8_t uint8_eq_const_132_0;
    uint8_t uint8_eq_const_133_0;
    uint8_t uint8_eq_const_134_0;
    uint8_t uint8_eq_const_135_0;
    uint8_t uint8_eq_const_136_0;
    uint8_t uint8_eq_const_137_0;
    uint8_t uint8_eq_const_138_0;
    uint8_t uint8_eq_const_139_0;
    uint8_t uint8_eq_const_140_0;
    uint8_t uint8_eq_const_141_0;
    uint8_t uint8_eq_const_142_0;
    uint8_t uint8_eq_const_143_0;
    uint8_t uint8_eq_const_144_0;
    uint8_t uint8_eq_const_145_0;
    uint8_t uint8_eq_const_146_0;
    uint8_t uint8_eq_const_147_0;
    uint8_t uint8_eq_const_148_0;
    uint8_t uint8_eq_const_149_0;
    uint8_t uint8_eq_const_150_0;
    uint8_t uint8_eq_const_151_0;
    uint8_t uint8_eq_const_152_0;
    uint8_t uint8_eq_const_153_0;
    uint8_t uint8_eq_const_154_0;
    uint8_t uint8_eq_const_155_0;
    uint8_t uint8_eq_const_156_0;
    uint8_t uint8_eq_const_157_0;
    uint8_t uint8_eq_const_158_0;
    uint8_t uint8_eq_const_159_0;
    uint8_t uint8_eq_const_160_0;
    uint8_t uint8_eq_const_161_0;
    uint8_t uint8_eq_const_162_0;
    uint8_t uint8_eq_const_163_0;
    uint8_t uint8_eq_const_164_0;
    uint8_t uint8_eq_const_165_0;
    uint8_t uint8_eq_const_166_0;
    uint8_t uint8_eq_const_167_0;
    uint8_t uint8_eq_const_168_0;
    uint8_t uint8_eq_const_169_0;
    uint8_t uint8_eq_const_170_0;
    uint8_t uint8_eq_const_171_0;
    uint8_t uint8_eq_const_172_0;
    uint8_t uint8_eq_const_173_0;
    uint8_t uint8_eq_const_174_0;
    uint8_t uint8_eq_const_175_0;
    uint8_t uint8_eq_const_176_0;
    uint8_t uint8_eq_const_177_0;
    uint8_t uint8_eq_const_178_0;
    uint8_t uint8_eq_const_179_0;
    uint8_t uint8_eq_const_180_0;
    uint8_t uint8_eq_const_181_0;
    uint8_t uint8_eq_const_182_0;
    uint8_t uint8_eq_const_183_0;
    uint8_t uint8_eq_const_184_0;
    uint8_t uint8_eq_const_185_0;
    uint8_t uint8_eq_const_186_0;
    uint8_t uint8_eq_const_187_0;
    uint8_t uint8_eq_const_188_0;
    uint8_t uint8_eq_const_189_0;
    uint8_t uint8_eq_const_190_0;
    uint8_t uint8_eq_const_191_0;
    uint8_t uint8_eq_const_192_0;
    uint8_t uint8_eq_const_193_0;
    uint8_t uint8_eq_const_194_0;
    uint8_t uint8_eq_const_195_0;
    uint8_t uint8_eq_const_196_0;
    uint8_t uint8_eq_const_197_0;
    uint8_t uint8_eq_const_198_0;
    uint8_t uint8_eq_const_199_0;
    uint8_t uint8_eq_const_200_0;
    uint8_t uint8_eq_const_201_0;
    uint8_t uint8_eq_const_202_0;
    uint8_t uint8_eq_const_203_0;
    uint8_t uint8_eq_const_204_0;
    uint8_t uint8_eq_const_205_0;
    uint8_t uint8_eq_const_206_0;
    uint8_t uint8_eq_const_207_0;
    uint8_t uint8_eq_const_208_0;
    uint8_t uint8_eq_const_209_0;
    uint8_t uint8_eq_const_210_0;
    uint8_t uint8_eq_const_211_0;
    uint8_t uint8_eq_const_212_0;
    uint8_t uint8_eq_const_213_0;
    uint8_t uint8_eq_const_214_0;
    uint8_t uint8_eq_const_215_0;
    uint8_t uint8_eq_const_216_0;
    uint8_t uint8_eq_const_217_0;
    uint8_t uint8_eq_const_218_0;
    uint8_t uint8_eq_const_219_0;
    uint8_t uint8_eq_const_220_0;
    uint8_t uint8_eq_const_221_0;
    uint8_t uint8_eq_const_222_0;
    uint8_t uint8_eq_const_223_0;
    uint8_t uint8_eq_const_224_0;
    uint8_t uint8_eq_const_225_0;
    uint8_t uint8_eq_const_226_0;
    uint8_t uint8_eq_const_227_0;
    uint8_t uint8_eq_const_228_0;
    uint8_t uint8_eq_const_229_0;
    uint8_t uint8_eq_const_230_0;
    uint8_t uint8_eq_const_231_0;
    uint8_t uint8_eq_const_232_0;
    uint8_t uint8_eq_const_233_0;
    uint8_t uint8_eq_const_234_0;
    uint8_t uint8_eq_const_235_0;
    uint8_t uint8_eq_const_236_0;
    uint8_t uint8_eq_const_237_0;
    uint8_t uint8_eq_const_238_0;
    uint8_t uint8_eq_const_239_0;
    uint8_t uint8_eq_const_240_0;
    uint8_t uint8_eq_const_241_0;
    uint8_t uint8_eq_const_242_0;
    uint8_t uint8_eq_const_243_0;
    uint8_t uint8_eq_const_244_0;
    uint8_t uint8_eq_const_245_0;
    uint8_t uint8_eq_const_246_0;
    uint8_t uint8_eq_const_247_0;
    uint8_t uint8_eq_const_248_0;
    uint8_t uint8_eq_const_249_0;
    uint8_t uint8_eq_const_250_0;
    uint8_t uint8_eq_const_251_0;
    uint8_t uint8_eq_const_252_0;
    uint8_t uint8_eq_const_253_0;
    uint8_t uint8_eq_const_254_0;
    uint8_t uint8_eq_const_255_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_11_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_13_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_20_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_23_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_32_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_37_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_38_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_40_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_44_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_46_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_50_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_51_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_57_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_58_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_59_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_62_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_63_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_64_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_65_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_66_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_67_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_68_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_69_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_71_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_72_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_73_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_74_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_75_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_76_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_77_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_78_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_79_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_81_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_82_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_83_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_85_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_86_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_87_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_88_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_89_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_90_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_91_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_92_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_94_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_95_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_97_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_98_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_99_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_100_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_101_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_103_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_104_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_105_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_106_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_107_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_108_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_109_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_110_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_111_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_112_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_113_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_114_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_115_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_116_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_117_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_118_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_119_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_120_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_121_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_122_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_123_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_125_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_126_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_127_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_128_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_129_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_130_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_131_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_132_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_133_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_134_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_135_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_136_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_137_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_138_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_139_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_140_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_141_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_142_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_143_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_144_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_145_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_146_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_147_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_148_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_149_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_150_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_151_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_152_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_153_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_154_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_155_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_156_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_157_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_158_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_159_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_160_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_161_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_162_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_163_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_164_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_165_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_166_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_167_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_168_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_169_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_170_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_171_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_172_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_173_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_174_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_175_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_176_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_177_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_178_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_179_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_180_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_181_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_182_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_183_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_184_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_185_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_186_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_187_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_188_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_189_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_190_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_191_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_192_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_193_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_194_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_195_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_196_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_197_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_198_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_199_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_200_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_201_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_202_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_203_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_204_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_205_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_206_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_207_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_208_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_209_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_210_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_211_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_212_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_213_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_214_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_215_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_216_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_217_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_218_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_219_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_220_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_221_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_222_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_223_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_224_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_225_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_226_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_227_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_228_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_229_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_230_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_231_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_232_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_233_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_234_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_235_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_236_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_237_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_238_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_239_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_240_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_241_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_242_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_243_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_244_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_245_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_246_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_247_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_248_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_249_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_250_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_251_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_252_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_253_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_254_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_255_0, &data[i], 1);
    i += 1;


    if (uint8_eq_const_0_0 == 160)
    if (uint8_eq_const_1_0 == 19)
    if (uint8_eq_const_2_0 == 244)
    if (uint8_eq_const_3_0 == 192)
    if (uint8_eq_const_4_0 == 119)
    if (uint8_eq_const_5_0 == 175)
    if (uint8_eq_const_6_0 == 1)
    if (uint8_eq_const_7_0 == 128)
    if (uint8_eq_const_8_0 == 232)
    if (uint8_eq_const_9_0 == 194)
    if (uint8_eq_const_10_0 == 233)
    if (uint8_eq_const_11_0 == 254)
    if (uint8_eq_const_12_0 == 124)
    if (uint8_eq_const_13_0 == 98)
    if (uint8_eq_const_14_0 == 183)
    if (uint8_eq_const_15_0 == 159)
    if (uint8_eq_const_16_0 == 188)
    if (uint8_eq_const_17_0 == 158)
    if (uint8_eq_const_18_0 == 83)
    if (uint8_eq_const_19_0 == 222)
    if (uint8_eq_const_20_0 == 145)
    if (uint8_eq_const_21_0 == 127)
    if (uint8_eq_const_22_0 == 47)
    if (uint8_eq_const_23_0 == 233)
    if (uint8_eq_const_24_0 == 192)
    if (uint8_eq_const_25_0 == 51)
    if (uint8_eq_const_26_0 == 110)
    if (uint8_eq_const_27_0 == 206)
    if (uint8_eq_const_28_0 == 79)
    if (uint8_eq_const_29_0 == 72)
    if (uint8_eq_const_30_0 == 188)
    if (uint8_eq_const_31_0 == 137)
    if (uint8_eq_const_32_0 == 0)
    if (uint8_eq_const_33_0 == 180)
    if (uint8_eq_const_34_0 == 215)
    if (uint8_eq_const_35_0 == 75)
    if (uint8_eq_const_36_0 == 214)
    if (uint8_eq_const_37_0 == 235)
    if (uint8_eq_const_38_0 == 164)
    if (uint8_eq_const_39_0 == 105)
    if (uint8_eq_const_40_0 == 128)
    if (uint8_eq_const_41_0 == 21)
    if (uint8_eq_const_42_0 == 32)
    if (uint8_eq_const_43_0 == 126)
    if (uint8_eq_const_44_0 == 223)
    if (uint8_eq_const_45_0 == 43)
    if (uint8_eq_const_46_0 == 188)
    if (uint8_eq_const_47_0 == 107)
    if (uint8_eq_const_48_0 == 77)
    if (uint8_eq_const_49_0 == 145)
    if (uint8_eq_const_50_0 == 209)
    if (uint8_eq_const_51_0 == 255)
    if (uint8_eq_const_52_0 == 68)
    if (uint8_eq_const_53_0 == 118)
    if (uint8_eq_const_54_0 == 171)
    if (uint8_eq_const_55_0 == 91)
    if (uint8_eq_const_56_0 == 248)
    if (uint8_eq_const_57_0 == 70)
    if (uint8_eq_const_58_0 == 78)
    if (uint8_eq_const_59_0 == 81)
    if (uint8_eq_const_60_0 == 250)
    if (uint8_eq_const_61_0 == 39)
    if (uint8_eq_const_62_0 == 113)
    if (uint8_eq_const_63_0 == 59)
    if (uint8_eq_const_64_0 == 159)
    if (uint8_eq_const_65_0 == 149)
    if (uint8_eq_const_66_0 == 117)
    if (uint8_eq_const_67_0 == 23)
    if (uint8_eq_const_68_0 == 197)
    if (uint8_eq_const_69_0 == 220)
    if (uint8_eq_const_70_0 == 4)
    if (uint8_eq_const_71_0 == 18)
    if (uint8_eq_const_72_0 == 245)
    if (uint8_eq_const_73_0 == 123)
    if (uint8_eq_const_74_0 == 198)
    if (uint8_eq_const_75_0 == 248)
    if (uint8_eq_const_76_0 == 56)
    if (uint8_eq_const_77_0 == 24)
    if (uint8_eq_const_78_0 == 38)
    if (uint8_eq_const_79_0 == 89)
    if (uint8_eq_const_80_0 == 233)
    if (uint8_eq_const_81_0 == 24)
    if (uint8_eq_const_82_0 == 115)
    if (uint8_eq_const_83_0 == 191)
    if (uint8_eq_const_84_0 == 194)
    if (uint8_eq_const_85_0 == 154)
    if (uint8_eq_const_86_0 == 193)
    if (uint8_eq_const_87_0 == 159)
    if (uint8_eq_const_88_0 == 218)
    if (uint8_eq_const_89_0 == 4)
    if (uint8_eq_const_90_0 == 187)
    if (uint8_eq_const_91_0 == 56)
    if (uint8_eq_const_92_0 == 214)
    if (uint8_eq_const_93_0 == 36)
    if (uint8_eq_const_94_0 == 109)
    if (uint8_eq_const_95_0 == 32)
    if (uint8_eq_const_96_0 == 137)
    if (uint8_eq_const_97_0 == 67)
    if (uint8_eq_const_98_0 == 71)
    if (uint8_eq_const_99_0 == 183)
    if (uint8_eq_const_100_0 == 117)
    if (uint8_eq_const_101_0 == 155)
    if (uint8_eq_const_102_0 == 244)
    if (uint8_eq_const_103_0 == 75)
    if (uint8_eq_const_104_0 == 24)
    if (uint8_eq_const_105_0 == 220)
    if (uint8_eq_const_106_0 == 156)
    if (uint8_eq_const_107_0 == 111)
    if (uint8_eq_const_108_0 == 161)
    if (uint8_eq_const_109_0 == 178)
    if (uint8_eq_const_110_0 == 232)
    if (uint8_eq_const_111_0 == 120)
    if (uint8_eq_const_112_0 == 229)
    if (uint8_eq_const_113_0 == 119)
    if (uint8_eq_const_114_0 == 180)
    if (uint8_eq_const_115_0 == 240)
    if (uint8_eq_const_116_0 == 133)
    if (uint8_eq_const_117_0 == 151)
    if (uint8_eq_const_118_0 == 177)
    if (uint8_eq_const_119_0 == 88)
    if (uint8_eq_const_120_0 == 5)
    if (uint8_eq_const_121_0 == 129)
    if (uint8_eq_const_122_0 == 92)
    if (uint8_eq_const_123_0 == 111)
    if (uint8_eq_const_124_0 == 90)
    if (uint8_eq_const_125_0 == 73)
    if (uint8_eq_const_126_0 == 156)
    if (uint8_eq_const_127_0 == 212)
    if (uint8_eq_const_128_0 == 164)
    if (uint8_eq_const_129_0 == 181)
    if (uint8_eq_const_130_0 == 246)
    if (uint8_eq_const_131_0 == 196)
    if (uint8_eq_const_132_0 == 85)
    if (uint8_eq_const_133_0 == 148)
    if (uint8_eq_const_134_0 == 216)
    if (uint8_eq_const_135_0 == 105)
    if (uint8_eq_const_136_0 == 158)
    if (uint8_eq_const_137_0 == 19)
    if (uint8_eq_const_138_0 == 168)
    if (uint8_eq_const_139_0 == 45)
    if (uint8_eq_const_140_0 == 30)
    if (uint8_eq_const_141_0 == 216)
    if (uint8_eq_const_142_0 == 93)
    if (uint8_eq_const_143_0 == 51)
    if (uint8_eq_const_144_0 == 10)
    if (uint8_eq_const_145_0 == 152)
    if (uint8_eq_const_146_0 == 36)
    if (uint8_eq_const_147_0 == 69)
    if (uint8_eq_const_148_0 == 163)
    if (uint8_eq_const_149_0 == 19)
    if (uint8_eq_const_150_0 == 59)
    if (uint8_eq_const_151_0 == 52)
    if (uint8_eq_const_152_0 == 154)
    if (uint8_eq_const_153_0 == 69)
    if (uint8_eq_const_154_0 == 144)
    if (uint8_eq_const_155_0 == 207)
    if (uint8_eq_const_156_0 == 76)
    if (uint8_eq_const_157_0 == 228)
    if (uint8_eq_const_158_0 == 197)
    if (uint8_eq_const_159_0 == 149)
    if (uint8_eq_const_160_0 == 244)
    if (uint8_eq_const_161_0 == 81)
    if (uint8_eq_const_162_0 == 61)
    if (uint8_eq_const_163_0 == 41)
    if (uint8_eq_const_164_0 == 219)
    if (uint8_eq_const_165_0 == 99)
    if (uint8_eq_const_166_0 == 142)
    if (uint8_eq_const_167_0 == 222)
    if (uint8_eq_const_168_0 == 112)
    if (uint8_eq_const_169_0 == 136)
    if (uint8_eq_const_170_0 == 36)
    if (uint8_eq_const_171_0 == 151)
    if (uint8_eq_const_172_0 == 116)
    if (uint8_eq_const_173_0 == 35)
    if (uint8_eq_const_174_0 == 63)
    if (uint8_eq_const_175_0 == 108)
    if (uint8_eq_const_176_0 == 243)
    if (uint8_eq_const_177_0 == 49)
    if (uint8_eq_const_178_0 == 112)
    if (uint8_eq_const_179_0 == 197)
    if (uint8_eq_const_180_0 == 179)
    if (uint8_eq_const_181_0 == 161)
    if (uint8_eq_const_182_0 == 168)
    if (uint8_eq_const_183_0 == 158)
    if (uint8_eq_const_184_0 == 175)
    if (uint8_eq_const_185_0 == 12)
    if (uint8_eq_const_186_0 == 123)
    if (uint8_eq_const_187_0 == 22)
    if (uint8_eq_const_188_0 == 185)
    if (uint8_eq_const_189_0 == 255)
    if (uint8_eq_const_190_0 == 163)
    if (uint8_eq_const_191_0 == 133)
    if (uint8_eq_const_192_0 == 17)
    if (uint8_eq_const_193_0 == 55)
    if (uint8_eq_const_194_0 == 11)
    if (uint8_eq_const_195_0 == 175)
    if (uint8_eq_const_196_0 == 137)
    if (uint8_eq_const_197_0 == 220)
    if (uint8_eq_const_198_0 == 155)
    if (uint8_eq_const_199_0 == 12)
    if (uint8_eq_const_200_0 == 60)
    if (uint8_eq_const_201_0 == 6)
    if (uint8_eq_const_202_0 == 178)
    if (uint8_eq_const_203_0 == 80)
    if (uint8_eq_const_204_0 == 67)
    if (uint8_eq_const_205_0 == 130)
    if (uint8_eq_const_206_0 == 224)
    if (uint8_eq_const_207_0 == 230)
    if (uint8_eq_const_208_0 == 170)
    if (uint8_eq_const_209_0 == 44)
    if (uint8_eq_const_210_0 == 162)
    if (uint8_eq_const_211_0 == 111)
    if (uint8_eq_const_212_0 == 247)
    if (uint8_eq_const_213_0 == 233)
    if (uint8_eq_const_214_0 == 19)
    if (uint8_eq_const_215_0 == 180)
    if (uint8_eq_const_216_0 == 248)
    if (uint8_eq_const_217_0 == 186)
    if (uint8_eq_const_218_0 == 88)
    if (uint8_eq_const_219_0 == 34)
    if (uint8_eq_const_220_0 == 39)
    if (uint8_eq_const_221_0 == 40)
    if (uint8_eq_const_222_0 == 63)
    if (uint8_eq_const_223_0 == 48)
    if (uint8_eq_const_224_0 == 238)
    if (uint8_eq_const_225_0 == 198)
    if (uint8_eq_const_226_0 == 229)
    if (uint8_eq_const_227_0 == 202)
    if (uint8_eq_const_228_0 == 54)
    if (uint8_eq_const_229_0 == 91)
    if (uint8_eq_const_230_0 == 145)
    if (uint8_eq_const_231_0 == 90)
    if (uint8_eq_const_232_0 == 59)
    if (uint8_eq_const_233_0 == 215)
    if (uint8_eq_const_234_0 == 204)
    if (uint8_eq_const_235_0 == 146)
    if (uint8_eq_const_236_0 == 87)
    if (uint8_eq_const_237_0 == 32)
    if (uint8_eq_const_238_0 == 169)
    if (uint8_eq_const_239_0 == 233)
    if (uint8_eq_const_240_0 == 133)
    if (uint8_eq_const_241_0 == 83)
    if (uint8_eq_const_242_0 == 165)
    if (uint8_eq_const_243_0 == 45)
    if (uint8_eq_const_244_0 == 187)
    if (uint8_eq_const_245_0 == 35)
    if (uint8_eq_const_246_0 == 241)
    if (uint8_eq_const_247_0 == 123)
    if (uint8_eq_const_248_0 == 187)
    if (uint8_eq_const_249_0 == 148)
    if (uint8_eq_const_250_0 == 13)
    if (uint8_eq_const_251_0 == 111)
    if (uint8_eq_const_252_0 == 15)
    if (uint8_eq_const_253_0 == 109)
    if (uint8_eq_const_254_0 == 142)
    if (uint8_eq_const_255_0 == 81)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
