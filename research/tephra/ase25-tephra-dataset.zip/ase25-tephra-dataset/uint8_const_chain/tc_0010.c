#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t uint8_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint8_t uint8_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint8_t uint8_eq_const_9_0;

    if (size < 10)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_9_0, &data[i], 1);
    i += 1;


    if (uint8_eq_const_0_0 == 96)
    if (uint8_eq_const_1_0 == 220)
    if (uint8_eq_const_2_0 == 178)
    if (uint8_eq_const_3_0 == 40)
    if (uint8_eq_const_4_0 == 204)
    if (uint8_eq_const_5_0 == 185)
    if (uint8_eq_const_6_0 == 203)
    if (uint8_eq_const_7_0 == 210)
    if (uint8_eq_const_8_0 == 217)
    if (uint8_eq_const_9_0 == 252)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
