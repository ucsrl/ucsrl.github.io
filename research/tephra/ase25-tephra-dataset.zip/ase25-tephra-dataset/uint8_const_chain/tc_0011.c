#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    uint8_t uint8_eq_const_0_0;
    uint8_t uint8_eq_const_1_0;
    uint8_t uint8_eq_const_2_0;
    uint8_t uint8_eq_const_3_0;
    uint8_t uint8_eq_const_4_0;
    uint8_t uint8_eq_const_5_0;
    uint8_t uint8_eq_const_6_0;
    uint8_t uint8_eq_const_7_0;
    uint8_t uint8_eq_const_8_0;
    uint8_t uint8_eq_const_9_0;
    uint8_t uint8_eq_const_10_0;

    if (size < 11)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&uint8_eq_const_0_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&uint8_eq_const_10_0, &data[i], 1);
    i += 1;


    if (uint8_eq_const_0_0 == 186)
    if (uint8_eq_const_1_0 == 174)
    if (uint8_eq_const_2_0 == 79)
    if (uint8_eq_const_3_0 == 70)
    if (uint8_eq_const_4_0 == 170)
    if (uint8_eq_const_5_0 == 231)
    if (uint8_eq_const_6_0 == 94)
    if (uint8_eq_const_7_0 == 70)
    if (uint8_eq_const_8_0 == 118)
    if (uint8_eq_const_9_0 == 200)
    if (uint8_eq_const_10_0 == 235)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
