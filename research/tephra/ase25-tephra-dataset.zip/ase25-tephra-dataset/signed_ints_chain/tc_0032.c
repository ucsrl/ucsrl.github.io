#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int16_t int16_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int8_t int8_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int16_t int16_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int64_t int64_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int16_t int16_eq_const_14_0;
    int16_t int16_eq_const_15_0;
    int64_t int64_eq_const_16_0;
    int8_t int8_eq_const_17_0;
    int32_t int32_eq_const_18_0;
    int8_t int8_eq_const_19_0;
    int32_t int32_eq_const_20_0;
    int32_t int32_eq_const_21_0;
    int64_t int64_eq_const_22_0;
    int32_t int32_eq_const_23_0;
    int16_t int16_eq_const_24_0;
    int8_t int8_eq_const_25_0;
    int32_t int32_eq_const_26_0;
    int64_t int64_eq_const_27_0;
    int8_t int8_eq_const_28_0;
    int32_t int32_eq_const_29_0;
    int64_t int64_eq_const_30_0;
    int64_t int64_eq_const_31_0;

    if (size < 134)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int16_eq_const_0_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_7_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_19_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_27_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_28_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_30_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_31_0, &data[i], 8);
    i += 8;


    if (int16_eq_const_0_0 == -15577)
    if (int64_eq_const_1_0 == 4879324748408446700)
    if (int64_eq_const_2_0 == -4786257427206772636)
    if (int8_eq_const_3_0 == -79)
    if (int16_eq_const_4_0 == -22007)
    if (int16_eq_const_5_0 == -20471)
    if (int64_eq_const_6_0 == -2462342345743291779)
    if (int16_eq_const_7_0 == 15467)
    if (int32_eq_const_8_0 == 826882453)
    if (int16_eq_const_9_0 == 7039)
    if (int8_eq_const_10_0 == 48)
    if (int32_eq_const_11_0 == 1360858977)
    if (int64_eq_const_12_0 == 4797314139920039668)
    if (int64_eq_const_13_0 == 7420119641802241843)
    if (int16_eq_const_14_0 == -21502)
    if (int16_eq_const_15_0 == -14845)
    if (int64_eq_const_16_0 == 1402913295322780842)
    if (int8_eq_const_17_0 == -39)
    if (int32_eq_const_18_0 == 546166683)
    if (int8_eq_const_19_0 == 17)
    if (int32_eq_const_20_0 == -1890433716)
    if (int32_eq_const_21_0 == -789223984)
    if (int64_eq_const_22_0 == -8219085301115750335)
    if (int32_eq_const_23_0 == 2066037668)
    if (int16_eq_const_24_0 == -1018)
    if (int8_eq_const_25_0 == -13)
    if (int32_eq_const_26_0 == -1111161327)
    if (int64_eq_const_27_0 == -7895754340749160156)
    if (int8_eq_const_28_0 == 71)
    if (int32_eq_const_29_0 == -1219477569)
    if (int64_eq_const_30_0 == -643641949724426732)
    if (int64_eq_const_31_0 == 3500520392002252439)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
