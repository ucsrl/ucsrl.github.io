#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int64_t int64_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int8_t int8_eq_const_4_0;
    int16_t int16_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int8_t int8_eq_const_10_0;
    int16_t int16_eq_const_11_0;
    int8_t int8_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    int32_t int32_eq_const_14_0;
    int64_t int64_eq_const_15_0;
    int16_t int16_eq_const_16_0;
    int8_t int8_eq_const_17_0;
    int32_t int32_eq_const_18_0;
    int32_t int32_eq_const_19_0;
    int64_t int64_eq_const_20_0;
    int32_t int32_eq_const_21_0;
    int16_t int16_eq_const_22_0;
    int32_t int32_eq_const_23_0;
    int8_t int8_eq_const_24_0;
    int16_t int16_eq_const_25_0;
    int32_t int32_eq_const_26_0;
    int16_t int16_eq_const_27_0;
    int16_t int16_eq_const_28_0;
    int32_t int32_eq_const_29_0;
    int8_t int8_eq_const_30_0;
    int8_t int8_eq_const_31_0;
    int16_t int16_eq_const_32_0;
    int16_t int16_eq_const_33_0;
    int32_t int32_eq_const_34_0;
    int32_t int32_eq_const_35_0;
    int32_t int32_eq_const_36_0;
    int16_t int16_eq_const_37_0;
    int16_t int16_eq_const_38_0;
    int8_t int8_eq_const_39_0;
    int64_t int64_eq_const_40_0;
    int16_t int16_eq_const_41_0;
    int8_t int8_eq_const_42_0;
    int8_t int8_eq_const_43_0;
    int16_t int16_eq_const_44_0;
    int32_t int32_eq_const_45_0;
    int64_t int64_eq_const_46_0;
    int32_t int32_eq_const_47_0;
    int8_t int8_eq_const_48_0;
    int16_t int16_eq_const_49_0;
    int32_t int32_eq_const_50_0;
    int64_t int64_eq_const_51_0;
    int16_t int16_eq_const_52_0;
    int16_t int16_eq_const_53_0;
    int16_t int16_eq_const_54_0;
    int8_t int8_eq_const_55_0;
    int64_t int64_eq_const_56_0;
    int16_t int16_eq_const_57_0;
    int16_t int16_eq_const_58_0;
    int64_t int64_eq_const_59_0;
    int64_t int64_eq_const_60_0;
    int16_t int16_eq_const_61_0;
    int64_t int64_eq_const_62_0;
    int16_t int16_eq_const_63_0;
    int8_t int8_eq_const_64_0;
    int8_t int8_eq_const_65_0;
    int64_t int64_eq_const_66_0;
    int8_t int8_eq_const_67_0;
    int64_t int64_eq_const_68_0;
    int32_t int32_eq_const_69_0;
    int8_t int8_eq_const_70_0;
    int8_t int8_eq_const_71_0;
    int64_t int64_eq_const_72_0;
    int32_t int32_eq_const_73_0;
    int64_t int64_eq_const_74_0;
    int8_t int8_eq_const_75_0;
    int16_t int16_eq_const_76_0;
    int16_t int16_eq_const_77_0;
    int32_t int32_eq_const_78_0;
    int32_t int32_eq_const_79_0;
    int8_t int8_eq_const_80_0;
    int64_t int64_eq_const_81_0;
    int16_t int16_eq_const_82_0;
    int64_t int64_eq_const_83_0;
    int32_t int32_eq_const_84_0;
    int64_t int64_eq_const_85_0;
    int32_t int32_eq_const_86_0;
    int32_t int32_eq_const_87_0;
    int16_t int16_eq_const_88_0;
    int8_t int8_eq_const_89_0;
    int8_t int8_eq_const_90_0;
    int16_t int16_eq_const_91_0;
    int64_t int64_eq_const_92_0;
    int32_t int32_eq_const_93_0;
    int64_t int64_eq_const_94_0;
    int64_t int64_eq_const_95_0;
    int8_t int8_eq_const_96_0;
    int32_t int32_eq_const_97_0;
    int32_t int32_eq_const_98_0;
    int8_t int8_eq_const_99_0;
    int32_t int32_eq_const_100_0;
    int32_t int32_eq_const_101_0;
    int32_t int32_eq_const_102_0;
    int16_t int16_eq_const_103_0;
    int32_t int32_eq_const_104_0;
    int16_t int16_eq_const_105_0;
    int16_t int16_eq_const_106_0;
    int16_t int16_eq_const_107_0;
    int8_t int8_eq_const_108_0;
    int32_t int32_eq_const_109_0;
    int8_t int8_eq_const_110_0;
    int16_t int16_eq_const_111_0;
    int32_t int32_eq_const_112_0;
    int64_t int64_eq_const_113_0;
    int16_t int16_eq_const_114_0;
    int64_t int64_eq_const_115_0;
    int32_t int32_eq_const_116_0;
    int64_t int64_eq_const_117_0;
    int8_t int8_eq_const_118_0;
    int8_t int8_eq_const_119_0;
    int64_t int64_eq_const_120_0;
    int32_t int32_eq_const_121_0;
    int16_t int16_eq_const_122_0;
    int8_t int8_eq_const_123_0;
    int16_t int16_eq_const_124_0;
    int8_t int8_eq_const_125_0;
    int64_t int64_eq_const_126_0;
    int8_t int8_eq_const_127_0;

    if (size < 456)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_2_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_5_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_10_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_12_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_15_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_16_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_17_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_22_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_24_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_25_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_31_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_32_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_33_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_37_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_39_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_41_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_43_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_44_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_45_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_46_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_49_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_52_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_53_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_54_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_56_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_57_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_58_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_60_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_61_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_62_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_63_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_64_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_65_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_66_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_67_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_68_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_69_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_71_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_73_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_74_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_75_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_76_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_77_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_78_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_79_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_81_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_82_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_83_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_84_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_86_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_87_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_88_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_89_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_90_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_91_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_92_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_93_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_94_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_95_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_97_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_98_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_99_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_100_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_101_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_102_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_103_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_104_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_105_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_106_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_107_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_108_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_109_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_110_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_111_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_112_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_113_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_114_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_115_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_116_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_117_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_118_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_119_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_120_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_121_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_122_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_123_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_124_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_125_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_126_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_127_0, &data[i], 1);
    i += 1;


    if (int64_eq_const_0_0 == 3814892950683460437)
    if (int16_eq_const_1_0 == 9270)
    if (int64_eq_const_2_0 == -4262445669474496681)
    if (int32_eq_const_3_0 == 1087438665)
    if (int8_eq_const_4_0 == 87)
    if (int16_eq_const_5_0 == 29637)
    if (int32_eq_const_6_0 == -1290737394)
    if (int64_eq_const_7_0 == -1460869622447806761)
    if (int32_eq_const_8_0 == -2114508285)
    if (int16_eq_const_9_0 == -12379)
    if (int8_eq_const_10_0 == 73)
    if (int16_eq_const_11_0 == -2493)
    if (int8_eq_const_12_0 == -38)
    if (int16_eq_const_13_0 == 28985)
    if (int32_eq_const_14_0 == -2094086943)
    if (int64_eq_const_15_0 == 1570489834612602086)
    if (int16_eq_const_16_0 == -2373)
    if (int8_eq_const_17_0 == 61)
    if (int32_eq_const_18_0 == 769257569)
    if (int32_eq_const_19_0 == 993859772)
    if (int64_eq_const_20_0 == 227443220752854241)
    if (int32_eq_const_21_0 == -1644077841)
    if (int16_eq_const_22_0 == 18427)
    if (int32_eq_const_23_0 == -316237697)
    if (int8_eq_const_24_0 == 112)
    if (int16_eq_const_25_0 == -27247)
    if (int32_eq_const_26_0 == 1868639220)
    if (int16_eq_const_27_0 == -26445)
    if (int16_eq_const_28_0 == 2423)
    if (int32_eq_const_29_0 == 8780997)
    if (int8_eq_const_30_0 == 51)
    if (int8_eq_const_31_0 == 82)
    if (int16_eq_const_32_0 == 4729)
    if (int16_eq_const_33_0 == 13270)
    if (int32_eq_const_34_0 == -801476172)
    if (int32_eq_const_35_0 == 1025777574)
    if (int32_eq_const_36_0 == 1975966947)
    if (int16_eq_const_37_0 == -21280)
    if (int16_eq_const_38_0 == -29770)
    if (int8_eq_const_39_0 == -33)
    if (int64_eq_const_40_0 == -2144756746907686547)
    if (int16_eq_const_41_0 == 21169)
    if (int8_eq_const_42_0 == 76)
    if (int8_eq_const_43_0 == -20)
    if (int16_eq_const_44_0 == 10765)
    if (int32_eq_const_45_0 == -582887441)
    if (int64_eq_const_46_0 == 3809656850550825310)
    if (int32_eq_const_47_0 == -1212025929)
    if (int8_eq_const_48_0 == -94)
    if (int16_eq_const_49_0 == 21308)
    if (int32_eq_const_50_0 == 1849387230)
    if (int64_eq_const_51_0 == -3338468545829419979)
    if (int16_eq_const_52_0 == 16772)
    if (int16_eq_const_53_0 == 13148)
    if (int16_eq_const_54_0 == 15872)
    if (int8_eq_const_55_0 == 8)
    if (int64_eq_const_56_0 == 3549836825774777071)
    if (int16_eq_const_57_0 == -13701)
    if (int16_eq_const_58_0 == -15097)
    if (int64_eq_const_59_0 == -1748036141123859142)
    if (int64_eq_const_60_0 == -6194232596837231627)
    if (int16_eq_const_61_0 == 27607)
    if (int64_eq_const_62_0 == 6011579916620775101)
    if (int16_eq_const_63_0 == 6452)
    if (int8_eq_const_64_0 == 99)
    if (int8_eq_const_65_0 == -67)
    if (int64_eq_const_66_0 == 2554348323744037863)
    if (int8_eq_const_67_0 == -8)
    if (int64_eq_const_68_0 == 1720872909945468036)
    if (int32_eq_const_69_0 == 213689315)
    if (int8_eq_const_70_0 == 80)
    if (int8_eq_const_71_0 == -122)
    if (int64_eq_const_72_0 == 3020669900511657304)
    if (int32_eq_const_73_0 == -1289235822)
    if (int64_eq_const_74_0 == -2139175324639435923)
    if (int8_eq_const_75_0 == 101)
    if (int16_eq_const_76_0 == 13538)
    if (int16_eq_const_77_0 == -10250)
    if (int32_eq_const_78_0 == 1551894510)
    if (int32_eq_const_79_0 == -147013791)
    if (int8_eq_const_80_0 == -13)
    if (int64_eq_const_81_0 == 802203553206868508)
    if (int16_eq_const_82_0 == -15091)
    if (int64_eq_const_83_0 == -5340896968628342647)
    if (int32_eq_const_84_0 == -1409216473)
    if (int64_eq_const_85_0 == -8446757270123620994)
    if (int32_eq_const_86_0 == 1266590042)
    if (int32_eq_const_87_0 == -256944296)
    if (int16_eq_const_88_0 == -26692)
    if (int8_eq_const_89_0 == 56)
    if (int8_eq_const_90_0 == 76)
    if (int16_eq_const_91_0 == 8314)
    if (int64_eq_const_92_0 == 8232594607962635362)
    if (int32_eq_const_93_0 == -1287035988)
    if (int64_eq_const_94_0 == -6360814002246269532)
    if (int64_eq_const_95_0 == 1795405950734187514)
    if (int8_eq_const_96_0 == 73)
    if (int32_eq_const_97_0 == -782841133)
    if (int32_eq_const_98_0 == -1961764270)
    if (int8_eq_const_99_0 == -112)
    if (int32_eq_const_100_0 == -301490058)
    if (int32_eq_const_101_0 == -1527469831)
    if (int32_eq_const_102_0 == 553254969)
    if (int16_eq_const_103_0 == -31075)
    if (int32_eq_const_104_0 == -889150779)
    if (int16_eq_const_105_0 == -25219)
    if (int16_eq_const_106_0 == -14605)
    if (int16_eq_const_107_0 == -10384)
    if (int8_eq_const_108_0 == -35)
    if (int32_eq_const_109_0 == -719064342)
    if (int8_eq_const_110_0 == -53)
    if (int16_eq_const_111_0 == -2974)
    if (int32_eq_const_112_0 == 1827802186)
    if (int64_eq_const_113_0 == -9021208616076282372)
    if (int16_eq_const_114_0 == -32097)
    if (int64_eq_const_115_0 == 417599641477094557)
    if (int32_eq_const_116_0 == 528476902)
    if (int64_eq_const_117_0 == -6295564133843906266)
    if (int8_eq_const_118_0 == -31)
    if (int8_eq_const_119_0 == -15)
    if (int64_eq_const_120_0 == -7536170505675553785)
    if (int32_eq_const_121_0 == -2073706151)
    if (int16_eq_const_122_0 == -19104)
    if (int8_eq_const_123_0 == -86)
    if (int16_eq_const_124_0 == 14443)
    if (int8_eq_const_125_0 == -5)
    if (int64_eq_const_126_0 == -455232686161556448)
    if (int8_eq_const_127_0 == 104)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
