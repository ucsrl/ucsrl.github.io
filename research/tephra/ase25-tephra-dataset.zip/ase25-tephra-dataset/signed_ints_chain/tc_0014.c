#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int8_t int8_eq_const_3_0;
    int8_t int8_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int8_t int8_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int8_t int8_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    int32_t int32_eq_const_13_0;

    if (size < 51)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_7_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_13_0, &data[i], 4);
    i += 4;


    if (int64_eq_const_0_0 == -5242380899075895653)
    if (int16_eq_const_1_0 == 8172)
    if (int32_eq_const_2_0 == 1014650780)
    if (int8_eq_const_3_0 == 30)
    if (int8_eq_const_4_0 == -45)
    if (int64_eq_const_5_0 == -2386206534053906919)
    if (int16_eq_const_6_0 == 4428)
    if (int8_eq_const_7_0 == -1)
    if (int8_eq_const_8_0 == -81)
    if (int8_eq_const_9_0 == 105)
    if (int64_eq_const_10_0 == -4558632831307625929)
    if (int64_eq_const_11_0 == 3710170943865492017)
    if (int16_eq_const_12_0 == -4585)
    if (int32_eq_const_13_0 == 1317455226)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
