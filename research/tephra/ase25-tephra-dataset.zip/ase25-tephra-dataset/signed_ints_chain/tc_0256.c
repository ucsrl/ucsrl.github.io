#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int8_t int8_eq_const_1_0;
    int8_t int8_eq_const_2_0;
    int64_t int64_eq_const_3_0;
    int16_t int16_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int8_t int8_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int8_t int8_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int64_t int64_eq_const_11_0;
    int32_t int32_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    int16_t int16_eq_const_14_0;
    int16_t int16_eq_const_15_0;
    int8_t int8_eq_const_16_0;
    int16_t int16_eq_const_17_0;
    int16_t int16_eq_const_18_0;
    int16_t int16_eq_const_19_0;
    int64_t int64_eq_const_20_0;
    int8_t int8_eq_const_21_0;
    int8_t int8_eq_const_22_0;
    int16_t int16_eq_const_23_0;
    int16_t int16_eq_const_24_0;
    int64_t int64_eq_const_25_0;
    int32_t int32_eq_const_26_0;
    int32_t int32_eq_const_27_0;
    int64_t int64_eq_const_28_0;
    int8_t int8_eq_const_29_0;
    int8_t int8_eq_const_30_0;
    int16_t int16_eq_const_31_0;
    int64_t int64_eq_const_32_0;
    int64_t int64_eq_const_33_0;
    int8_t int8_eq_const_34_0;
    int8_t int8_eq_const_35_0;
    int8_t int8_eq_const_36_0;
    int64_t int64_eq_const_37_0;
    int16_t int16_eq_const_38_0;
    int64_t int64_eq_const_39_0;
    int64_t int64_eq_const_40_0;
    int32_t int32_eq_const_41_0;
    int64_t int64_eq_const_42_0;
    int32_t int32_eq_const_43_0;
    int32_t int32_eq_const_44_0;
    int8_t int8_eq_const_45_0;
    int16_t int16_eq_const_46_0;
    int8_t int8_eq_const_47_0;
    int64_t int64_eq_const_48_0;
    int32_t int32_eq_const_49_0;
    int16_t int16_eq_const_50_0;
    int64_t int64_eq_const_51_0;
    int32_t int32_eq_const_52_0;
    int8_t int8_eq_const_53_0;
    int64_t int64_eq_const_54_0;
    int16_t int16_eq_const_55_0;
    int16_t int16_eq_const_56_0;
    int64_t int64_eq_const_57_0;
    int8_t int8_eq_const_58_0;
    int64_t int64_eq_const_59_0;
    int16_t int16_eq_const_60_0;
    int32_t int32_eq_const_61_0;
    int8_t int8_eq_const_62_0;
    int8_t int8_eq_const_63_0;
    int8_t int8_eq_const_64_0;
    int32_t int32_eq_const_65_0;
    int16_t int16_eq_const_66_0;
    int16_t int16_eq_const_67_0;
    int8_t int8_eq_const_68_0;
    int64_t int64_eq_const_69_0;
    int16_t int16_eq_const_70_0;
    int16_t int16_eq_const_71_0;
    int8_t int8_eq_const_72_0;
    int64_t int64_eq_const_73_0;
    int16_t int16_eq_const_74_0;
    int64_t int64_eq_const_75_0;
    int8_t int8_eq_const_76_0;
    int64_t int64_eq_const_77_0;
    int64_t int64_eq_const_78_0;
    int64_t int64_eq_const_79_0;
    int8_t int8_eq_const_80_0;
    int8_t int8_eq_const_81_0;
    int64_t int64_eq_const_82_0;
    int16_t int16_eq_const_83_0;
    int8_t int8_eq_const_84_0;
    int16_t int16_eq_const_85_0;
    int16_t int16_eq_const_86_0;
    int8_t int8_eq_const_87_0;
    int32_t int32_eq_const_88_0;
    int32_t int32_eq_const_89_0;
    int64_t int64_eq_const_90_0;
    int32_t int32_eq_const_91_0;
    int16_t int16_eq_const_92_0;
    int8_t int8_eq_const_93_0;
    int8_t int8_eq_const_94_0;
    int64_t int64_eq_const_95_0;
    int8_t int8_eq_const_96_0;
    int64_t int64_eq_const_97_0;
    int64_t int64_eq_const_98_0;
    int64_t int64_eq_const_99_0;
    int16_t int16_eq_const_100_0;
    int64_t int64_eq_const_101_0;
    int8_t int8_eq_const_102_0;
    int32_t int32_eq_const_103_0;
    int64_t int64_eq_const_104_0;
    int16_t int16_eq_const_105_0;
    int64_t int64_eq_const_106_0;
    int64_t int64_eq_const_107_0;
    int64_t int64_eq_const_108_0;
    int32_t int32_eq_const_109_0;
    int16_t int16_eq_const_110_0;
    int64_t int64_eq_const_111_0;
    int16_t int16_eq_const_112_0;
    int16_t int16_eq_const_113_0;
    int32_t int32_eq_const_114_0;
    int32_t int32_eq_const_115_0;
    int8_t int8_eq_const_116_0;
    int64_t int64_eq_const_117_0;
    int32_t int32_eq_const_118_0;
    int64_t int64_eq_const_119_0;
    int16_t int16_eq_const_120_0;
    int8_t int8_eq_const_121_0;
    int8_t int8_eq_const_122_0;
    int32_t int32_eq_const_123_0;
    int8_t int8_eq_const_124_0;
    int8_t int8_eq_const_125_0;
    int64_t int64_eq_const_126_0;
    int8_t int8_eq_const_127_0;
    int8_t int8_eq_const_128_0;
    int64_t int64_eq_const_129_0;
    int32_t int32_eq_const_130_0;
    int8_t int8_eq_const_131_0;
    int64_t int64_eq_const_132_0;
    int16_t int16_eq_const_133_0;
    int32_t int32_eq_const_134_0;
    int16_t int16_eq_const_135_0;
    int8_t int8_eq_const_136_0;
    int64_t int64_eq_const_137_0;
    int32_t int32_eq_const_138_0;
    int8_t int8_eq_const_139_0;
    int8_t int8_eq_const_140_0;
    int8_t int8_eq_const_141_0;
    int64_t int64_eq_const_142_0;
    int8_t int8_eq_const_143_0;
    int32_t int32_eq_const_144_0;
    int8_t int8_eq_const_145_0;
    int16_t int16_eq_const_146_0;
    int8_t int8_eq_const_147_0;
    int16_t int16_eq_const_148_0;
    int8_t int8_eq_const_149_0;
    int8_t int8_eq_const_150_0;
    int16_t int16_eq_const_151_0;
    int16_t int16_eq_const_152_0;
    int32_t int32_eq_const_153_0;
    int16_t int16_eq_const_154_0;
    int8_t int8_eq_const_155_0;
    int16_t int16_eq_const_156_0;
    int8_t int8_eq_const_157_0;
    int32_t int32_eq_const_158_0;
    int16_t int16_eq_const_159_0;
    int32_t int32_eq_const_160_0;
    int32_t int32_eq_const_161_0;
    int64_t int64_eq_const_162_0;
    int16_t int16_eq_const_163_0;
    int32_t int32_eq_const_164_0;
    int32_t int32_eq_const_165_0;
    int16_t int16_eq_const_166_0;
    int32_t int32_eq_const_167_0;
    int32_t int32_eq_const_168_0;
    int8_t int8_eq_const_169_0;
    int64_t int64_eq_const_170_0;
    int8_t int8_eq_const_171_0;
    int8_t int8_eq_const_172_0;
    int16_t int16_eq_const_173_0;
    int64_t int64_eq_const_174_0;
    int16_t int16_eq_const_175_0;
    int32_t int32_eq_const_176_0;
    int8_t int8_eq_const_177_0;
    int8_t int8_eq_const_178_0;
    int8_t int8_eq_const_179_0;
    int8_t int8_eq_const_180_0;
    int8_t int8_eq_const_181_0;
    int64_t int64_eq_const_182_0;
    int16_t int16_eq_const_183_0;
    int16_t int16_eq_const_184_0;
    int64_t int64_eq_const_185_0;
    int32_t int32_eq_const_186_0;
    int8_t int8_eq_const_187_0;
    int8_t int8_eq_const_188_0;
    int8_t int8_eq_const_189_0;
    int64_t int64_eq_const_190_0;
    int16_t int16_eq_const_191_0;
    int16_t int16_eq_const_192_0;
    int16_t int16_eq_const_193_0;
    int64_t int64_eq_const_194_0;
    int16_t int16_eq_const_195_0;
    int16_t int16_eq_const_196_0;
    int8_t int8_eq_const_197_0;
    int32_t int32_eq_const_198_0;
    int64_t int64_eq_const_199_0;
    int32_t int32_eq_const_200_0;
    int32_t int32_eq_const_201_0;
    int64_t int64_eq_const_202_0;
    int16_t int16_eq_const_203_0;
    int8_t int8_eq_const_204_0;
    int8_t int8_eq_const_205_0;
    int16_t int16_eq_const_206_0;
    int16_t int16_eq_const_207_0;
    int8_t int8_eq_const_208_0;
    int8_t int8_eq_const_209_0;
    int16_t int16_eq_const_210_0;
    int32_t int32_eq_const_211_0;
    int32_t int32_eq_const_212_0;
    int8_t int8_eq_const_213_0;
    int64_t int64_eq_const_214_0;
    int16_t int16_eq_const_215_0;
    int16_t int16_eq_const_216_0;
    int8_t int8_eq_const_217_0;
    int64_t int64_eq_const_218_0;
    int64_t int64_eq_const_219_0;
    int16_t int16_eq_const_220_0;
    int64_t int64_eq_const_221_0;
    int32_t int32_eq_const_222_0;
    int64_t int64_eq_const_223_0;
    int64_t int64_eq_const_224_0;
    int8_t int8_eq_const_225_0;
    int8_t int8_eq_const_226_0;
    int8_t int8_eq_const_227_0;
    int16_t int16_eq_const_228_0;
    int16_t int16_eq_const_229_0;
    int16_t int16_eq_const_230_0;
    int64_t int64_eq_const_231_0;
    int16_t int16_eq_const_232_0;
    int32_t int32_eq_const_233_0;
    int8_t int8_eq_const_234_0;
    int16_t int16_eq_const_235_0;
    int32_t int32_eq_const_236_0;
    int16_t int16_eq_const_237_0;
    int8_t int8_eq_const_238_0;
    int32_t int32_eq_const_239_0;
    int16_t int16_eq_const_240_0;
    int32_t int32_eq_const_241_0;
    int8_t int8_eq_const_242_0;
    int64_t int64_eq_const_243_0;
    int8_t int8_eq_const_244_0;
    int32_t int32_eq_const_245_0;
    int16_t int16_eq_const_246_0;
    int16_t int16_eq_const_247_0;
    int16_t int16_eq_const_248_0;
    int32_t int32_eq_const_249_0;
    int8_t int8_eq_const_250_0;
    int32_t int32_eq_const_251_0;
    int32_t int32_eq_const_252_0;
    int8_t int8_eq_const_253_0;
    int16_t int16_eq_const_254_0;
    int16_t int16_eq_const_255_0;

    if (size < 900)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_2_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_3_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_4_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_6_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_8_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_11_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_16_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_19_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_20_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_21_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_23_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_25_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_30_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_33_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_34_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_36_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_37_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_40_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_41_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_42_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_43_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_44_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_46_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_47_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_48_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_50_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_55_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_56_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_58_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_61_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_62_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_63_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_64_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_65_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_66_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_67_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_68_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_69_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_70_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_71_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_72_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_73_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_74_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_75_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_76_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_77_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_78_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_79_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_80_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_81_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_82_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_83_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_85_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_86_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_87_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_88_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_89_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_91_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_92_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_94_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_95_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_96_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_97_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_98_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_99_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_100_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_101_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_102_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_103_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_104_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_105_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_106_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_107_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_108_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_109_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_110_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_111_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_112_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_113_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_114_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_115_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_116_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_117_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_118_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_119_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_120_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_121_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_122_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_123_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_124_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_125_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_126_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_127_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_128_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_129_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_130_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_131_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_132_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_133_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_134_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_135_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_136_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_137_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_138_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_139_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_140_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_141_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_142_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_143_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_144_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_145_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_146_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_147_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_148_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_149_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_150_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_151_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_152_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_153_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_154_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_155_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_156_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_157_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_158_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_159_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_160_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_161_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_162_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_163_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_164_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_165_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_166_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_167_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_168_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_169_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_170_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_171_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_172_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_173_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_174_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_175_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_176_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_177_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_178_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_179_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_180_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_181_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_182_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_183_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_184_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_185_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_186_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_187_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_188_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_189_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_190_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_191_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_192_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_193_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_194_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_195_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_196_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_197_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_198_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_199_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_200_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_201_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_202_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_203_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_204_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_205_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_206_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_207_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_208_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_209_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_210_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_211_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_212_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_213_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_214_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_215_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_216_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_217_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_218_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_219_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_220_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_221_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_222_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_223_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_224_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_225_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_226_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_227_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_228_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_229_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_230_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_231_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_232_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_233_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_234_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_235_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_236_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_237_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_238_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_239_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_240_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_241_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_242_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_243_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_244_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_245_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_246_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_247_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_248_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_249_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_250_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_251_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_252_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_253_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_254_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_255_0, &data[i], 2);
    i += 2;


    if (int32_eq_const_0_0 == 721189696)
    if (int8_eq_const_1_0 == 64)
    if (int8_eq_const_2_0 == -85)
    if (int64_eq_const_3_0 == 8425524414862651279)
    if (int16_eq_const_4_0 == -16153)
    if (int64_eq_const_5_0 == -1499443348351917623)
    if (int8_eq_const_6_0 == 11)
    if (int64_eq_const_7_0 == 4614098383702611195)
    if (int8_eq_const_8_0 == 75)
    if (int32_eq_const_9_0 == -1102817902)
    if (int64_eq_const_10_0 == -2816157573516330358)
    if (int64_eq_const_11_0 == 4441580452770489164)
    if (int32_eq_const_12_0 == 467143953)
    if (int16_eq_const_13_0 == -11075)
    if (int16_eq_const_14_0 == -27874)
    if (int16_eq_const_15_0 == -21568)
    if (int8_eq_const_16_0 == 82)
    if (int16_eq_const_17_0 == 455)
    if (int16_eq_const_18_0 == -20364)
    if (int16_eq_const_19_0 == -366)
    if (int64_eq_const_20_0 == 3665946681858076470)
    if (int8_eq_const_21_0 == -5)
    if (int8_eq_const_22_0 == -102)
    if (int16_eq_const_23_0 == -12667)
    if (int16_eq_const_24_0 == 23934)
    if (int64_eq_const_25_0 == -1726176648965118341)
    if (int32_eq_const_26_0 == -67885150)
    if (int32_eq_const_27_0 == -1292548787)
    if (int64_eq_const_28_0 == -7445377568171689475)
    if (int8_eq_const_29_0 == 38)
    if (int8_eq_const_30_0 == 121)
    if (int16_eq_const_31_0 == -3316)
    if (int64_eq_const_32_0 == -7739023186269079761)
    if (int64_eq_const_33_0 == -371855180126582540)
    if (int8_eq_const_34_0 == 64)
    if (int8_eq_const_35_0 == 86)
    if (int8_eq_const_36_0 == -80)
    if (int64_eq_const_37_0 == 8958022302190537779)
    if (int16_eq_const_38_0 == -17962)
    if (int64_eq_const_39_0 == 701759964073563590)
    if (int64_eq_const_40_0 == -4877164666188774456)
    if (int32_eq_const_41_0 == -5968850)
    if (int64_eq_const_42_0 == 964385265951933355)
    if (int32_eq_const_43_0 == 1930961922)
    if (int32_eq_const_44_0 == 983227332)
    if (int8_eq_const_45_0 == 118)
    if (int16_eq_const_46_0 == 7363)
    if (int8_eq_const_47_0 == 27)
    if (int64_eq_const_48_0 == -4335387123111136309)
    if (int32_eq_const_49_0 == -1250717884)
    if (int16_eq_const_50_0 == 1245)
    if (int64_eq_const_51_0 == 4460392071947520775)
    if (int32_eq_const_52_0 == 938503356)
    if (int8_eq_const_53_0 == 83)
    if (int64_eq_const_54_0 == -4736655640648517779)
    if (int16_eq_const_55_0 == 25629)
    if (int16_eq_const_56_0 == 6369)
    if (int64_eq_const_57_0 == -1577891002207289097)
    if (int8_eq_const_58_0 == -11)
    if (int64_eq_const_59_0 == -8881213261450523420)
    if (int16_eq_const_60_0 == -29344)
    if (int32_eq_const_61_0 == -921733907)
    if (int8_eq_const_62_0 == 69)
    if (int8_eq_const_63_0 == 108)
    if (int8_eq_const_64_0 == -66)
    if (int32_eq_const_65_0 == 1344475872)
    if (int16_eq_const_66_0 == -28632)
    if (int16_eq_const_67_0 == 23777)
    if (int8_eq_const_68_0 == 0)
    if (int64_eq_const_69_0 == 605417926066982352)
    if (int16_eq_const_70_0 == 21809)
    if (int16_eq_const_71_0 == 15565)
    if (int8_eq_const_72_0 == 107)
    if (int64_eq_const_73_0 == 4479047732698230079)
    if (int16_eq_const_74_0 == 2829)
    if (int64_eq_const_75_0 == -3399243796964425575)
    if (int8_eq_const_76_0 == 113)
    if (int64_eq_const_77_0 == -3189418197465690964)
    if (int64_eq_const_78_0 == 2908328219107347024)
    if (int64_eq_const_79_0 == -8776157725485604159)
    if (int8_eq_const_80_0 == 39)
    if (int8_eq_const_81_0 == -64)
    if (int64_eq_const_82_0 == -3959651869017890308)
    if (int16_eq_const_83_0 == 1235)
    if (int8_eq_const_84_0 == -10)
    if (int16_eq_const_85_0 == -19062)
    if (int16_eq_const_86_0 == -27614)
    if (int8_eq_const_87_0 == -49)
    if (int32_eq_const_88_0 == 960597142)
    if (int32_eq_const_89_0 == 666136155)
    if (int64_eq_const_90_0 == -3541728377055038850)
    if (int32_eq_const_91_0 == -1962796954)
    if (int16_eq_const_92_0 == 13258)
    if (int8_eq_const_93_0 == -98)
    if (int8_eq_const_94_0 == -41)
    if (int64_eq_const_95_0 == -8137644961177085047)
    if (int8_eq_const_96_0 == -44)
    if (int64_eq_const_97_0 == 8665945651729474873)
    if (int64_eq_const_98_0 == -7231561796135143971)
    if (int64_eq_const_99_0 == 6941706766821937541)
    if (int16_eq_const_100_0 == -27989)
    if (int64_eq_const_101_0 == 8600465922831920096)
    if (int8_eq_const_102_0 == -15)
    if (int32_eq_const_103_0 == -1203932205)
    if (int64_eq_const_104_0 == 6043911193686956848)
    if (int16_eq_const_105_0 == 27705)
    if (int64_eq_const_106_0 == 3794836801479585014)
    if (int64_eq_const_107_0 == -3795869014748876873)
    if (int64_eq_const_108_0 == -4688896636852924945)
    if (int32_eq_const_109_0 == 1708983596)
    if (int16_eq_const_110_0 == 25499)
    if (int64_eq_const_111_0 == 2969109433568528039)
    if (int16_eq_const_112_0 == 32105)
    if (int16_eq_const_113_0 == -6135)
    if (int32_eq_const_114_0 == 1961252517)
    if (int32_eq_const_115_0 == 360850409)
    if (int8_eq_const_116_0 == 2)
    if (int64_eq_const_117_0 == 6771763469593819831)
    if (int32_eq_const_118_0 == 613147697)
    if (int64_eq_const_119_0 == 55611106044083403)
    if (int16_eq_const_120_0 == -28643)
    if (int8_eq_const_121_0 == -112)
    if (int8_eq_const_122_0 == -15)
    if (int32_eq_const_123_0 == -659184073)
    if (int8_eq_const_124_0 == 100)
    if (int8_eq_const_125_0 == -72)
    if (int64_eq_const_126_0 == 2104407910651165090)
    if (int8_eq_const_127_0 == 63)
    if (int8_eq_const_128_0 == 30)
    if (int64_eq_const_129_0 == -1770169682980384243)
    if (int32_eq_const_130_0 == 115867402)
    if (int8_eq_const_131_0 == -39)
    if (int64_eq_const_132_0 == 3565380767215137275)
    if (int16_eq_const_133_0 == 24403)
    if (int32_eq_const_134_0 == -218681005)
    if (int16_eq_const_135_0 == 18641)
    if (int8_eq_const_136_0 == -9)
    if (int64_eq_const_137_0 == -7078551658361785355)
    if (int32_eq_const_138_0 == -692987531)
    if (int8_eq_const_139_0 == 36)
    if (int8_eq_const_140_0 == -63)
    if (int8_eq_const_141_0 == -36)
    if (int64_eq_const_142_0 == 538199273951921005)
    if (int8_eq_const_143_0 == -96)
    if (int32_eq_const_144_0 == -1767684927)
    if (int8_eq_const_145_0 == -6)
    if (int16_eq_const_146_0 == -10721)
    if (int8_eq_const_147_0 == 114)
    if (int16_eq_const_148_0 == -22148)
    if (int8_eq_const_149_0 == -54)
    if (int8_eq_const_150_0 == -31)
    if (int16_eq_const_151_0 == 30703)
    if (int16_eq_const_152_0 == -4243)
    if (int32_eq_const_153_0 == -1950530078)
    if (int16_eq_const_154_0 == 12134)
    if (int8_eq_const_155_0 == -9)
    if (int16_eq_const_156_0 == -18873)
    if (int8_eq_const_157_0 == 117)
    if (int32_eq_const_158_0 == 1853046854)
    if (int16_eq_const_159_0 == 27597)
    if (int32_eq_const_160_0 == 2067125706)
    if (int32_eq_const_161_0 == -66042258)
    if (int64_eq_const_162_0 == -8095594541909047814)
    if (int16_eq_const_163_0 == -20459)
    if (int32_eq_const_164_0 == 1220152301)
    if (int32_eq_const_165_0 == 988895352)
    if (int16_eq_const_166_0 == -12009)
    if (int32_eq_const_167_0 == 55526276)
    if (int32_eq_const_168_0 == 1620827322)
    if (int8_eq_const_169_0 == 70)
    if (int64_eq_const_170_0 == 3431272376712687605)
    if (int8_eq_const_171_0 == -50)
    if (int8_eq_const_172_0 == -127)
    if (int16_eq_const_173_0 == 25607)
    if (int64_eq_const_174_0 == 2913451389067355516)
    if (int16_eq_const_175_0 == 20487)
    if (int32_eq_const_176_0 == -1446898173)
    if (int8_eq_const_177_0 == -94)
    if (int8_eq_const_178_0 == 40)
    if (int8_eq_const_179_0 == 79)
    if (int8_eq_const_180_0 == -44)
    if (int8_eq_const_181_0 == 15)
    if (int64_eq_const_182_0 == -8800333543464951836)
    if (int16_eq_const_183_0 == -15336)
    if (int16_eq_const_184_0 == -12829)
    if (int64_eq_const_185_0 == 6422018487505500472)
    if (int32_eq_const_186_0 == 1708351921)
    if (int8_eq_const_187_0 == -23)
    if (int8_eq_const_188_0 == -24)
    if (int8_eq_const_189_0 == -17)
    if (int64_eq_const_190_0 == 9219270132181584783)
    if (int16_eq_const_191_0 == -26406)
    if (int16_eq_const_192_0 == 3792)
    if (int16_eq_const_193_0 == 27910)
    if (int64_eq_const_194_0 == 5026595925487684372)
    if (int16_eq_const_195_0 == -11741)
    if (int16_eq_const_196_0 == 25417)
    if (int8_eq_const_197_0 == -33)
    if (int32_eq_const_198_0 == 333388522)
    if (int64_eq_const_199_0 == -2397414544202369524)
    if (int32_eq_const_200_0 == 1800125074)
    if (int32_eq_const_201_0 == -1206673074)
    if (int64_eq_const_202_0 == -5177261615964059335)
    if (int16_eq_const_203_0 == 3263)
    if (int8_eq_const_204_0 == -127)
    if (int8_eq_const_205_0 == -87)
    if (int16_eq_const_206_0 == 18115)
    if (int16_eq_const_207_0 == -28824)
    if (int8_eq_const_208_0 == 39)
    if (int8_eq_const_209_0 == 110)
    if (int16_eq_const_210_0 == -4599)
    if (int32_eq_const_211_0 == 1184570614)
    if (int32_eq_const_212_0 == -1608014089)
    if (int8_eq_const_213_0 == 113)
    if (int64_eq_const_214_0 == -5228481382716593985)
    if (int16_eq_const_215_0 == 15166)
    if (int16_eq_const_216_0 == 11052)
    if (int8_eq_const_217_0 == 44)
    if (int64_eq_const_218_0 == 7648050929065896439)
    if (int64_eq_const_219_0 == -1329957141131506718)
    if (int16_eq_const_220_0 == 4555)
    if (int64_eq_const_221_0 == 1919989574533330134)
    if (int32_eq_const_222_0 == -1846702422)
    if (int64_eq_const_223_0 == -6127715690522556678)
    if (int64_eq_const_224_0 == 4226752439170748588)
    if (int8_eq_const_225_0 == -9)
    if (int8_eq_const_226_0 == 3)
    if (int8_eq_const_227_0 == -127)
    if (int16_eq_const_228_0 == -6371)
    if (int16_eq_const_229_0 == 13203)
    if (int16_eq_const_230_0 == -27249)
    if (int64_eq_const_231_0 == -8171420587765101437)
    if (int16_eq_const_232_0 == 17622)
    if (int32_eq_const_233_0 == -527886282)
    if (int8_eq_const_234_0 == 43)
    if (int16_eq_const_235_0 == 22417)
    if (int32_eq_const_236_0 == -2027560645)
    if (int16_eq_const_237_0 == 9391)
    if (int8_eq_const_238_0 == -98)
    if (int32_eq_const_239_0 == -1833082919)
    if (int16_eq_const_240_0 == 19960)
    if (int32_eq_const_241_0 == 636436172)
    if (int8_eq_const_242_0 == 7)
    if (int64_eq_const_243_0 == -4067591879088550573)
    if (int8_eq_const_244_0 == 58)
    if (int32_eq_const_245_0 == -1237158789)
    if (int16_eq_const_246_0 == -6819)
    if (int16_eq_const_247_0 == 29950)
    if (int16_eq_const_248_0 == -19409)
    if (int32_eq_const_249_0 == -1926157401)
    if (int8_eq_const_250_0 == 47)
    if (int32_eq_const_251_0 == -39814439)
    if (int32_eq_const_252_0 == 168235791)
    if (int8_eq_const_253_0 == 49)
    if (int16_eq_const_254_0 == -7988)
    if (int16_eq_const_255_0 == -3905)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
