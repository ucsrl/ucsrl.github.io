#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int16_t int16_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int8_t int8_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int64_t int64_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    int16_t int16_eq_const_13_0;
    int8_t int8_eq_const_14_0;
    int16_t int16_eq_const_15_0;
    int32_t int32_eq_const_16_0;
    int32_t int32_eq_const_17_0;
    int8_t int8_eq_const_18_0;
    int32_t int32_eq_const_19_0;
    int16_t int16_eq_const_20_0;
    int64_t int64_eq_const_21_0;
    int8_t int8_eq_const_22_0;
    int32_t int32_eq_const_23_0;
    int32_t int32_eq_const_24_0;
    int8_t int8_eq_const_25_0;
    int16_t int16_eq_const_26_0;
    int16_t int16_eq_const_27_0;
    int64_t int64_eq_const_28_0;
    int8_t int8_eq_const_29_0;
    int32_t int32_eq_const_30_0;
    int16_t int16_eq_const_31_0;
    int64_t int64_eq_const_32_0;
    int8_t int8_eq_const_33_0;
    int16_t int16_eq_const_34_0;
    int8_t int8_eq_const_35_0;
    int64_t int64_eq_const_36_0;
    int32_t int32_eq_const_37_0;
    int16_t int16_eq_const_38_0;
    int64_t int64_eq_const_39_0;
    int32_t int32_eq_const_40_0;
    int8_t int8_eq_const_41_0;
    int8_t int8_eq_const_42_0;
    int64_t int64_eq_const_43_0;
    int64_t int64_eq_const_44_0;
    int16_t int16_eq_const_45_0;
    int16_t int16_eq_const_46_0;
    int32_t int32_eq_const_47_0;
    int32_t int32_eq_const_48_0;
    int32_t int32_eq_const_49_0;
    int16_t int16_eq_const_50_0;
    int32_t int32_eq_const_51_0;
    int8_t int8_eq_const_52_0;
    int8_t int8_eq_const_53_0;
    int8_t int8_eq_const_54_0;
    int32_t int32_eq_const_55_0;
    int8_t int8_eq_const_56_0;
    int64_t int64_eq_const_57_0;
    int32_t int32_eq_const_58_0;
    int64_t int64_eq_const_59_0;
    int16_t int16_eq_const_60_0;
    int8_t int8_eq_const_61_0;
    int16_t int16_eq_const_62_0;
    int32_t int32_eq_const_63_0;

    if (size < 229)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_1_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_5_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_9_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_13_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_14_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_15_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_18_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_20_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_21_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_22_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_25_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_26_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_27_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_28_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_33_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_34_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_35_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_36_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_38_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_43_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_45_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_46_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_50_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_51_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_53_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_54_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_55_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_60_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_62_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_63_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == -91183728)
    if (int16_eq_const_1_0 == -5059)
    if (int32_eq_const_2_0 == -240140161)
    if (int32_eq_const_3_0 == 1594711539)
    if (int32_eq_const_4_0 == 1087455450)
    if (int8_eq_const_5_0 == 38)
    if (int64_eq_const_6_0 == -5945059659519584160)
    if (int64_eq_const_7_0 == -8420238362809092427)
    if (int32_eq_const_8_0 == -232259713)
    if (int64_eq_const_9_0 == -8713868714503600091)
    if (int32_eq_const_10_0 == 1718020739)
    if (int32_eq_const_11_0 == 806636379)
    if (int16_eq_const_12_0 == -6115)
    if (int16_eq_const_13_0 == -2677)
    if (int8_eq_const_14_0 == -33)
    if (int16_eq_const_15_0 == 28049)
    if (int32_eq_const_16_0 == -1003449991)
    if (int32_eq_const_17_0 == 1864836071)
    if (int8_eq_const_18_0 == -7)
    if (int32_eq_const_19_0 == -195052828)
    if (int16_eq_const_20_0 == -7353)
    if (int64_eq_const_21_0 == 424595332833446470)
    if (int8_eq_const_22_0 == 52)
    if (int32_eq_const_23_0 == -717078620)
    if (int32_eq_const_24_0 == 17905519)
    if (int8_eq_const_25_0 == -59)
    if (int16_eq_const_26_0 == 23954)
    if (int16_eq_const_27_0 == -12551)
    if (int64_eq_const_28_0 == -4157266503549945079)
    if (int8_eq_const_29_0 == 70)
    if (int32_eq_const_30_0 == 797794998)
    if (int16_eq_const_31_0 == -12741)
    if (int64_eq_const_32_0 == -7254345282035464646)
    if (int8_eq_const_33_0 == 29)
    if (int16_eq_const_34_0 == -20550)
    if (int8_eq_const_35_0 == -2)
    if (int64_eq_const_36_0 == -4740485635312444889)
    if (int32_eq_const_37_0 == -1979726687)
    if (int16_eq_const_38_0 == 5792)
    if (int64_eq_const_39_0 == -4509766097668994034)
    if (int32_eq_const_40_0 == 1249193428)
    if (int8_eq_const_41_0 == 57)
    if (int8_eq_const_42_0 == 63)
    if (int64_eq_const_43_0 == -7670880602692270600)
    if (int64_eq_const_44_0 == -7633517080213263745)
    if (int16_eq_const_45_0 == -17289)
    if (int16_eq_const_46_0 == 1501)
    if (int32_eq_const_47_0 == -1945792125)
    if (int32_eq_const_48_0 == 106915201)
    if (int32_eq_const_49_0 == -909842541)
    if (int16_eq_const_50_0 == 20623)
    if (int32_eq_const_51_0 == -1582746354)
    if (int8_eq_const_52_0 == -59)
    if (int8_eq_const_53_0 == 68)
    if (int8_eq_const_54_0 == 0)
    if (int32_eq_const_55_0 == 1996059593)
    if (int8_eq_const_56_0 == -116)
    if (int64_eq_const_57_0 == -8445457547842010212)
    if (int32_eq_const_58_0 == 1538442489)
    if (int64_eq_const_59_0 == -5372615676958871760)
    if (int16_eq_const_60_0 == -26841)
    if (int8_eq_const_61_0 == -128)
    if (int16_eq_const_62_0 == 5829)
    if (int32_eq_const_63_0 == 391115928)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
