#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int64_t int64_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int16_t int16_eq_const_3_0;
    int64_t int64_eq_const_4_0;
    int64_t int64_eq_const_5_0;
    int64_t int64_eq_const_6_0;
    int32_t int32_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int16_t int16_eq_const_9_0;
    int16_t int16_eq_const_10_0;
    int16_t int16_eq_const_11_0;
    int16_t int16_eq_const_12_0;
    int64_t int64_eq_const_13_0;
    int16_t int16_eq_const_14_0;
    int8_t int8_eq_const_15_0;
    int64_t int64_eq_const_16_0;
    int16_t int16_eq_const_17_0;
    int16_t int16_eq_const_18_0;
    int64_t int64_eq_const_19_0;
    int8_t int8_eq_const_20_0;
    int16_t int16_eq_const_21_0;
    int64_t int64_eq_const_22_0;
    int64_t int64_eq_const_23_0;
    int16_t int16_eq_const_24_0;
    int32_t int32_eq_const_25_0;
    int8_t int8_eq_const_26_0;
    int8_t int8_eq_const_27_0;
    int16_t int16_eq_const_28_0;
    int8_t int8_eq_const_29_0;
    int16_t int16_eq_const_30_0;
    int16_t int16_eq_const_31_0;
    int64_t int64_eq_const_32_0;
    int16_t int16_eq_const_33_0;
    int64_t int64_eq_const_34_0;
    int64_t int64_eq_const_35_0;
    int16_t int16_eq_const_36_0;
    int32_t int32_eq_const_37_0;
    int32_t int32_eq_const_38_0;
    int64_t int64_eq_const_39_0;
    int32_t int32_eq_const_40_0;
    int8_t int8_eq_const_41_0;
    int8_t int8_eq_const_42_0;
    int16_t int16_eq_const_43_0;
    int64_t int64_eq_const_44_0;
    int8_t int8_eq_const_45_0;
    int32_t int32_eq_const_46_0;
    int64_t int64_eq_const_47_0;
    int8_t int8_eq_const_48_0;
    int8_t int8_eq_const_49_0;
    int32_t int32_eq_const_50_0;
    int64_t int64_eq_const_51_0;
    int8_t int8_eq_const_52_0;
    int32_t int32_eq_const_53_0;
    int64_t int64_eq_const_54_0;
    int8_t int8_eq_const_55_0;
    int8_t int8_eq_const_56_0;
    int64_t int64_eq_const_57_0;
    int32_t int32_eq_const_58_0;
    int64_t int64_eq_const_59_0;
    int8_t int8_eq_const_60_0;
    int8_t int8_eq_const_61_0;
    int16_t int16_eq_const_62_0;
    int32_t int32_eq_const_63_0;
    int16_t int16_eq_const_64_0;
    int16_t int16_eq_const_65_0;
    int64_t int64_eq_const_66_0;
    int64_t int64_eq_const_67_0;
    int64_t int64_eq_const_68_0;
    int8_t int8_eq_const_69_0;
    int8_t int8_eq_const_70_0;
    int32_t int32_eq_const_71_0;
    int64_t int64_eq_const_72_0;
    int64_t int64_eq_const_73_0;
    int16_t int16_eq_const_74_0;
    int64_t int64_eq_const_75_0;
    int8_t int8_eq_const_76_0;
    int8_t int8_eq_const_77_0;
    int16_t int16_eq_const_78_0;
    int16_t int16_eq_const_79_0;
    int32_t int32_eq_const_80_0;
    int32_t int32_eq_const_81_0;
    int8_t int8_eq_const_82_0;
    int16_t int16_eq_const_83_0;
    int8_t int8_eq_const_84_0;
    int64_t int64_eq_const_85_0;
    int8_t int8_eq_const_86_0;
    int32_t int32_eq_const_87_0;
    int32_t int32_eq_const_88_0;
    int16_t int16_eq_const_89_0;
    int64_t int64_eq_const_90_0;
    int64_t int64_eq_const_91_0;
    int8_t int8_eq_const_92_0;
    int8_t int8_eq_const_93_0;
    int64_t int64_eq_const_94_0;
    int8_t int8_eq_const_95_0;
    int64_t int64_eq_const_96_0;
    int32_t int32_eq_const_97_0;
    int16_t int16_eq_const_98_0;
    int8_t int8_eq_const_99_0;
    int8_t int8_eq_const_100_0;
    int8_t int8_eq_const_101_0;
    int16_t int16_eq_const_102_0;
    int8_t int8_eq_const_103_0;
    int32_t int32_eq_const_104_0;
    int32_t int32_eq_const_105_0;
    int32_t int32_eq_const_106_0;
    int16_t int16_eq_const_107_0;
    int64_t int64_eq_const_108_0;
    int16_t int16_eq_const_109_0;
    int64_t int64_eq_const_110_0;
    int64_t int64_eq_const_111_0;
    int8_t int8_eq_const_112_0;
    int8_t int8_eq_const_113_0;
    int64_t int64_eq_const_114_0;
    int64_t int64_eq_const_115_0;
    int32_t int32_eq_const_116_0;
    int8_t int8_eq_const_117_0;
    int32_t int32_eq_const_118_0;
    int16_t int16_eq_const_119_0;
    int32_t int32_eq_const_120_0;
    int8_t int8_eq_const_121_0;
    int64_t int64_eq_const_122_0;
    int16_t int16_eq_const_123_0;
    int16_t int16_eq_const_124_0;
    int32_t int32_eq_const_125_0;
    int8_t int8_eq_const_126_0;
    int32_t int32_eq_const_127_0;
    int64_t int64_eq_const_128_0;
    int16_t int16_eq_const_129_0;
    int8_t int8_eq_const_130_0;
    int8_t int8_eq_const_131_0;
    int8_t int8_eq_const_132_0;
    int64_t int64_eq_const_133_0;
    int8_t int8_eq_const_134_0;
    int8_t int8_eq_const_135_0;
    int64_t int64_eq_const_136_0;
    int32_t int32_eq_const_137_0;
    int32_t int32_eq_const_138_0;
    int16_t int16_eq_const_139_0;
    int32_t int32_eq_const_140_0;
    int8_t int8_eq_const_141_0;
    int16_t int16_eq_const_142_0;
    int64_t int64_eq_const_143_0;
    int16_t int16_eq_const_144_0;
    int16_t int16_eq_const_145_0;
    int32_t int32_eq_const_146_0;
    int32_t int32_eq_const_147_0;
    int8_t int8_eq_const_148_0;
    int8_t int8_eq_const_149_0;
    int64_t int64_eq_const_150_0;
    int8_t int8_eq_const_151_0;
    int32_t int32_eq_const_152_0;
    int16_t int16_eq_const_153_0;
    int8_t int8_eq_const_154_0;
    int32_t int32_eq_const_155_0;
    int32_t int32_eq_const_156_0;
    int32_t int32_eq_const_157_0;
    int32_t int32_eq_const_158_0;
    int16_t int16_eq_const_159_0;
    int8_t int8_eq_const_160_0;
    int8_t int8_eq_const_161_0;
    int64_t int64_eq_const_162_0;
    int64_t int64_eq_const_163_0;
    int16_t int16_eq_const_164_0;
    int32_t int32_eq_const_165_0;
    int8_t int8_eq_const_166_0;
    int64_t int64_eq_const_167_0;
    int64_t int64_eq_const_168_0;
    int64_t int64_eq_const_169_0;
    int32_t int32_eq_const_170_0;
    int16_t int16_eq_const_171_0;
    int64_t int64_eq_const_172_0;
    int64_t int64_eq_const_173_0;
    int16_t int16_eq_const_174_0;
    int8_t int8_eq_const_175_0;
    int16_t int16_eq_const_176_0;
    int8_t int8_eq_const_177_0;
    int16_t int16_eq_const_178_0;
    int32_t int32_eq_const_179_0;
    int16_t int16_eq_const_180_0;
    int8_t int8_eq_const_181_0;
    int8_t int8_eq_const_182_0;
    int8_t int8_eq_const_183_0;
    int64_t int64_eq_const_184_0;
    int32_t int32_eq_const_185_0;
    int32_t int32_eq_const_186_0;
    int16_t int16_eq_const_187_0;
    int16_t int16_eq_const_188_0;
    int8_t int8_eq_const_189_0;
    int16_t int16_eq_const_190_0;
    int32_t int32_eq_const_191_0;
    int16_t int16_eq_const_192_0;
    int16_t int16_eq_const_193_0;
    int32_t int32_eq_const_194_0;
    int32_t int32_eq_const_195_0;
    int64_t int64_eq_const_196_0;
    int8_t int8_eq_const_197_0;
    int16_t int16_eq_const_198_0;
    int32_t int32_eq_const_199_0;
    int64_t int64_eq_const_200_0;
    int8_t int8_eq_const_201_0;
    int32_t int32_eq_const_202_0;
    int16_t int16_eq_const_203_0;
    int32_t int32_eq_const_204_0;
    int8_t int8_eq_const_205_0;
    int32_t int32_eq_const_206_0;
    int8_t int8_eq_const_207_0;
    int64_t int64_eq_const_208_0;
    int16_t int16_eq_const_209_0;
    int32_t int32_eq_const_210_0;
    int16_t int16_eq_const_211_0;
    int16_t int16_eq_const_212_0;
    int16_t int16_eq_const_213_0;
    int64_t int64_eq_const_214_0;
    int64_t int64_eq_const_215_0;
    int16_t int16_eq_const_216_0;
    int64_t int64_eq_const_217_0;
    int16_t int16_eq_const_218_0;
    int32_t int32_eq_const_219_0;
    int64_t int64_eq_const_220_0;
    int16_t int16_eq_const_221_0;
    int32_t int32_eq_const_222_0;
    int32_t int32_eq_const_223_0;
    int64_t int64_eq_const_224_0;
    int16_t int16_eq_const_225_0;
    int16_t int16_eq_const_226_0;
    int16_t int16_eq_const_227_0;
    int32_t int32_eq_const_228_0;
    int16_t int16_eq_const_229_0;
    int64_t int64_eq_const_230_0;
    int16_t int16_eq_const_231_0;
    int32_t int32_eq_const_232_0;
    int8_t int8_eq_const_233_0;
    int32_t int32_eq_const_234_0;
    int32_t int32_eq_const_235_0;
    int16_t int16_eq_const_236_0;
    int32_t int32_eq_const_237_0;
    int64_t int64_eq_const_238_0;
    int64_t int64_eq_const_239_0;
    int8_t int8_eq_const_240_0;
    int32_t int32_eq_const_241_0;
    int8_t int8_eq_const_242_0;
    int64_t int64_eq_const_243_0;
    int8_t int8_eq_const_244_0;
    int32_t int32_eq_const_245_0;
    int8_t int8_eq_const_246_0;
    int32_t int32_eq_const_247_0;
    int64_t int64_eq_const_248_0;
    int64_t int64_eq_const_249_0;
    int8_t int8_eq_const_250_0;
    int8_t int8_eq_const_251_0;
    int8_t int8_eq_const_252_0;
    int16_t int16_eq_const_253_0;
    int8_t int8_eq_const_254_0;
    int32_t int32_eq_const_255_0;
    int8_t int8_eq_const_256_0;
    int32_t int32_eq_const_257_0;
    int64_t int64_eq_const_258_0;
    int64_t int64_eq_const_259_0;
    int16_t int16_eq_const_260_0;
    int8_t int8_eq_const_261_0;
    int8_t int8_eq_const_262_0;
    int16_t int16_eq_const_263_0;
    int8_t int8_eq_const_264_0;
    int64_t int64_eq_const_265_0;
    int8_t int8_eq_const_266_0;
    int64_t int64_eq_const_267_0;
    int64_t int64_eq_const_268_0;
    int64_t int64_eq_const_269_0;
    int8_t int8_eq_const_270_0;
    int64_t int64_eq_const_271_0;
    int32_t int32_eq_const_272_0;
    int64_t int64_eq_const_273_0;
    int16_t int16_eq_const_274_0;
    int32_t int32_eq_const_275_0;
    int8_t int8_eq_const_276_0;
    int8_t int8_eq_const_277_0;
    int16_t int16_eq_const_278_0;
    int16_t int16_eq_const_279_0;
    int8_t int8_eq_const_280_0;
    int64_t int64_eq_const_281_0;
    int16_t int16_eq_const_282_0;
    int16_t int16_eq_const_283_0;
    int32_t int32_eq_const_284_0;
    int16_t int16_eq_const_285_0;
    int32_t int32_eq_const_286_0;
    int32_t int32_eq_const_287_0;
    int32_t int32_eq_const_288_0;
    int8_t int8_eq_const_289_0;
    int32_t int32_eq_const_290_0;
    int32_t int32_eq_const_291_0;
    int8_t int8_eq_const_292_0;
    int8_t int8_eq_const_293_0;
    int8_t int8_eq_const_294_0;
    int16_t int16_eq_const_295_0;
    int64_t int64_eq_const_296_0;
    int32_t int32_eq_const_297_0;
    int16_t int16_eq_const_298_0;
    int16_t int16_eq_const_299_0;
    int16_t int16_eq_const_300_0;
    int64_t int64_eq_const_301_0;
    int8_t int8_eq_const_302_0;
    int16_t int16_eq_const_303_0;
    int16_t int16_eq_const_304_0;
    int16_t int16_eq_const_305_0;
    int16_t int16_eq_const_306_0;
    int32_t int32_eq_const_307_0;
    int32_t int32_eq_const_308_0;
    int64_t int64_eq_const_309_0;
    int32_t int32_eq_const_310_0;
    int64_t int64_eq_const_311_0;
    int8_t int8_eq_const_312_0;
    int32_t int32_eq_const_313_0;
    int64_t int64_eq_const_314_0;
    int32_t int32_eq_const_315_0;
    int8_t int8_eq_const_316_0;
    int32_t int32_eq_const_317_0;
    int32_t int32_eq_const_318_0;
    int8_t int8_eq_const_319_0;
    int16_t int16_eq_const_320_0;
    int8_t int8_eq_const_321_0;
    int32_t int32_eq_const_322_0;
    int64_t int64_eq_const_323_0;
    int32_t int32_eq_const_324_0;
    int8_t int8_eq_const_325_0;
    int64_t int64_eq_const_326_0;
    int64_t int64_eq_const_327_0;
    int32_t int32_eq_const_328_0;
    int16_t int16_eq_const_329_0;
    int8_t int8_eq_const_330_0;
    int8_t int8_eq_const_331_0;
    int64_t int64_eq_const_332_0;
    int32_t int32_eq_const_333_0;
    int16_t int16_eq_const_334_0;
    int8_t int8_eq_const_335_0;
    int64_t int64_eq_const_336_0;
    int16_t int16_eq_const_337_0;
    int16_t int16_eq_const_338_0;
    int16_t int16_eq_const_339_0;
    int64_t int64_eq_const_340_0;
    int64_t int64_eq_const_341_0;
    int16_t int16_eq_const_342_0;
    int16_t int16_eq_const_343_0;
    int64_t int64_eq_const_344_0;
    int16_t int16_eq_const_345_0;
    int16_t int16_eq_const_346_0;
    int32_t int32_eq_const_347_0;
    int8_t int8_eq_const_348_0;
    int8_t int8_eq_const_349_0;
    int32_t int32_eq_const_350_0;
    int64_t int64_eq_const_351_0;
    int64_t int64_eq_const_352_0;
    int64_t int64_eq_const_353_0;
    int8_t int8_eq_const_354_0;
    int16_t int16_eq_const_355_0;
    int32_t int32_eq_const_356_0;
    int32_t int32_eq_const_357_0;
    int16_t int16_eq_const_358_0;
    int64_t int64_eq_const_359_0;
    int16_t int16_eq_const_360_0;
    int8_t int8_eq_const_361_0;
    int16_t int16_eq_const_362_0;
    int8_t int8_eq_const_363_0;
    int16_t int16_eq_const_364_0;
    int64_t int64_eq_const_365_0;
    int16_t int16_eq_const_366_0;
    int8_t int8_eq_const_367_0;
    int16_t int16_eq_const_368_0;
    int8_t int8_eq_const_369_0;
    int8_t int8_eq_const_370_0;
    int32_t int32_eq_const_371_0;
    int64_t int64_eq_const_372_0;
    int32_t int32_eq_const_373_0;
    int32_t int32_eq_const_374_0;
    int16_t int16_eq_const_375_0;
    int32_t int32_eq_const_376_0;
    int8_t int8_eq_const_377_0;
    int16_t int16_eq_const_378_0;
    int16_t int16_eq_const_379_0;
    int32_t int32_eq_const_380_0;
    int32_t int32_eq_const_381_0;
    int64_t int64_eq_const_382_0;
    int8_t int8_eq_const_383_0;
    int16_t int16_eq_const_384_0;
    int16_t int16_eq_const_385_0;
    int64_t int64_eq_const_386_0;
    int16_t int16_eq_const_387_0;
    int16_t int16_eq_const_388_0;
    int32_t int32_eq_const_389_0;
    int8_t int8_eq_const_390_0;
    int16_t int16_eq_const_391_0;
    int8_t int8_eq_const_392_0;
    int16_t int16_eq_const_393_0;
    int16_t int16_eq_const_394_0;
    int8_t int8_eq_const_395_0;
    int16_t int16_eq_const_396_0;
    int32_t int32_eq_const_397_0;
    int16_t int16_eq_const_398_0;
    int32_t int32_eq_const_399_0;
    int16_t int16_eq_const_400_0;
    int64_t int64_eq_const_401_0;
    int16_t int16_eq_const_402_0;
    int16_t int16_eq_const_403_0;
    int32_t int32_eq_const_404_0;
    int8_t int8_eq_const_405_0;
    int32_t int32_eq_const_406_0;
    int8_t int8_eq_const_407_0;
    int32_t int32_eq_const_408_0;
    int8_t int8_eq_const_409_0;
    int8_t int8_eq_const_410_0;
    int64_t int64_eq_const_411_0;
    int16_t int16_eq_const_412_0;
    int64_t int64_eq_const_413_0;
    int32_t int32_eq_const_414_0;
    int32_t int32_eq_const_415_0;
    int32_t int32_eq_const_416_0;
    int32_t int32_eq_const_417_0;
    int8_t int8_eq_const_418_0;
    int32_t int32_eq_const_419_0;
    int64_t int64_eq_const_420_0;
    int32_t int32_eq_const_421_0;
    int32_t int32_eq_const_422_0;
    int8_t int8_eq_const_423_0;
    int8_t int8_eq_const_424_0;
    int8_t int8_eq_const_425_0;
    int8_t int8_eq_const_426_0;
    int32_t int32_eq_const_427_0;
    int16_t int16_eq_const_428_0;
    int32_t int32_eq_const_429_0;
    int16_t int16_eq_const_430_0;
    int16_t int16_eq_const_431_0;
    int8_t int8_eq_const_432_0;
    int32_t int32_eq_const_433_0;
    int32_t int32_eq_const_434_0;
    int8_t int8_eq_const_435_0;
    int64_t int64_eq_const_436_0;
    int64_t int64_eq_const_437_0;
    int32_t int32_eq_const_438_0;
    int64_t int64_eq_const_439_0;
    int64_t int64_eq_const_440_0;
    int8_t int8_eq_const_441_0;
    int8_t int8_eq_const_442_0;
    int64_t int64_eq_const_443_0;
    int16_t int16_eq_const_444_0;
    int64_t int64_eq_const_445_0;
    int8_t int8_eq_const_446_0;
    int64_t int64_eq_const_447_0;
    int64_t int64_eq_const_448_0;
    int16_t int16_eq_const_449_0;
    int32_t int32_eq_const_450_0;
    int32_t int32_eq_const_451_0;
    int32_t int32_eq_const_452_0;
    int32_t int32_eq_const_453_0;
    int8_t int8_eq_const_454_0;
    int8_t int8_eq_const_455_0;
    int64_t int64_eq_const_456_0;
    int32_t int32_eq_const_457_0;
    int32_t int32_eq_const_458_0;
    int8_t int8_eq_const_459_0;
    int16_t int16_eq_const_460_0;
    int64_t int64_eq_const_461_0;
    int64_t int64_eq_const_462_0;
    int8_t int8_eq_const_463_0;
    int16_t int16_eq_const_464_0;
    int16_t int16_eq_const_465_0;
    int32_t int32_eq_const_466_0;
    int16_t int16_eq_const_467_0;
    int64_t int64_eq_const_468_0;
    int16_t int16_eq_const_469_0;
    int64_t int64_eq_const_470_0;
    int16_t int16_eq_const_471_0;
    int16_t int16_eq_const_472_0;
    int8_t int8_eq_const_473_0;
    int32_t int32_eq_const_474_0;
    int8_t int8_eq_const_475_0;
    int8_t int8_eq_const_476_0;
    int8_t int8_eq_const_477_0;
    int16_t int16_eq_const_478_0;
    int16_t int16_eq_const_479_0;
    int64_t int64_eq_const_480_0;
    int64_t int64_eq_const_481_0;
    int64_t int64_eq_const_482_0;
    int16_t int16_eq_const_483_0;
    int64_t int64_eq_const_484_0;
    int16_t int16_eq_const_485_0;
    int32_t int32_eq_const_486_0;
    int16_t int16_eq_const_487_0;
    int8_t int8_eq_const_488_0;
    int16_t int16_eq_const_489_0;
    int64_t int64_eq_const_490_0;
    int8_t int8_eq_const_491_0;
    int64_t int64_eq_const_492_0;
    int16_t int16_eq_const_493_0;
    int64_t int64_eq_const_494_0;
    int32_t int32_eq_const_495_0;
    int8_t int8_eq_const_496_0;
    int32_t int32_eq_const_497_0;
    int16_t int16_eq_const_498_0;
    int16_t int16_eq_const_499_0;
    int64_t int64_eq_const_500_0;
    int64_t int64_eq_const_501_0;
    int16_t int16_eq_const_502_0;
    int8_t int8_eq_const_503_0;
    int16_t int16_eq_const_504_0;
    int16_t int16_eq_const_505_0;
    int64_t int64_eq_const_506_0;
    int16_t int16_eq_const_507_0;
    int8_t int8_eq_const_508_0;
    int32_t int32_eq_const_509_0;
    int32_t int32_eq_const_510_0;
    int16_t int16_eq_const_511_0;

    if (size < 1872)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_1_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_3_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_4_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_5_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_6_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_9_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_10_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_11_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_12_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_13_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_14_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_15_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_16_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_17_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_18_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_19_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_20_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_21_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_22_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_23_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_24_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_26_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_27_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_28_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_29_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_30_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_31_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_32_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_33_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_34_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_35_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_36_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_38_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_39_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_41_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_42_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_43_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_44_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_45_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_47_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_48_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_49_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_51_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_52_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_53_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_54_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_55_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_56_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_57_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_59_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_60_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_61_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_62_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_63_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_64_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_65_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_66_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_67_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_68_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_69_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_70_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_71_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_72_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_73_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_74_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_75_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_76_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_77_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_78_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_79_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_80_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_81_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_82_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_83_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_84_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_85_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_86_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_87_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_88_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_89_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_90_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_91_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_92_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_93_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_94_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_95_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_96_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_97_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_98_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_99_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_100_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_101_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_102_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_103_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_104_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_105_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_106_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_107_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_108_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_109_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_110_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_111_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_112_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_113_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_114_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_115_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_116_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_117_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_118_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_119_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_120_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_121_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_122_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_123_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_124_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_125_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_126_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_127_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_128_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_129_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_130_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_131_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_132_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_133_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_134_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_135_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_136_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_137_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_138_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_139_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_140_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_141_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_142_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_143_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_144_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_145_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_146_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_147_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_148_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_149_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_150_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_151_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_152_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_153_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_154_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_155_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_156_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_157_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_158_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_159_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_160_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_161_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_162_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_163_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_164_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_165_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_166_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_167_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_168_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_169_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_170_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_171_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_172_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_173_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_174_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_175_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_176_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_177_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_178_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_179_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_180_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_181_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_182_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_183_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_184_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_185_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_186_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_187_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_188_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_189_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_190_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_191_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_192_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_193_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_194_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_195_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_196_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_197_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_198_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_199_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_200_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_201_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_202_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_203_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_204_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_205_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_206_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_207_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_208_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_209_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_210_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_211_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_212_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_213_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_214_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_215_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_216_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_217_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_218_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_219_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_220_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_221_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_222_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_223_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_224_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_225_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_226_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_227_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_228_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_229_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_230_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_231_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_232_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_233_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_234_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_235_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_236_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_237_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_238_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_239_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_240_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_241_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_242_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_243_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_244_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_245_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_246_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_247_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_248_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_249_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_250_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_251_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_252_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_253_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_254_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_255_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_256_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_257_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_258_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_259_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_260_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_261_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_262_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_263_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_264_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_265_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_266_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_267_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_268_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_269_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_270_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_271_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_272_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_273_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_274_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_275_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_276_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_277_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_278_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_279_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_280_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_281_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_282_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_283_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_284_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_285_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_286_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_287_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_288_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_289_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_290_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_291_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_292_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_293_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_294_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_295_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_296_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_297_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_298_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_299_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_300_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_301_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_302_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_303_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_304_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_305_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_306_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_307_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_308_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_309_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_310_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_311_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_312_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_313_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_314_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_315_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_316_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_317_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_318_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_319_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_320_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_321_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_322_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_323_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_324_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_325_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_326_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_327_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_328_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_329_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_330_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_331_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_332_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_333_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_334_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_335_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_336_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_337_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_338_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_339_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_340_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_341_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_342_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_343_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_344_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_345_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_346_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_347_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_348_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_349_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_350_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_351_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_352_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_353_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_354_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_355_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_356_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_357_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_358_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_359_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_360_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_361_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_362_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_363_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_364_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_365_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_366_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_367_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_368_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_369_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_370_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_371_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_372_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_373_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_374_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_375_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_376_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_377_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_378_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_379_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_380_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_381_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_382_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_383_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_384_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_385_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_386_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_387_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_388_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_389_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_390_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_391_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_392_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_393_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_394_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_395_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_396_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_397_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_398_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_399_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_400_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_401_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_402_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_403_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_404_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_405_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_406_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_407_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_408_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_409_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_410_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_411_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_412_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_413_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_414_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_415_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_416_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_417_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_418_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_419_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_420_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_421_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_422_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_423_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_424_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_425_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_426_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_427_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_428_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_429_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_430_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_431_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_432_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_433_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_434_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_435_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_436_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_437_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_438_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_439_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_440_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_441_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_442_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_443_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_444_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_445_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_446_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_447_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_448_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_449_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_450_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_451_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_452_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_453_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_454_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_455_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_456_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_457_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_458_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_459_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_460_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_461_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_462_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_463_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_464_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_465_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_466_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_467_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_468_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_469_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_470_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_471_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_472_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_473_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_474_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_475_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_476_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_477_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_478_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_479_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_480_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_481_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_482_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_483_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_484_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_485_0, &data[i], 2);
    i += 2;
    memcpy(&int32_eq_const_486_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_487_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_488_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_489_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_490_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_491_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_492_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_493_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_494_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_495_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_496_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_497_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_498_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_499_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_500_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_501_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_502_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_503_0, &data[i], 1);
    i += 1;
    memcpy(&int16_eq_const_504_0, &data[i], 2);
    i += 2;
    memcpy(&int16_eq_const_505_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_506_0, &data[i], 8);
    i += 8;
    memcpy(&int16_eq_const_507_0, &data[i], 2);
    i += 2;
    memcpy(&int8_eq_const_508_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_509_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_510_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_511_0, &data[i], 2);
    i += 2;


    if (int64_eq_const_0_0 == -7844179577375574148)
    if (int64_eq_const_1_0 == -973997838764646091)
    if (int32_eq_const_2_0 == 138404397)
    if (int16_eq_const_3_0 == 2706)
    if (int64_eq_const_4_0 == -5056852019771018309)
    if (int64_eq_const_5_0 == -7413969633323255952)
    if (int64_eq_const_6_0 == 4659256066719173953)
    if (int32_eq_const_7_0 == -1816399670)
    if (int64_eq_const_8_0 == 7239207261628379835)
    if (int16_eq_const_9_0 == -19198)
    if (int16_eq_const_10_0 == -25619)
    if (int16_eq_const_11_0 == -32080)
    if (int16_eq_const_12_0 == 25757)
    if (int64_eq_const_13_0 == 7676402837154675288)
    if (int16_eq_const_14_0 == 16792)
    if (int8_eq_const_15_0 == -21)
    if (int64_eq_const_16_0 == -3163898237063736004)
    if (int16_eq_const_17_0 == -29235)
    if (int16_eq_const_18_0 == 3681)
    if (int64_eq_const_19_0 == -5674450569592031711)
    if (int8_eq_const_20_0 == -95)
    if (int16_eq_const_21_0 == -22750)
    if (int64_eq_const_22_0 == 555364060518316399)
    if (int64_eq_const_23_0 == 4182026724844147889)
    if (int16_eq_const_24_0 == 9146)
    if (int32_eq_const_25_0 == 67190013)
    if (int8_eq_const_26_0 == 106)
    if (int8_eq_const_27_0 == 33)
    if (int16_eq_const_28_0 == -20398)
    if (int8_eq_const_29_0 == -87)
    if (int16_eq_const_30_0 == -24971)
    if (int16_eq_const_31_0 == 25421)
    if (int64_eq_const_32_0 == -5701014884171565958)
    if (int16_eq_const_33_0 == 27139)
    if (int64_eq_const_34_0 == 5011275219657178026)
    if (int64_eq_const_35_0 == 7117704403142365999)
    if (int16_eq_const_36_0 == -16294)
    if (int32_eq_const_37_0 == 299226769)
    if (int32_eq_const_38_0 == -49346221)
    if (int64_eq_const_39_0 == -2509331314576052656)
    if (int32_eq_const_40_0 == 1766934767)
    if (int8_eq_const_41_0 == 31)
    if (int8_eq_const_42_0 == -16)
    if (int16_eq_const_43_0 == -4035)
    if (int64_eq_const_44_0 == 4160032475598042508)
    if (int8_eq_const_45_0 == -71)
    if (int32_eq_const_46_0 == 1300202840)
    if (int64_eq_const_47_0 == -8137841767508255112)
    if (int8_eq_const_48_0 == 2)
    if (int8_eq_const_49_0 == -87)
    if (int32_eq_const_50_0 == 833843023)
    if (int64_eq_const_51_0 == 6601292438168132720)
    if (int8_eq_const_52_0 == -62)
    if (int32_eq_const_53_0 == 1824078725)
    if (int64_eq_const_54_0 == -4524716211666976453)
    if (int8_eq_const_55_0 == -81)
    if (int8_eq_const_56_0 == 116)
    if (int64_eq_const_57_0 == -8100150452049750373)
    if (int32_eq_const_58_0 == -1636850041)
    if (int64_eq_const_59_0 == 4846823728521241224)
    if (int8_eq_const_60_0 == -95)
    if (int8_eq_const_61_0 == 110)
    if (int16_eq_const_62_0 == 9308)
    if (int32_eq_const_63_0 == -1104722774)
    if (int16_eq_const_64_0 == -1504)
    if (int16_eq_const_65_0 == -25987)
    if (int64_eq_const_66_0 == 7306169948437200905)
    if (int64_eq_const_67_0 == 4857736059373422605)
    if (int64_eq_const_68_0 == 6543027275495287812)
    if (int8_eq_const_69_0 == -106)
    if (int8_eq_const_70_0 == 32)
    if (int32_eq_const_71_0 == -385750113)
    if (int64_eq_const_72_0 == 1729873026296667857)
    if (int64_eq_const_73_0 == -1312580331177479798)
    if (int16_eq_const_74_0 == -26899)
    if (int64_eq_const_75_0 == -2409933816446185502)
    if (int8_eq_const_76_0 == -81)
    if (int8_eq_const_77_0 == -120)
    if (int16_eq_const_78_0 == 25028)
    if (int16_eq_const_79_0 == -31164)
    if (int32_eq_const_80_0 == -404853839)
    if (int32_eq_const_81_0 == -1750649557)
    if (int8_eq_const_82_0 == 63)
    if (int16_eq_const_83_0 == 5536)
    if (int8_eq_const_84_0 == 87)
    if (int64_eq_const_85_0 == 6497944914541912160)
    if (int8_eq_const_86_0 == -120)
    if (int32_eq_const_87_0 == -345124035)
    if (int32_eq_const_88_0 == 777042949)
    if (int16_eq_const_89_0 == -30950)
    if (int64_eq_const_90_0 == 7220024259907296296)
    if (int64_eq_const_91_0 == 2952085643602244180)
    if (int8_eq_const_92_0 == 36)
    if (int8_eq_const_93_0 == 34)
    if (int64_eq_const_94_0 == -6484926263303165508)
    if (int8_eq_const_95_0 == 68)
    if (int64_eq_const_96_0 == -555881275488782206)
    if (int32_eq_const_97_0 == 258161425)
    if (int16_eq_const_98_0 == -19945)
    if (int8_eq_const_99_0 == -69)
    if (int8_eq_const_100_0 == 88)
    if (int8_eq_const_101_0 == 76)
    if (int16_eq_const_102_0 == 9020)
    if (int8_eq_const_103_0 == -64)
    if (int32_eq_const_104_0 == -1029601942)
    if (int32_eq_const_105_0 == 1643192421)
    if (int32_eq_const_106_0 == -232322330)
    if (int16_eq_const_107_0 == -12836)
    if (int64_eq_const_108_0 == 7794382411778416556)
    if (int16_eq_const_109_0 == -23539)
    if (int64_eq_const_110_0 == -3138237282842050597)
    if (int64_eq_const_111_0 == -5801860047557310180)
    if (int8_eq_const_112_0 == 108)
    if (int8_eq_const_113_0 == -89)
    if (int64_eq_const_114_0 == 1295654289866004047)
    if (int64_eq_const_115_0 == 6076764503081190043)
    if (int32_eq_const_116_0 == -1840507598)
    if (int8_eq_const_117_0 == 114)
    if (int32_eq_const_118_0 == -1654375128)
    if (int16_eq_const_119_0 == 25557)
    if (int32_eq_const_120_0 == 1981308430)
    if (int8_eq_const_121_0 == 35)
    if (int64_eq_const_122_0 == 5967923446600485271)
    if (int16_eq_const_123_0 == -12245)
    if (int16_eq_const_124_0 == -24789)
    if (int32_eq_const_125_0 == 852633448)
    if (int8_eq_const_126_0 == 94)
    if (int32_eq_const_127_0 == -82830673)
    if (int64_eq_const_128_0 == -3810607962185550324)
    if (int16_eq_const_129_0 == 1457)
    if (int8_eq_const_130_0 == -17)
    if (int8_eq_const_131_0 == 53)
    if (int8_eq_const_132_0 == -73)
    if (int64_eq_const_133_0 == 2230402095402628006)
    if (int8_eq_const_134_0 == 22)
    if (int8_eq_const_135_0 == 92)
    if (int64_eq_const_136_0 == -7155043163374904948)
    if (int32_eq_const_137_0 == 1482805902)
    if (int32_eq_const_138_0 == -878909944)
    if (int16_eq_const_139_0 == 3704)
    if (int32_eq_const_140_0 == 1688546003)
    if (int8_eq_const_141_0 == 39)
    if (int16_eq_const_142_0 == 29933)
    if (int64_eq_const_143_0 == -8339765800228408519)
    if (int16_eq_const_144_0 == 2318)
    if (int16_eq_const_145_0 == -19590)
    if (int32_eq_const_146_0 == -115996931)
    if (int32_eq_const_147_0 == 325798680)
    if (int8_eq_const_148_0 == -16)
    if (int8_eq_const_149_0 == -103)
    if (int64_eq_const_150_0 == -5102109605883105953)
    if (int8_eq_const_151_0 == -84)
    if (int32_eq_const_152_0 == -1821343245)
    if (int16_eq_const_153_0 == -26306)
    if (int8_eq_const_154_0 == -85)
    if (int32_eq_const_155_0 == 940705645)
    if (int32_eq_const_156_0 == 707231017)
    if (int32_eq_const_157_0 == 6783101)
    if (int32_eq_const_158_0 == -1464623601)
    if (int16_eq_const_159_0 == 16072)
    if (int8_eq_const_160_0 == 44)
    if (int8_eq_const_161_0 == -86)
    if (int64_eq_const_162_0 == -2002800818948729548)
    if (int64_eq_const_163_0 == -2354765668486852605)
    if (int16_eq_const_164_0 == -3475)
    if (int32_eq_const_165_0 == 62169918)
    if (int8_eq_const_166_0 == 121)
    if (int64_eq_const_167_0 == 880140175861201814)
    if (int64_eq_const_168_0 == 5721692446175772807)
    if (int64_eq_const_169_0 == -7563857335247384595)
    if (int32_eq_const_170_0 == 1788995046)
    if (int16_eq_const_171_0 == 13068)
    if (int64_eq_const_172_0 == 3823332599231132945)
    if (int64_eq_const_173_0 == -2919908701329907727)
    if (int16_eq_const_174_0 == 27693)
    if (int8_eq_const_175_0 == -69)
    if (int16_eq_const_176_0 == -5490)
    if (int8_eq_const_177_0 == -6)
    if (int16_eq_const_178_0 == 25334)
    if (int32_eq_const_179_0 == 1467788895)
    if (int16_eq_const_180_0 == 11139)
    if (int8_eq_const_181_0 == -5)
    if (int8_eq_const_182_0 == 2)
    if (int8_eq_const_183_0 == 124)
    if (int64_eq_const_184_0 == -6488535097207129895)
    if (int32_eq_const_185_0 == -2092462506)
    if (int32_eq_const_186_0 == -1847359712)
    if (int16_eq_const_187_0 == 29530)
    if (int16_eq_const_188_0 == 3306)
    if (int8_eq_const_189_0 == 88)
    if (int16_eq_const_190_0 == 963)
    if (int32_eq_const_191_0 == 1588825327)
    if (int16_eq_const_192_0 == -18660)
    if (int16_eq_const_193_0 == 6035)
    if (int32_eq_const_194_0 == -1611737605)
    if (int32_eq_const_195_0 == -977225613)
    if (int64_eq_const_196_0 == 809376992171552677)
    if (int8_eq_const_197_0 == -124)
    if (int16_eq_const_198_0 == -15010)
    if (int32_eq_const_199_0 == 596372475)
    if (int64_eq_const_200_0 == -3615363500367102740)
    if (int8_eq_const_201_0 == -37)
    if (int32_eq_const_202_0 == -321462829)
    if (int16_eq_const_203_0 == 17113)
    if (int32_eq_const_204_0 == -1092932737)
    if (int8_eq_const_205_0 == 54)
    if (int32_eq_const_206_0 == 1560382328)
    if (int8_eq_const_207_0 == 50)
    if (int64_eq_const_208_0 == 6292049215025186023)
    if (int16_eq_const_209_0 == 16919)
    if (int32_eq_const_210_0 == -1004874557)
    if (int16_eq_const_211_0 == 28746)
    if (int16_eq_const_212_0 == 24980)
    if (int16_eq_const_213_0 == 12103)
    if (int64_eq_const_214_0 == -5043405155040271210)
    if (int64_eq_const_215_0 == -133925442536086608)
    if (int16_eq_const_216_0 == -26296)
    if (int64_eq_const_217_0 == 1482646688413803269)
    if (int16_eq_const_218_0 == 934)
    if (int32_eq_const_219_0 == 2053722227)
    if (int64_eq_const_220_0 == -434754954602726490)
    if (int16_eq_const_221_0 == 10030)
    if (int32_eq_const_222_0 == -820754571)
    if (int32_eq_const_223_0 == 1986514956)
    if (int64_eq_const_224_0 == -1887119320881224767)
    if (int16_eq_const_225_0 == -27401)
    if (int16_eq_const_226_0 == 1443)
    if (int16_eq_const_227_0 == 15151)
    if (int32_eq_const_228_0 == -669651738)
    if (int16_eq_const_229_0 == -32192)
    if (int64_eq_const_230_0 == -4607662108399406142)
    if (int16_eq_const_231_0 == -7506)
    if (int32_eq_const_232_0 == -382020163)
    if (int8_eq_const_233_0 == -88)
    if (int32_eq_const_234_0 == -563420519)
    if (int32_eq_const_235_0 == 737762356)
    if (int16_eq_const_236_0 == -31571)
    if (int32_eq_const_237_0 == 1510775181)
    if (int64_eq_const_238_0 == -4301126629439931203)
    if (int64_eq_const_239_0 == 4169397954680435643)
    if (int8_eq_const_240_0 == 82)
    if (int32_eq_const_241_0 == 850911905)
    if (int8_eq_const_242_0 == 63)
    if (int64_eq_const_243_0 == -360435229709461465)
    if (int8_eq_const_244_0 == -125)
    if (int32_eq_const_245_0 == -1573086857)
    if (int8_eq_const_246_0 == -82)
    if (int32_eq_const_247_0 == 1395520362)
    if (int64_eq_const_248_0 == 6439191983774707141)
    if (int64_eq_const_249_0 == -8882948923973153450)
    if (int8_eq_const_250_0 == -111)
    if (int8_eq_const_251_0 == -67)
    if (int8_eq_const_252_0 == -117)
    if (int16_eq_const_253_0 == 29296)
    if (int8_eq_const_254_0 == 76)
    if (int32_eq_const_255_0 == -2009445182)
    if (int8_eq_const_256_0 == -36)
    if (int32_eq_const_257_0 == 333841645)
    if (int64_eq_const_258_0 == -7865998709492402506)
    if (int64_eq_const_259_0 == 8671014381966315586)
    if (int16_eq_const_260_0 == -28784)
    if (int8_eq_const_261_0 == -66)
    if (int8_eq_const_262_0 == 11)
    if (int16_eq_const_263_0 == -24258)
    if (int8_eq_const_264_0 == -91)
    if (int64_eq_const_265_0 == 6244839382465345622)
    if (int8_eq_const_266_0 == 18)
    if (int64_eq_const_267_0 == 8475217968645101066)
    if (int64_eq_const_268_0 == -4135570805784731862)
    if (int64_eq_const_269_0 == -8973889193508551475)
    if (int8_eq_const_270_0 == -103)
    if (int64_eq_const_271_0 == -6582037846577007755)
    if (int32_eq_const_272_0 == 32928471)
    if (int64_eq_const_273_0 == 8543109841409752062)
    if (int16_eq_const_274_0 == -28800)
    if (int32_eq_const_275_0 == 611114784)
    if (int8_eq_const_276_0 == 1)
    if (int8_eq_const_277_0 == -70)
    if (int16_eq_const_278_0 == -5424)
    if (int16_eq_const_279_0 == -7450)
    if (int8_eq_const_280_0 == 70)
    if (int64_eq_const_281_0 == -4718262045575361167)
    if (int16_eq_const_282_0 == -10583)
    if (int16_eq_const_283_0 == 30604)
    if (int32_eq_const_284_0 == 2111129853)
    if (int16_eq_const_285_0 == -29706)
    if (int32_eq_const_286_0 == 1628293141)
    if (int32_eq_const_287_0 == -679429668)
    if (int32_eq_const_288_0 == 1798892919)
    if (int8_eq_const_289_0 == -18)
    if (int32_eq_const_290_0 == -402033688)
    if (int32_eq_const_291_0 == -22003649)
    if (int8_eq_const_292_0 == -108)
    if (int8_eq_const_293_0 == -99)
    if (int8_eq_const_294_0 == 119)
    if (int16_eq_const_295_0 == -18325)
    if (int64_eq_const_296_0 == -3722526957776428270)
    if (int32_eq_const_297_0 == -558151581)
    if (int16_eq_const_298_0 == -17741)
    if (int16_eq_const_299_0 == 12881)
    if (int16_eq_const_300_0 == -8594)
    if (int64_eq_const_301_0 == -884857323079832429)
    if (int8_eq_const_302_0 == 45)
    if (int16_eq_const_303_0 == 19622)
    if (int16_eq_const_304_0 == 20340)
    if (int16_eq_const_305_0 == 6058)
    if (int16_eq_const_306_0 == -21292)
    if (int32_eq_const_307_0 == 726488694)
    if (int32_eq_const_308_0 == -1272655471)
    if (int64_eq_const_309_0 == -4771157256533024352)
    if (int32_eq_const_310_0 == -1524945620)
    if (int64_eq_const_311_0 == 7142232544700937705)
    if (int8_eq_const_312_0 == -22)
    if (int32_eq_const_313_0 == -835237983)
    if (int64_eq_const_314_0 == 3607400883070169372)
    if (int32_eq_const_315_0 == 1061462321)
    if (int8_eq_const_316_0 == 47)
    if (int32_eq_const_317_0 == -1985954783)
    if (int32_eq_const_318_0 == -1821730879)
    if (int8_eq_const_319_0 == -126)
    if (int16_eq_const_320_0 == -12202)
    if (int8_eq_const_321_0 == -26)
    if (int32_eq_const_322_0 == 285018712)
    if (int64_eq_const_323_0 == 4235133984063615523)
    if (int32_eq_const_324_0 == 69404482)
    if (int8_eq_const_325_0 == -80)
    if (int64_eq_const_326_0 == 976991313481423772)
    if (int64_eq_const_327_0 == 3257400613781746184)
    if (int32_eq_const_328_0 == -1012681202)
    if (int16_eq_const_329_0 == 27474)
    if (int8_eq_const_330_0 == -64)
    if (int8_eq_const_331_0 == -78)
    if (int64_eq_const_332_0 == -2602540391624875397)
    if (int32_eq_const_333_0 == -2098735433)
    if (int16_eq_const_334_0 == 20117)
    if (int8_eq_const_335_0 == -53)
    if (int64_eq_const_336_0 == -3463742474792461272)
    if (int16_eq_const_337_0 == -25031)
    if (int16_eq_const_338_0 == -18411)
    if (int16_eq_const_339_0 == 8835)
    if (int64_eq_const_340_0 == -8230875049124764890)
    if (int64_eq_const_341_0 == 8755493390630313344)
    if (int16_eq_const_342_0 == 29071)
    if (int16_eq_const_343_0 == -23916)
    if (int64_eq_const_344_0 == 7714118918390626508)
    if (int16_eq_const_345_0 == -28733)
    if (int16_eq_const_346_0 == -16970)
    if (int32_eq_const_347_0 == -628281978)
    if (int8_eq_const_348_0 == -40)
    if (int8_eq_const_349_0 == -5)
    if (int32_eq_const_350_0 == 1307509301)
    if (int64_eq_const_351_0 == -2431525436728721071)
    if (int64_eq_const_352_0 == -4660200408229134188)
    if (int64_eq_const_353_0 == -2126680964383999847)
    if (int8_eq_const_354_0 == -116)
    if (int16_eq_const_355_0 == -6554)
    if (int32_eq_const_356_0 == 2123165313)
    if (int32_eq_const_357_0 == 2056026914)
    if (int16_eq_const_358_0 == -6264)
    if (int64_eq_const_359_0 == -7301624392440578440)
    if (int16_eq_const_360_0 == -24677)
    if (int8_eq_const_361_0 == -91)
    if (int16_eq_const_362_0 == 23953)
    if (int8_eq_const_363_0 == 117)
    if (int16_eq_const_364_0 == -7967)
    if (int64_eq_const_365_0 == -705309506931415849)
    if (int16_eq_const_366_0 == 9020)
    if (int8_eq_const_367_0 == -9)
    if (int16_eq_const_368_0 == -6589)
    if (int8_eq_const_369_0 == 110)
    if (int8_eq_const_370_0 == 33)
    if (int32_eq_const_371_0 == 1935291747)
    if (int64_eq_const_372_0 == 175308367597257839)
    if (int32_eq_const_373_0 == -1494924048)
    if (int32_eq_const_374_0 == -1321436222)
    if (int16_eq_const_375_0 == 4923)
    if (int32_eq_const_376_0 == 1074398822)
    if (int8_eq_const_377_0 == 29)
    if (int16_eq_const_378_0 == 1892)
    if (int16_eq_const_379_0 == 20516)
    if (int32_eq_const_380_0 == 200170111)
    if (int32_eq_const_381_0 == -519572244)
    if (int64_eq_const_382_0 == -2450939812706599281)
    if (int8_eq_const_383_0 == 13)
    if (int16_eq_const_384_0 == -23610)
    if (int16_eq_const_385_0 == -5064)
    if (int64_eq_const_386_0 == -7575613981612696909)
    if (int16_eq_const_387_0 == -21785)
    if (int16_eq_const_388_0 == -18755)
    if (int32_eq_const_389_0 == 1962662512)
    if (int8_eq_const_390_0 == -70)
    if (int16_eq_const_391_0 == -9169)
    if (int8_eq_const_392_0 == -8)
    if (int16_eq_const_393_0 == -15426)
    if (int16_eq_const_394_0 == -3659)
    if (int8_eq_const_395_0 == -35)
    if (int16_eq_const_396_0 == -16946)
    if (int32_eq_const_397_0 == 372326235)
    if (int16_eq_const_398_0 == 20197)
    if (int32_eq_const_399_0 == 398445913)
    if (int16_eq_const_400_0 == 10191)
    if (int64_eq_const_401_0 == 7544021638967755642)
    if (int16_eq_const_402_0 == 4240)
    if (int16_eq_const_403_0 == -24636)
    if (int32_eq_const_404_0 == 906298271)
    if (int8_eq_const_405_0 == 18)
    if (int32_eq_const_406_0 == -1030389245)
    if (int8_eq_const_407_0 == 20)
    if (int32_eq_const_408_0 == -1500708258)
    if (int8_eq_const_409_0 == 124)
    if (int8_eq_const_410_0 == 8)
    if (int64_eq_const_411_0 == -5043286100062528161)
    if (int16_eq_const_412_0 == -4367)
    if (int64_eq_const_413_0 == 7021319257237337305)
    if (int32_eq_const_414_0 == -1268066466)
    if (int32_eq_const_415_0 == 1591527992)
    if (int32_eq_const_416_0 == 635355760)
    if (int32_eq_const_417_0 == -272175544)
    if (int8_eq_const_418_0 == -83)
    if (int32_eq_const_419_0 == 57206536)
    if (int64_eq_const_420_0 == -4831698323441387858)
    if (int32_eq_const_421_0 == 1479615976)
    if (int32_eq_const_422_0 == 713074158)
    if (int8_eq_const_423_0 == 119)
    if (int8_eq_const_424_0 == 124)
    if (int8_eq_const_425_0 == -41)
    if (int8_eq_const_426_0 == 29)
    if (int32_eq_const_427_0 == 563628919)
    if (int16_eq_const_428_0 == -12872)
    if (int32_eq_const_429_0 == 84070600)
    if (int16_eq_const_430_0 == -12229)
    if (int16_eq_const_431_0 == -6504)
    if (int8_eq_const_432_0 == 0)
    if (int32_eq_const_433_0 == -1007570992)
    if (int32_eq_const_434_0 == 231737005)
    if (int8_eq_const_435_0 == -60)
    if (int64_eq_const_436_0 == 7507724823556336932)
    if (int64_eq_const_437_0 == 96023196039991409)
    if (int32_eq_const_438_0 == 1907704461)
    if (int64_eq_const_439_0 == 9027573505646362277)
    if (int64_eq_const_440_0 == 6162035266783058278)
    if (int8_eq_const_441_0 == 13)
    if (int8_eq_const_442_0 == -33)
    if (int64_eq_const_443_0 == -2912088971149949726)
    if (int16_eq_const_444_0 == -18222)
    if (int64_eq_const_445_0 == 4599200447447259949)
    if (int8_eq_const_446_0 == 101)
    if (int64_eq_const_447_0 == 7202756323227708265)
    if (int64_eq_const_448_0 == 7972779377415067612)
    if (int16_eq_const_449_0 == -18161)
    if (int32_eq_const_450_0 == 1557686459)
    if (int32_eq_const_451_0 == 1595028391)
    if (int32_eq_const_452_0 == -1957809474)
    if (int32_eq_const_453_0 == -1599766524)
    if (int8_eq_const_454_0 == -41)
    if (int8_eq_const_455_0 == -57)
    if (int64_eq_const_456_0 == 5219107496358144223)
    if (int32_eq_const_457_0 == -610997261)
    if (int32_eq_const_458_0 == 461343458)
    if (int8_eq_const_459_0 == -2)
    if (int16_eq_const_460_0 == 4772)
    if (int64_eq_const_461_0 == -3120674018246513202)
    if (int64_eq_const_462_0 == -6791412075385393470)
    if (int8_eq_const_463_0 == 69)
    if (int16_eq_const_464_0 == 6099)
    if (int16_eq_const_465_0 == 12245)
    if (int32_eq_const_466_0 == -376981915)
    if (int16_eq_const_467_0 == 23530)
    if (int64_eq_const_468_0 == -6873457207743333615)
    if (int16_eq_const_469_0 == 22755)
    if (int64_eq_const_470_0 == 2926330011105185222)
    if (int16_eq_const_471_0 == 26305)
    if (int16_eq_const_472_0 == -3610)
    if (int8_eq_const_473_0 == -69)
    if (int32_eq_const_474_0 == -958941481)
    if (int8_eq_const_475_0 == 96)
    if (int8_eq_const_476_0 == 109)
    if (int8_eq_const_477_0 == 18)
    if (int16_eq_const_478_0 == -5480)
    if (int16_eq_const_479_0 == -12919)
    if (int64_eq_const_480_0 == -6035587380194025732)
    if (int64_eq_const_481_0 == 3620846699929851909)
    if (int64_eq_const_482_0 == -4335499189673917204)
    if (int16_eq_const_483_0 == -31917)
    if (int64_eq_const_484_0 == -3308997496912913576)
    if (int16_eq_const_485_0 == 21854)
    if (int32_eq_const_486_0 == -1315459342)
    if (int16_eq_const_487_0 == -6456)
    if (int8_eq_const_488_0 == -9)
    if (int16_eq_const_489_0 == 860)
    if (int64_eq_const_490_0 == -3181566811166656337)
    if (int8_eq_const_491_0 == -87)
    if (int64_eq_const_492_0 == 1281161119990970133)
    if (int16_eq_const_493_0 == 23902)
    if (int64_eq_const_494_0 == 1876257372680516988)
    if (int32_eq_const_495_0 == 984462145)
    if (int8_eq_const_496_0 == -13)
    if (int32_eq_const_497_0 == 822388196)
    if (int16_eq_const_498_0 == -6970)
    if (int16_eq_const_499_0 == 16148)
    if (int64_eq_const_500_0 == 1960474686740405855)
    if (int64_eq_const_501_0 == -8961561875784238162)
    if (int16_eq_const_502_0 == 24433)
    if (int8_eq_const_503_0 == 54)
    if (int16_eq_const_504_0 == 17140)
    if (int16_eq_const_505_0 == 25721)
    if (int64_eq_const_506_0 == 5532580524098240959)
    if (int16_eq_const_507_0 == 5237)
    if (int8_eq_const_508_0 == -38)
    if (int32_eq_const_509_0 == 955604196)
    if (int32_eq_const_510_0 == -1617567504)
    if (int16_eq_const_511_0 == 1264)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
