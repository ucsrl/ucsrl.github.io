#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int64_t int64_eq_const_0_0;
    int8_t int8_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int8_t int8_eq_const_3_0;
    int8_t int8_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int16_t int16_eq_const_6_0;
    int64_t int64_eq_const_7_0;
    int64_t int64_eq_const_8_0;
    int8_t int8_eq_const_9_0;
    int64_t int64_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int64_t int64_eq_const_12_0;

    if (size < 58)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int64_eq_const_0_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_1_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int8_eq_const_3_0, &data[i], 1);
    i += 1;
    memcpy(&int8_eq_const_4_0, &data[i], 1);
    i += 1;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int16_eq_const_6_0, &data[i], 2);
    i += 2;
    memcpy(&int64_eq_const_7_0, &data[i], 8);
    i += 8;
    memcpy(&int64_eq_const_8_0, &data[i], 8);
    i += 8;
    memcpy(&int8_eq_const_9_0, &data[i], 1);
    i += 1;
    memcpy(&int64_eq_const_10_0, &data[i], 8);
    i += 8;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int64_eq_const_12_0, &data[i], 8);
    i += 8;


    if (int64_eq_const_0_0 == -421419391332459497)
    if (int8_eq_const_1_0 == 16)
    if (int32_eq_const_2_0 == -659691915)
    if (int8_eq_const_3_0 == -47)
    if (int8_eq_const_4_0 == 89)
    if (int32_eq_const_5_0 == -444994350)
    if (int16_eq_const_6_0 == 21877)
    if (int64_eq_const_7_0 == -509526177079276747)
    if (int64_eq_const_8_0 == -8998531154635562075)
    if (int8_eq_const_9_0 == -121)
    if (int64_eq_const_10_0 == -8374946280088441233)
    if (int32_eq_const_11_0 == -791372131)
    if (int64_eq_const_12_0 == 7045061637844398142)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
