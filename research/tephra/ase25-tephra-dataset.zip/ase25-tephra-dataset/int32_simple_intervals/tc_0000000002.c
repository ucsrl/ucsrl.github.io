#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    int32_t value;
    int32_t eps = 100;
    int32_t bound = 1699585472;

    if (size < sizeof(int32_t))
        return TEPHRA_EXIT_FAILURE;

    memcpy(&value, data, sizeof(int32_t));

    if (value <= (bound + eps))
        if ((bound - eps) <= value)
            BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
