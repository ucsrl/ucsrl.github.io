#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    int32_t value;
    int32_t eps = 100000000;
    int32_t bound = 318864961;

    if (size < sizeof(int32_t))
        return TEPHRA_EXIT_FAILURE;

    memcpy(&value, data, sizeof(int32_t));

    if (value <= (bound + eps))
        if ((bound - eps) <= value)
            BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
