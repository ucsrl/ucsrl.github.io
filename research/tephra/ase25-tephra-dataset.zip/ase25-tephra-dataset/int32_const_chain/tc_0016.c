#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int32_t int32_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int32_t int32_eq_const_12_0;
    int32_t int32_eq_const_13_0;
    int32_t int32_eq_const_14_0;
    int32_t int32_eq_const_15_0;

    if (size < 64)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_15_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == -532201046)
    if (int32_eq_const_1_0 == 1558317896)
    if (int32_eq_const_2_0 == 846509337)
    if (int32_eq_const_3_0 == -1459727296)
    if (int32_eq_const_4_0 == 1288751649)
    if (int32_eq_const_5_0 == 968298459)
    if (int32_eq_const_6_0 == 1266477296)
    if (int32_eq_const_7_0 == 1388309161)
    if (int32_eq_const_8_0 == 1504455963)
    if (int32_eq_const_9_0 == 2082969826)
    if (int32_eq_const_10_0 == -1592888753)
    if (int32_eq_const_11_0 == 490033538)
    if (int32_eq_const_12_0 == 184145353)
    if (int32_eq_const_13_0 == -1491591706)
    if (int32_eq_const_14_0 == 148502831)
    if (int32_eq_const_15_0 == 210426480)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
