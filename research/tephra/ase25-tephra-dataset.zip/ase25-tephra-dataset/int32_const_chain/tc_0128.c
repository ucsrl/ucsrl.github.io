#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int32_t int32_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int32_t int32_eq_const_12_0;
    int32_t int32_eq_const_13_0;
    int32_t int32_eq_const_14_0;
    int32_t int32_eq_const_15_0;
    int32_t int32_eq_const_16_0;
    int32_t int32_eq_const_17_0;
    int32_t int32_eq_const_18_0;
    int32_t int32_eq_const_19_0;
    int32_t int32_eq_const_20_0;
    int32_t int32_eq_const_21_0;
    int32_t int32_eq_const_22_0;
    int32_t int32_eq_const_23_0;
    int32_t int32_eq_const_24_0;
    int32_t int32_eq_const_25_0;
    int32_t int32_eq_const_26_0;
    int32_t int32_eq_const_27_0;
    int32_t int32_eq_const_28_0;
    int32_t int32_eq_const_29_0;
    int32_t int32_eq_const_30_0;
    int32_t int32_eq_const_31_0;
    int32_t int32_eq_const_32_0;
    int32_t int32_eq_const_33_0;
    int32_t int32_eq_const_34_0;
    int32_t int32_eq_const_35_0;
    int32_t int32_eq_const_36_0;
    int32_t int32_eq_const_37_0;
    int32_t int32_eq_const_38_0;
    int32_t int32_eq_const_39_0;
    int32_t int32_eq_const_40_0;
    int32_t int32_eq_const_41_0;
    int32_t int32_eq_const_42_0;
    int32_t int32_eq_const_43_0;
    int32_t int32_eq_const_44_0;
    int32_t int32_eq_const_45_0;
    int32_t int32_eq_const_46_0;
    int32_t int32_eq_const_47_0;
    int32_t int32_eq_const_48_0;
    int32_t int32_eq_const_49_0;
    int32_t int32_eq_const_50_0;
    int32_t int32_eq_const_51_0;
    int32_t int32_eq_const_52_0;
    int32_t int32_eq_const_53_0;
    int32_t int32_eq_const_54_0;
    int32_t int32_eq_const_55_0;
    int32_t int32_eq_const_56_0;
    int32_t int32_eq_const_57_0;
    int32_t int32_eq_const_58_0;
    int32_t int32_eq_const_59_0;
    int32_t int32_eq_const_60_0;
    int32_t int32_eq_const_61_0;
    int32_t int32_eq_const_62_0;
    int32_t int32_eq_const_63_0;
    int32_t int32_eq_const_64_0;
    int32_t int32_eq_const_65_0;
    int32_t int32_eq_const_66_0;
    int32_t int32_eq_const_67_0;
    int32_t int32_eq_const_68_0;
    int32_t int32_eq_const_69_0;
    int32_t int32_eq_const_70_0;
    int32_t int32_eq_const_71_0;
    int32_t int32_eq_const_72_0;
    int32_t int32_eq_const_73_0;
    int32_t int32_eq_const_74_0;
    int32_t int32_eq_const_75_0;
    int32_t int32_eq_const_76_0;
    int32_t int32_eq_const_77_0;
    int32_t int32_eq_const_78_0;
    int32_t int32_eq_const_79_0;
    int32_t int32_eq_const_80_0;
    int32_t int32_eq_const_81_0;
    int32_t int32_eq_const_82_0;
    int32_t int32_eq_const_83_0;
    int32_t int32_eq_const_84_0;
    int32_t int32_eq_const_85_0;
    int32_t int32_eq_const_86_0;
    int32_t int32_eq_const_87_0;
    int32_t int32_eq_const_88_0;
    int32_t int32_eq_const_89_0;
    int32_t int32_eq_const_90_0;
    int32_t int32_eq_const_91_0;
    int32_t int32_eq_const_92_0;
    int32_t int32_eq_const_93_0;
    int32_t int32_eq_const_94_0;
    int32_t int32_eq_const_95_0;
    int32_t int32_eq_const_96_0;
    int32_t int32_eq_const_97_0;
    int32_t int32_eq_const_98_0;
    int32_t int32_eq_const_99_0;
    int32_t int32_eq_const_100_0;
    int32_t int32_eq_const_101_0;
    int32_t int32_eq_const_102_0;
    int32_t int32_eq_const_103_0;
    int32_t int32_eq_const_104_0;
    int32_t int32_eq_const_105_0;
    int32_t int32_eq_const_106_0;
    int32_t int32_eq_const_107_0;
    int32_t int32_eq_const_108_0;
    int32_t int32_eq_const_109_0;
    int32_t int32_eq_const_110_0;
    int32_t int32_eq_const_111_0;
    int32_t int32_eq_const_112_0;
    int32_t int32_eq_const_113_0;
    int32_t int32_eq_const_114_0;
    int32_t int32_eq_const_115_0;
    int32_t int32_eq_const_116_0;
    int32_t int32_eq_const_117_0;
    int32_t int32_eq_const_118_0;
    int32_t int32_eq_const_119_0;
    int32_t int32_eq_const_120_0;
    int32_t int32_eq_const_121_0;
    int32_t int32_eq_const_122_0;
    int32_t int32_eq_const_123_0;
    int32_t int32_eq_const_124_0;
    int32_t int32_eq_const_125_0;
    int32_t int32_eq_const_126_0;
    int32_t int32_eq_const_127_0;

    if (size < 512)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_22_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_28_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_31_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_32_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_33_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_38_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_39_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_41_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_42_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_43_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_44_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_45_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_51_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_53_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_54_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_55_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_56_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_59_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_60_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_61_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_63_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_64_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_65_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_66_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_67_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_68_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_69_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_70_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_71_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_72_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_73_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_74_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_75_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_76_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_77_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_78_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_79_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_80_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_81_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_82_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_83_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_84_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_85_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_86_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_87_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_88_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_89_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_90_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_91_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_92_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_93_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_94_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_95_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_96_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_97_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_98_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_99_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_100_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_101_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_102_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_103_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_104_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_105_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_106_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_107_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_108_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_109_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_110_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_111_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_112_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_113_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_114_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_115_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_116_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_117_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_118_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_119_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_120_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_121_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_122_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_123_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_124_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_125_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_126_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_127_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == 461353794)
    if (int32_eq_const_1_0 == 817379547)
    if (int32_eq_const_2_0 == 1360858977)
    if (int32_eq_const_3_0 == -1030521920)
    if (int32_eq_const_4_0 == -419852404)
    if (int32_eq_const_5_0 == -1409140176)
    if (int32_eq_const_6_0 == -972820410)
    if (int32_eq_const_7_0 == -1820842462)
    if (int32_eq_const_8_0 == -643099337)
    if (int32_eq_const_9_0 == 546166683)
    if (int32_eq_const_10_0 == 290545705)
    if (int32_eq_const_11_0 == -1890433716)
    if (int32_eq_const_12_0 == -789223984)
    if (int32_eq_const_13_0 == 233828678)
    if (int32_eq_const_14_0 == 2066037668)
    if (int32_eq_const_15_0 == -66672136)
    if (int32_eq_const_16_0 == -203299775)
    if (int32_eq_const_17_0 == -1111161327)
    if (int32_eq_const_18_0 == 309110125)
    if (int32_eq_const_19_0 == 1205534885)
    if (int32_eq_const_20_0 == -1219477569)
    if (int32_eq_const_21_0 == 1997624100)
    if (int32_eq_const_22_0 == -1332455169)
    if (int32_eq_const_23_0 == 887585432)
    if (int32_eq_const_24_0 == 1344901370)
    if (int32_eq_const_25_0 == 72647749)
    if (int32_eq_const_26_0 == -327086224)
    if (int32_eq_const_27_0 == -454752336)
    if (int32_eq_const_28_0 == -919959906)
    if (int32_eq_const_29_0 == 959641024)
    if (int32_eq_const_30_0 == -1182796684)
    if (int32_eq_const_31_0 == 509221965)
    if (int32_eq_const_32_0 == 1377215090)
    if (int32_eq_const_33_0 == 517374944)
    if (int32_eq_const_34_0 == -1826542999)
    if (int32_eq_const_35_0 == -2107110391)
    if (int32_eq_const_36_0 == -2040101722)
    if (int32_eq_const_37_0 == 1885924148)
    if (int32_eq_const_38_0 == -2094113004)
    if (int32_eq_const_39_0 == 1354428688)
    if (int32_eq_const_40_0 == 1505970439)
    if (int32_eq_const_41_0 == 457816375)
    if (int32_eq_const_42_0 == 53440405)
    if (int32_eq_const_43_0 == -983685862)
    if (int32_eq_const_44_0 == 283177932)
    if (int32_eq_const_45_0 == -1998467631)
    if (int32_eq_const_46_0 == -1221649067)
    if (int32_eq_const_47_0 == 309807544)
    if (int32_eq_const_48_0 == 764013885)
    if (int32_eq_const_49_0 == -1841927463)
    if (int32_eq_const_50_0 == 1135727486)
    if (int32_eq_const_51_0 == 1982455915)
    if (int32_eq_const_52_0 == 2095943422)
    if (int32_eq_const_53_0 == 530437151)
    if (int32_eq_const_54_0 == 219183294)
    if (int32_eq_const_55_0 == -215649262)
    if (int32_eq_const_56_0 == -2021408855)
    if (int32_eq_const_57_0 == -1590197900)
    if (int32_eq_const_58_0 == -2102831317)
    if (int32_eq_const_59_0 == -1063235229)
    if (int32_eq_const_60_0 == 2048368711)
    if (int32_eq_const_61_0 == -1089872466)
    if (int32_eq_const_62_0 == -1265037801)
    if (int32_eq_const_63_0 == -1665085995)
    if (int32_eq_const_64_0 == 1070287065)
    if (int32_eq_const_65_0 == -639133645)
    if (int32_eq_const_66_0 == 1458411556)
    if (int32_eq_const_67_0 == -893967781)
    if (int32_eq_const_68_0 == -316238991)
    if (int32_eq_const_69_0 == 947815578)
    if (int32_eq_const_70_0 == 25517805)
    if (int32_eq_const_71_0 == -1408642509)
    if (int32_eq_const_72_0 == -863831529)
    if (int32_eq_const_73_0 == 103943175)
    if (int32_eq_const_74_0 == 1879859215)
    if (int32_eq_const_75_0 == -1831427160)
    if (int32_eq_const_76_0 == 1416004327)
    if (int32_eq_const_77_0 == -1683804912)
    if (int32_eq_const_78_0 == -1043766927)
    if (int32_eq_const_79_0 == -1593169406)
    if (int32_eq_const_80_0 == 278903970)
    if (int32_eq_const_81_0 == -486011677)
    if (int32_eq_const_82_0 == 1026372801)
    if (int32_eq_const_83_0 == 1188027344)
    if (int32_eq_const_84_0 == 255118039)
    if (int32_eq_const_85_0 == 213194245)
    if (int32_eq_const_86_0 == -413790440)
    if (int32_eq_const_87_0 == 951893315)
    if (int32_eq_const_88_0 == -1300790698)
    if (int32_eq_const_89_0 == 846834746)
    if (int32_eq_const_90_0 == 1408821479)
    if (int32_eq_const_91_0 == -2072602633)
    if (int32_eq_const_92_0 == -506423675)
    if (int32_eq_const_93_0 == -88971181)
    if (int32_eq_const_94_0 == 1851979411)
    if (int32_eq_const_95_0 == -1059470777)
    if (int32_eq_const_96_0 == 1930679540)
    if (int32_eq_const_97_0 == -969740828)
    if (int32_eq_const_98_0 == -1601885578)
    if (int32_eq_const_99_0 == 887061138)
    if (int32_eq_const_100_0 == 1315926545)
    if (int32_eq_const_101_0 == 1986610959)
    if (int32_eq_const_102_0 == -1455699392)
    if (int32_eq_const_103_0 == 918998241)
    if (int32_eq_const_104_0 == 1061709429)
    if (int32_eq_const_105_0 == 1667029086)
    if (int32_eq_const_106_0 == -1488710670)
    if (int32_eq_const_107_0 == -213775017)
    if (int32_eq_const_108_0 == -1667901032)
    if (int32_eq_const_109_0 == -1419059337)
    if (int32_eq_const_110_0 == 1519513907)
    if (int32_eq_const_111_0 == 1118494601)
    if (int32_eq_const_112_0 == -208822036)
    if (int32_eq_const_113_0 == -1595767709)
    if (int32_eq_const_114_0 == 1643625554)
    if (int32_eq_const_115_0 == 813617099)
    if (int32_eq_const_116_0 == -1481389625)
    if (int32_eq_const_117_0 == -1142785712)
    if (int32_eq_const_118_0 == 1196561898)
    if (int32_eq_const_119_0 == 1604746031)
    if (int32_eq_const_120_0 == 194983809)
    if (int32_eq_const_121_0 == 555363387)
    if (int32_eq_const_122_0 == -2136356994)
    if (int32_eq_const_123_0 == -2075572338)
    if (int32_eq_const_124_0 == -838512786)
    if (int32_eq_const_125_0 == -2142206396)
    if (int32_eq_const_126_0 == 687716387)
    if (int32_eq_const_127_0 == -1037062626)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
