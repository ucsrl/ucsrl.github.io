#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int32_t int32_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int32_t int32_eq_const_12_0;

    if (size < 52)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_12_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == 1147278726)
    if (int32_eq_const_1_0 == 110520526)
    if (int32_eq_const_2_0 == -1387216447)
    if (int32_eq_const_3_0 == 913088861)
    if (int32_eq_const_4_0 == 202754740)
    if (int32_eq_const_5_0 == -169617687)
    if (int32_eq_const_6_0 == -691650755)
    if (int32_eq_const_7_0 == -1971405421)
    if (int32_eq_const_8_0 == 1278035663)
    if (int32_eq_const_9_0 == 880485788)
    if (int32_eq_const_10_0 == -843158053)
    if (int32_eq_const_11_0 == 598941085)
    if (int32_eq_const_12_0 == 282688139)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
