#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int32_t int32_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int32_t int32_eq_const_12_0;
    int32_t int32_eq_const_13_0;
    int32_t int32_eq_const_14_0;
    int32_t int32_eq_const_15_0;
    int32_t int32_eq_const_16_0;
    int32_t int32_eq_const_17_0;
    int32_t int32_eq_const_18_0;
    int32_t int32_eq_const_19_0;
    int32_t int32_eq_const_20_0;
    int32_t int32_eq_const_21_0;
    int32_t int32_eq_const_22_0;
    int32_t int32_eq_const_23_0;
    int32_t int32_eq_const_24_0;
    int32_t int32_eq_const_25_0;
    int32_t int32_eq_const_26_0;
    int32_t int32_eq_const_27_0;
    int32_t int32_eq_const_28_0;
    int32_t int32_eq_const_29_0;
    int32_t int32_eq_const_30_0;
    int32_t int32_eq_const_31_0;
    int32_t int32_eq_const_32_0;
    int32_t int32_eq_const_33_0;
    int32_t int32_eq_const_34_0;
    int32_t int32_eq_const_35_0;
    int32_t int32_eq_const_36_0;
    int32_t int32_eq_const_37_0;
    int32_t int32_eq_const_38_0;
    int32_t int32_eq_const_39_0;
    int32_t int32_eq_const_40_0;
    int32_t int32_eq_const_41_0;
    int32_t int32_eq_const_42_0;
    int32_t int32_eq_const_43_0;
    int32_t int32_eq_const_44_0;
    int32_t int32_eq_const_45_0;
    int32_t int32_eq_const_46_0;
    int32_t int32_eq_const_47_0;
    int32_t int32_eq_const_48_0;
    int32_t int32_eq_const_49_0;
    int32_t int32_eq_const_50_0;
    int32_t int32_eq_const_51_0;
    int32_t int32_eq_const_52_0;
    int32_t int32_eq_const_53_0;
    int32_t int32_eq_const_54_0;
    int32_t int32_eq_const_55_0;
    int32_t int32_eq_const_56_0;
    int32_t int32_eq_const_57_0;
    int32_t int32_eq_const_58_0;
    int32_t int32_eq_const_59_0;
    int32_t int32_eq_const_60_0;
    int32_t int32_eq_const_61_0;
    int32_t int32_eq_const_62_0;
    int32_t int32_eq_const_63_0;

    if (size < 256)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_22_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_28_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_31_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_32_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_33_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_34_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_35_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_36_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_37_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_38_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_39_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_40_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_41_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_42_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_43_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_44_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_45_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_46_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_47_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_48_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_49_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_50_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_51_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_52_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_53_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_54_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_55_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_56_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_57_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_58_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_59_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_60_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_61_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_62_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_63_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == -750339063)
    if (int32_eq_const_1_0 == 493491807)
    if (int32_eq_const_2_0 == -1448724293)
    if (int32_eq_const_3_0 == -454513758)
    if (int32_eq_const_4_0 == -2143604577)
    if (int32_eq_const_5_0 == 1849384909)
    if (int32_eq_const_6_0 == 238389825)
    if (int32_eq_const_7_0 == -1590440844)
    if (int32_eq_const_8_0 == -1635059131)
    if (int32_eq_const_9_0 == -2065358146)
    if (int32_eq_const_10_0 == 1223513125)
    if (int32_eq_const_11_0 == -1252171885)
    if (int32_eq_const_12_0 == 1278063841)
    if (int32_eq_const_13_0 == -411718090)
    if (int32_eq_const_14_0 == -266745492)
    if (int32_eq_const_15_0 == 1523769739)
    if (int32_eq_const_16_0 == 1374729329)
    if (int32_eq_const_17_0 == -2007422663)
    if (int32_eq_const_18_0 == 1415666164)
    if (int32_eq_const_19_0 == 1508139750)
    if (int32_eq_const_20_0 == -488894023)
    if (int32_eq_const_21_0 == -381112256)
    if (int32_eq_const_22_0 == 1545471704)
    if (int32_eq_const_23_0 == 783626553)
    if (int32_eq_const_24_0 == 1501349730)
    if (int32_eq_const_25_0 == 1405945853)
    if (int32_eq_const_26_0 == -69417078)
    if (int32_eq_const_27_0 == 526978736)
    if (int32_eq_const_28_0 == 1151721083)
    if (int32_eq_const_29_0 == 1345772457)
    if (int32_eq_const_30_0 == -457900703)
    if (int32_eq_const_31_0 == -661652319)
    if (int32_eq_const_32_0 == -176510569)
    if (int32_eq_const_33_0 == -30503220)
    if (int32_eq_const_34_0 == -1519781840)
    if (int32_eq_const_35_0 == 51548665)
    if (int32_eq_const_36_0 == 1758728962)
    if (int32_eq_const_37_0 == 1950195455)
    if (int32_eq_const_38_0 == 1737001797)
    if (int32_eq_const_39_0 == -1390353238)
    if (int32_eq_const_40_0 == -699205390)
    if (int32_eq_const_41_0 == -705458109)
    if (int32_eq_const_42_0 == -1510821408)
    if (int32_eq_const_43_0 == 1306919459)
    if (int32_eq_const_44_0 == 1739692053)
    if (int32_eq_const_45_0 == 1653109613)
    if (int32_eq_const_46_0 == -1232387263)
    if (int32_eq_const_47_0 == -1576929434)
    if (int32_eq_const_48_0 == -1692005479)
    if (int32_eq_const_49_0 == 1478422842)
    if (int32_eq_const_50_0 == -990660663)
    if (int32_eq_const_51_0 == -1660130693)
    if (int32_eq_const_52_0 == -1679305159)
    if (int32_eq_const_53_0 == 705162498)
    if (int32_eq_const_54_0 == -393347858)
    if (int32_eq_const_55_0 == 849461659)
    if (int32_eq_const_56_0 == 1814724689)
    if (int32_eq_const_57_0 == 849983240)
    if (int32_eq_const_58_0 == 1412716871)
    if (int32_eq_const_59_0 == -943923981)
    if (int32_eq_const_60_0 == 337593666)
    if (int32_eq_const_61_0 == -1142109721)
    if (int32_eq_const_62_0 == 978936546)
    if (int32_eq_const_63_0 == -1285595627)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
