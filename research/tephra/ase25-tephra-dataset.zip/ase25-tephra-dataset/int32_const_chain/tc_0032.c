#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int32_t int32_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int32_t int32_eq_const_12_0;
    int32_t int32_eq_const_13_0;
    int32_t int32_eq_const_14_0;
    int32_t int32_eq_const_15_0;
    int32_t int32_eq_const_16_0;
    int32_t int32_eq_const_17_0;
    int32_t int32_eq_const_18_0;
    int32_t int32_eq_const_19_0;
    int32_t int32_eq_const_20_0;
    int32_t int32_eq_const_21_0;
    int32_t int32_eq_const_22_0;
    int32_t int32_eq_const_23_0;
    int32_t int32_eq_const_24_0;
    int32_t int32_eq_const_25_0;
    int32_t int32_eq_const_26_0;
    int32_t int32_eq_const_27_0;
    int32_t int32_eq_const_28_0;
    int32_t int32_eq_const_29_0;
    int32_t int32_eq_const_30_0;
    int32_t int32_eq_const_31_0;

    if (size < 128)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_13_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_14_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_15_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_16_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_17_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_18_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_19_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_20_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_21_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_22_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_23_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_24_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_25_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_26_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_27_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_28_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_29_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_30_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_31_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == -1715962834)
    if (int32_eq_const_1_0 == 1787968149)
    if (int32_eq_const_2_0 == -1279116453)
    if (int32_eq_const_3_0 == 270541020)
    if (int32_eq_const_4_0 == 265003535)
    if (int32_eq_const_5_0 == -1802674352)
    if (int32_eq_const_6_0 == -356986554)
    if (int32_eq_const_7_0 == 258316412)
    if (int32_eq_const_8_0 == -1716851581)
    if (int32_eq_const_9_0 == 476037419)
    if (int32_eq_const_10_0 == 1805510065)
    if (int32_eq_const_11_0 == -2002702614)
    if (int32_eq_const_12_0 == -1376852945)
    if (int32_eq_const_13_0 == 2136577929)
    if (int32_eq_const_14_0 == 1037338255)
    if (int32_eq_const_15_0 == -1876105588)
    if (int32_eq_const_16_0 == -777878099)
    if (int32_eq_const_17_0 == 566889730)
    if (int32_eq_const_18_0 == 977697524)
    if (int32_eq_const_19_0 == -2024001129)
    if (int32_eq_const_20_0 == 1342426880)
    if (int32_eq_const_21_0 == -495591751)
    if (int32_eq_const_22_0 == 1498486414)
    if (int32_eq_const_23_0 == 49027928)
    if (int32_eq_const_24_0 == 1343839179)
    if (int32_eq_const_25_0 == 2098301944)
    if (int32_eq_const_26_0 == 214441932)
    if (int32_eq_const_27_0 == -2095054644)
    if (int32_eq_const_28_0 == -1481698935)
    if (int32_eq_const_29_0 == -1566500698)
    if (int32_eq_const_30_0 == 750830332)
    if (int32_eq_const_31_0 == 814536722)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
