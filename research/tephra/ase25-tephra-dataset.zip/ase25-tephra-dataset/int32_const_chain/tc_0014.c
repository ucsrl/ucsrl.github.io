#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int32_t int32_eq_const_7_0;
    int32_t int32_eq_const_8_0;
    int32_t int32_eq_const_9_0;
    int32_t int32_eq_const_10_0;
    int32_t int32_eq_const_11_0;
    int32_t int32_eq_const_12_0;
    int32_t int32_eq_const_13_0;

    if (size < 56)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_8_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_9_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_10_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_11_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_12_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_13_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == -2046122075)
    if (int32_eq_const_1_0 == -184124873)
    if (int32_eq_const_2_0 == -818670594)
    if (int32_eq_const_3_0 == -1479760052)
    if (int32_eq_const_4_0 == 545802542)
    if (int32_eq_const_5_0 == -164599173)
    if (int32_eq_const_6_0 == 776263026)
    if (int32_eq_const_7_0 == 311557518)
    if (int32_eq_const_8_0 == 494839804)
    if (int32_eq_const_9_0 == 894287070)
    if (int32_eq_const_10_0 == 882420734)
    if (int32_eq_const_11_0 == 82744654)
    if (int32_eq_const_12_0 == 835628727)
    if (int32_eq_const_13_0 == -1080465458)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
