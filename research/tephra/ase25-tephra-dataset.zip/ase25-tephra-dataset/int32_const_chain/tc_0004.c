#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;

    if (size < 16)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == 307606869)
    if (int32_eq_const_1_0 == -553997998)
    if (int32_eq_const_2_0 == 1596931529)
    if (int32_eq_const_3_0 == 1313104400)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
