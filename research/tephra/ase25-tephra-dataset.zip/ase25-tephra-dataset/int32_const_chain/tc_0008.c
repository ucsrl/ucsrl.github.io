#include "common.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

int
LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    size_t i = 0;

    int32_t int32_eq_const_0_0;
    int32_t int32_eq_const_1_0;
    int32_t int32_eq_const_2_0;
    int32_t int32_eq_const_3_0;
    int32_t int32_eq_const_4_0;
    int32_t int32_eq_const_5_0;
    int32_t int32_eq_const_6_0;
    int32_t int32_eq_const_7_0;

    if (size < 32)
        return TEPHRA_EXIT_FAILURE;


    memcpy(&int32_eq_const_0_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_1_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_2_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_3_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_4_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_5_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_6_0, &data[i], 4);
    i += 4;
    memcpy(&int32_eq_const_7_0, &data[i], 4);
    i += 4;


    if (int32_eq_const_0_0 == 967654628)
    if (int32_eq_const_1_0 == 753869889)
    if (int32_eq_const_2_0 == 1459712965)
    if (int32_eq_const_3_0 == -83580011)
    if (int32_eq_const_4_0 == -713151314)
    if (int32_eq_const_5_0 == 1324261806)
    if (int32_eq_const_6_0 == 1230553726)
    if (int32_eq_const_7_0 == -900853446)
        BOOM();

    return TEPHRA_EXIT_SUCCESS;
}

#ifdef __cplusplus
}
#endif
